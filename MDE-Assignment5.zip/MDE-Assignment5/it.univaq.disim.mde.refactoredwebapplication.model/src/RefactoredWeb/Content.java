/**
 */
package RefactoredWeb;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Content</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RefactoredWeb.RefactoredWebPackage#getContent()
 * @model abstract="true"
 * @generated
 */
public interface Content extends NamedIdentifier {
} // Content
