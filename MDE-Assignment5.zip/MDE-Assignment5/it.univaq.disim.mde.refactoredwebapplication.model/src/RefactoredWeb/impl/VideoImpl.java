/**
 */
package RefactoredWeb.impl;

import RefactoredWeb.RefactoredWebPackage;
import RefactoredWeb.Video;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Video</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class VideoImpl extends VisualMediaImpl implements Video {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VideoImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RefactoredWebPackage.Literals.VIDEO;
	}

} //VideoImpl
