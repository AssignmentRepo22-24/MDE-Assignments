/**
 */
package RefactoredWeb.impl;

import RefactoredWeb.Administrator;
import RefactoredWeb.Attribute;
import RefactoredWeb.Content;
import RefactoredWeb.DContent;
import RefactoredWeb.DataType;
import RefactoredWeb.Detail;
import RefactoredWeb.DisplayMode;
import RefactoredWeb.Element;
import RefactoredWeb.ElementType;
import RefactoredWeb.Entity;
import RefactoredWeb.Form;
import RefactoredWeb.Image;
import RefactoredWeb.List;
import RefactoredWeb.MethodType;
import RefactoredWeb.NamedIdentifier;
import RefactoredWeb.Page;
import RefactoredWeb.RefactoredWebApplication;
import RefactoredWeb.RefactoredWebFactory;
import RefactoredWeb.RefactoredWebPackage;
import RefactoredWeb.Reference;
import RefactoredWeb.SContent;
import RefactoredWeb.Video;
import RefactoredWeb.VisualMedia;

import RefactoredWeb.util.RefactoredWebValidator;

import java.time.Instant;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EGenericType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class RefactoredWebPackageImpl extends EPackageImpl implements RefactoredWebPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass refactoredWebApplicationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass entityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass attributeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass referenceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass namedIdentifierEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass contentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dContentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass listEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass detailEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass sContentEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass formEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass visualMediaEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass administratorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass imageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass videoEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum dataTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum methodTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum elementTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum displayModeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType instantEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see RefactoredWeb.RefactoredWebPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private RefactoredWebPackageImpl() {
		super(eNS_URI, RefactoredWebFactory.eINSTANCE);
	}
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link RefactoredWebPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static RefactoredWebPackage init() {
		if (isInited) return (RefactoredWebPackage)EPackage.Registry.INSTANCE.getEPackage(RefactoredWebPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredRefactoredWebPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		RefactoredWebPackageImpl theRefactoredWebPackage = registeredRefactoredWebPackage instanceof RefactoredWebPackageImpl ? (RefactoredWebPackageImpl)registeredRefactoredWebPackage : new RefactoredWebPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theRefactoredWebPackage.createPackageContents();

		// Initialize created meta-data
		theRefactoredWebPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theRefactoredWebPackage,
			 new EValidator.Descriptor() {
				 public EValidator getEValidator() {
					 return RefactoredWebValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theRefactoredWebPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(RefactoredWebPackage.eNS_URI, theRefactoredWebPackage);
		return theRefactoredWebPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRefactoredWebApplication() {
		return refactoredWebApplicationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRefactoredWebApplication_Entities() {
		return (EReference)refactoredWebApplicationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRefactoredWebApplication_Pages() {
		return (EReference)refactoredWebApplicationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRefactoredWebApplication_TotalPages() {
		return (EAttribute)refactoredWebApplicationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRefactoredWebApplication_DisplayMode() {
		return (EAttribute)refactoredWebApplicationEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRefactoredWebApplication_Admin() {
		return (EReference)refactoredWebApplicationEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRefactoredWebApplication_CurrentSysAdmin() {
		return (EAttribute)refactoredWebApplicationEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRefactoredWebApplication__UniquePageNames__DiagnosticChain_Map() {
		return refactoredWebApplicationEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRefactoredWebApplication__AtLeastOnePage__DiagnosticChain_Map() {
		return refactoredWebApplicationEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRefactoredWebApplication__AtLeastOneEntity__DiagnosticChain_Map() {
		return refactoredWebApplicationEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getRefactoredWebApplication__UniqueEntityNames__DiagnosticChain_Map() {
		return refactoredWebApplicationEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEntity() {
		return entityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntity_Attributes() {
		return (EReference)entityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntity_References() {
		return (EReference)entityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEntity__PrimaryKeyName() {
		return entityEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEntity__OnePrimaryKey__DiagnosticChain_Map() {
		return entityEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getEntity__UniqueAttributeReferenceNames__DiagnosticChain_Map() {
		return entityEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAttribute() {
		return attributeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_Type() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAttribute_IsPK() {
		return (EAttribute)attributeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getReference() {
		return referenceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getReference_ForeignKey() {
		return (EReference)referenceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNamedIdentifier() {
		return namedIdentifierEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNamedIdentifier_Name() {
		return (EAttribute)namedIdentifierEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNamedIdentifier_Id() {
		return (EAttribute)namedIdentifierEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPage() {
		return pageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPage_TotalMediaSize() {
		return (EAttribute)pageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPage_Link() {
		return (EReference)pageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPage_Contents() {
		return (EReference)pageEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPage_WebApplication() {
		return (EReference)pageEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPage_CreatedAt() {
		return (EAttribute)pageEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPage__IsNotEmpty() {
		return pageEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPage__GetStaticContentQty() {
		return pageEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPage__GetDynamicContentQty() {
		return pageEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getPage__OptimisePageLoad__DiagnosticChain_Map() {
		return pageEClass.getEOperations().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getContent() {
		return contentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDContent() {
		return dContentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDContent_Attributes() {
		return (EReference)dContentEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getDContent_Entity() {
		return (EReference)dContentEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getList() {
		return listEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getDetail() {
		return detailEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSContent() {
		return sContentEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getForm() {
		return formEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getForm_Method() {
		return (EAttribute)formEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getForm_Elements() {
		return (EReference)formEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getForm_Entity() {
		return (EReference)formEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getForm__GetElementQty() {
		return formEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EOperation getForm__AtLeastOneElement__DiagnosticChain_Map() {
		return formEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElement() {
		return elementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElement_Label() {
		return (EAttribute)elementEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElement_Tooltip() {
		return (EAttribute)elementEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElement_Attribute() {
		return (EReference)elementEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getElement_Type() {
		return (EAttribute)elementEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getElement_Form() {
		return (EReference)elementEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVisualMedia() {
		return visualMediaEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVisualMedia_Source() {
		return (EAttribute)visualMediaEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVisualMedia_AltText() {
		return (EAttribute)visualMediaEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVisualMedia_Size() {
		return (EAttribute)visualMediaEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVisualMedia_MediaClassification() {
		return (EAttribute)visualMediaEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAdministrator() {
		return administratorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAdministrator_FirstName() {
		return (EAttribute)administratorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAdministrator_LastName() {
		return (EAttribute)administratorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAdministrator_Id() {
		return (EAttribute)administratorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAdministrator_FullName() {
		return (EAttribute)administratorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getImage() {
		return imageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVideo() {
		return videoEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getDataType() {
		return dataTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getMethodType() {
		return methodTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getElementType() {
		return elementTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getDisplayMode() {
		return displayModeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getInstant() {
		return instantEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RefactoredWebFactory getRefactoredWebFactory() {
		return (RefactoredWebFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		refactoredWebApplicationEClass = createEClass(REFACTORED_WEB_APPLICATION);
		createEReference(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION__ENTITIES);
		createEReference(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION__PAGES);
		createEAttribute(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION__TOTAL_PAGES);
		createEAttribute(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION__DISPLAY_MODE);
		createEReference(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION__ADMIN);
		createEAttribute(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION__CURRENT_SYS_ADMIN);
		createEOperation(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION___UNIQUE_PAGE_NAMES__DIAGNOSTICCHAIN_MAP);
		createEOperation(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION___AT_LEAST_ONE_PAGE__DIAGNOSTICCHAIN_MAP);
		createEOperation(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION___AT_LEAST_ONE_ENTITY__DIAGNOSTICCHAIN_MAP);
		createEOperation(refactoredWebApplicationEClass, REFACTORED_WEB_APPLICATION___UNIQUE_ENTITY_NAMES__DIAGNOSTICCHAIN_MAP);

		entityEClass = createEClass(ENTITY);
		createEReference(entityEClass, ENTITY__ATTRIBUTES);
		createEReference(entityEClass, ENTITY__REFERENCES);
		createEOperation(entityEClass, ENTITY___PRIMARY_KEY_NAME);
		createEOperation(entityEClass, ENTITY___ONE_PRIMARY_KEY__DIAGNOSTICCHAIN_MAP);
		createEOperation(entityEClass, ENTITY___UNIQUE_ATTRIBUTE_REFERENCE_NAMES__DIAGNOSTICCHAIN_MAP);

		attributeEClass = createEClass(ATTRIBUTE);
		createEAttribute(attributeEClass, ATTRIBUTE__TYPE);
		createEAttribute(attributeEClass, ATTRIBUTE__IS_PK);

		referenceEClass = createEClass(REFERENCE);
		createEReference(referenceEClass, REFERENCE__FOREIGN_KEY);

		namedIdentifierEClass = createEClass(NAMED_IDENTIFIER);
		createEAttribute(namedIdentifierEClass, NAMED_IDENTIFIER__NAME);
		createEAttribute(namedIdentifierEClass, NAMED_IDENTIFIER__ID);

		pageEClass = createEClass(PAGE);
		createEAttribute(pageEClass, PAGE__TOTAL_MEDIA_SIZE);
		createEReference(pageEClass, PAGE__LINK);
		createEReference(pageEClass, PAGE__CONTENTS);
		createEReference(pageEClass, PAGE__WEB_APPLICATION);
		createEAttribute(pageEClass, PAGE__CREATED_AT);
		createEOperation(pageEClass, PAGE___IS_NOT_EMPTY);
		createEOperation(pageEClass, PAGE___GET_STATIC_CONTENT_QTY);
		createEOperation(pageEClass, PAGE___GET_DYNAMIC_CONTENT_QTY);
		createEOperation(pageEClass, PAGE___OPTIMISE_PAGE_LOAD__DIAGNOSTICCHAIN_MAP);

		contentEClass = createEClass(CONTENT);

		dContentEClass = createEClass(DCONTENT);
		createEReference(dContentEClass, DCONTENT__ATTRIBUTES);
		createEReference(dContentEClass, DCONTENT__ENTITY);

		listEClass = createEClass(LIST);

		detailEClass = createEClass(DETAIL);

		sContentEClass = createEClass(SCONTENT);

		formEClass = createEClass(FORM);
		createEAttribute(formEClass, FORM__METHOD);
		createEReference(formEClass, FORM__ELEMENTS);
		createEReference(formEClass, FORM__ENTITY);
		createEOperation(formEClass, FORM___GET_ELEMENT_QTY);
		createEOperation(formEClass, FORM___AT_LEAST_ONE_ELEMENT__DIAGNOSTICCHAIN_MAP);

		elementEClass = createEClass(ELEMENT);
		createEAttribute(elementEClass, ELEMENT__LABEL);
		createEAttribute(elementEClass, ELEMENT__TOOLTIP);
		createEReference(elementEClass, ELEMENT__ATTRIBUTE);
		createEAttribute(elementEClass, ELEMENT__TYPE);
		createEReference(elementEClass, ELEMENT__FORM);

		visualMediaEClass = createEClass(VISUAL_MEDIA);
		createEAttribute(visualMediaEClass, VISUAL_MEDIA__SOURCE);
		createEAttribute(visualMediaEClass, VISUAL_MEDIA__ALT_TEXT);
		createEAttribute(visualMediaEClass, VISUAL_MEDIA__SIZE);
		createEAttribute(visualMediaEClass, VISUAL_MEDIA__MEDIA_CLASSIFICATION);

		administratorEClass = createEClass(ADMINISTRATOR);
		createEAttribute(administratorEClass, ADMINISTRATOR__FIRST_NAME);
		createEAttribute(administratorEClass, ADMINISTRATOR__LAST_NAME);
		createEAttribute(administratorEClass, ADMINISTRATOR__ID);
		createEAttribute(administratorEClass, ADMINISTRATOR__FULL_NAME);

		imageEClass = createEClass(IMAGE);

		videoEClass = createEClass(VIDEO);

		// Create enums
		dataTypeEEnum = createEEnum(DATA_TYPE);
		methodTypeEEnum = createEEnum(METHOD_TYPE);
		elementTypeEEnum = createEEnum(ELEMENT_TYPE);
		displayModeEEnum = createEEnum(DISPLAY_MODE);

		// Create data types
		instantEDataType = createEDataType(INSTANT);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		refactoredWebApplicationEClass.getESuperTypes().add(this.getNamedIdentifier());
		entityEClass.getESuperTypes().add(this.getNamedIdentifier());
		attributeEClass.getESuperTypes().add(this.getNamedIdentifier());
		referenceEClass.getESuperTypes().add(this.getNamedIdentifier());
		pageEClass.getESuperTypes().add(this.getNamedIdentifier());
		contentEClass.getESuperTypes().add(this.getNamedIdentifier());
		dContentEClass.getESuperTypes().add(this.getContent());
		listEClass.getESuperTypes().add(this.getDContent());
		detailEClass.getESuperTypes().add(this.getDContent());
		sContentEClass.getESuperTypes().add(this.getContent());
		formEClass.getESuperTypes().add(this.getSContent());
		elementEClass.getESuperTypes().add(this.getNamedIdentifier());
		visualMediaEClass.getESuperTypes().add(this.getSContent());
		imageEClass.getESuperTypes().add(this.getVisualMedia());
		videoEClass.getESuperTypes().add(this.getVisualMedia());

		// Initialize classes, features, and operations; add parameters
		initEClass(refactoredWebApplicationEClass, RefactoredWebApplication.class, "RefactoredWebApplication", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRefactoredWebApplication_Entities(), this.getEntity(), null, "entities", null, 0, -1, RefactoredWebApplication.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRefactoredWebApplication_Pages(), this.getPage(), this.getPage_WebApplication(), "pages", null, 0, -1, RefactoredWebApplication.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRefactoredWebApplication_TotalPages(), ecorePackage.getEInt(), "totalPages", null, 1, 1, RefactoredWebApplication.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEAttribute(getRefactoredWebApplication_DisplayMode(), this.getDisplayMode(), "displayMode", null, 0, 1, RefactoredWebApplication.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRefactoredWebApplication_Admin(), this.getAdministrator(), null, "admin", null, 1, -1, RefactoredWebApplication.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getRefactoredWebApplication_CurrentSysAdmin(), ecorePackage.getEString(), "currentSysAdmin", null, 1, -1, RefactoredWebApplication.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		EOperation op = initEOperation(getRefactoredWebApplication__UniquePageNames__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "UniquePageNames", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		EGenericType g1 = createEGenericType(ecorePackage.getEMap());
		EGenericType g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getRefactoredWebApplication__AtLeastOnePage__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "AtLeastOnePage", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getRefactoredWebApplication__AtLeastOneEntity__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "AtLeastOneEntity", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getRefactoredWebApplication__UniqueEntityNames__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "UniqueEntityNames", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(entityEClass, Entity.class, "Entity", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEntity_Attributes(), this.getAttribute(), null, "attributes", null, 1, -1, Entity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntity_References(), this.getReference(), null, "references", null, 0, -1, Entity.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getEntity__PrimaryKeyName(), ecorePackage.getEString(), "primaryKeyName", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEntity__OnePrimaryKey__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "OnePrimaryKey", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getEntity__UniqueAttributeReferenceNames__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "UniqueAttributeReferenceNames", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(attributeEClass, Attribute.class, "Attribute", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAttribute_Type(), this.getDataType(), "type", null, 0, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAttribute_IsPK(), ecorePackage.getEBoolean(), "isPK", "false", 1, 1, Attribute.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(referenceEClass, Reference.class, "Reference", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getReference_ForeignKey(), this.getEntity(), null, "foreignKey", null, 0, -1, Reference.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(namedIdentifierEClass, NamedIdentifier.class, "NamedIdentifier", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNamedIdentifier_Name(), ecorePackage.getEString(), "name", null, 0, 1, NamedIdentifier.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getNamedIdentifier_Id(), ecorePackage.getEString(), "id", null, 0, 1, NamedIdentifier.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(pageEClass, Page.class, "Page", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPage_TotalMediaSize(), ecorePackage.getEDouble(), "totalMediaSize", null, 1, 1, Page.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getPage_Link(), this.getPage(), null, "link", null, 0, -1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPage_Contents(), this.getContent(), null, "contents", null, 0, -1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPage_WebApplication(), this.getRefactoredWebApplication(), this.getRefactoredWebApplication_Pages(), "webApplication", null, 1, 1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPage_CreatedAt(), this.getInstant(), "createdAt", null, 0, 1, Page.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getPage__IsNotEmpty(), ecorePackage.getEBooleanObject(), "isNotEmpty", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPage__GetStaticContentQty(), ecorePackage.getEBigInteger(), "getStaticContentQty", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getPage__GetDynamicContentQty(), ecorePackage.getEBigInteger(), "getDynamicContentQty", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getPage__OptimisePageLoad__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "OptimisePageLoad", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(contentEClass, Content.class, "Content", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(dContentEClass, DContent.class, "DContent", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDContent_Attributes(), this.getAttribute(), null, "attributes", null, 1, -1, DContent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDContent_Entity(), this.getEntity(), null, "entity", null, 1, 1, DContent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(listEClass, List.class, "List", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(detailEClass, Detail.class, "Detail", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(sContentEClass, SContent.class, "SContent", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(formEClass, Form.class, "Form", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getForm_Method(), this.getMethodType(), "method", null, 0, 1, Form.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getForm_Elements(), this.getElement(), this.getElement_Form(), "elements", null, 0, -1, Form.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getForm_Entity(), this.getEntity(), null, "entity", null, 1, 1, Form.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getForm__GetElementQty(), ecorePackage.getEBigInteger(), "getElementQty", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = initEOperation(getForm__AtLeastOneElement__DiagnosticChain_Map(), ecorePackage.getEBoolean(), "AtLeastOneElement", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDiagnosticChain(), "diagnostics", 0, 1, IS_UNIQUE, IS_ORDERED);
		g1 = createEGenericType(ecorePackage.getEMap());
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		g2 = createEGenericType(ecorePackage.getEJavaObject());
		g1.getETypeArguments().add(g2);
		addEParameter(op, g1, "context", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(elementEClass, Element.class, "Element", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getElement_Label(), ecorePackage.getEString(), "label", null, 0, 1, Element.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getElement_Tooltip(), ecorePackage.getEString(), "tooltip", null, 0, 1, Element.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getElement_Attribute(), this.getAttribute(), null, "attribute", null, 0, 1, Element.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getElement_Type(), this.getElementType(), "type", null, 0, 1, Element.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getElement_Form(), this.getForm(), this.getForm_Elements(), "form", null, 1, 1, Element.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(visualMediaEClass, VisualMedia.class, "VisualMedia", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVisualMedia_Source(), ecorePackage.getEString(), "source", null, 0, 1, VisualMedia.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVisualMedia_AltText(), ecorePackage.getEString(), "altText", null, 0, 1, VisualMedia.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVisualMedia_Size(), ecorePackage.getEBigDecimal(), "size", null, 1, 1, VisualMedia.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVisualMedia_MediaClassification(), ecorePackage.getEString(), "mediaClassification", null, 0, 1, VisualMedia.class, !IS_TRANSIENT, IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(administratorEClass, Administrator.class, "Administrator", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAdministrator_FirstName(), ecorePackage.getEString(), "firstName", null, 1, 1, Administrator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAdministrator_LastName(), ecorePackage.getEString(), "lastName", null, 1, 1, Administrator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAdministrator_Id(), ecorePackage.getEInt(), "id", null, 1, 1, Administrator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAdministrator_FullName(), ecorePackage.getEString(), "fullName", null, 1, 1, Administrator.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(imageEClass, Image.class, "Image", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(videoEClass, Video.class, "Video", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(dataTypeEEnum, DataType.class, "DataType");
		addEEnumLiteral(dataTypeEEnum, DataType.STRING);
		addEEnumLiteral(dataTypeEEnum, DataType.INT);
		addEEnumLiteral(dataTypeEEnum, DataType.TEXT);
		addEEnumLiteral(dataTypeEEnum, DataType.BOOL);
		addEEnumLiteral(dataTypeEEnum, DataType.DATE);
		addEEnumLiteral(dataTypeEEnum, DataType.FILE);
		addEEnumLiteral(dataTypeEEnum, DataType.CURRENCY);
		addEEnumLiteral(dataTypeEEnum, DataType.PERCENT);
		addEEnumLiteral(dataTypeEEnum, DataType.IMAGE);
		addEEnumLiteral(dataTypeEEnum, DataType.IMAGES);
		addEEnumLiteral(dataTypeEEnum, DataType.EMAIL);
		addEEnumLiteral(dataTypeEEnum, DataType.PASSWORD);

		initEEnum(methodTypeEEnum, MethodType.class, "MethodType");
		addEEnumLiteral(methodTypeEEnum, MethodType.POST);
		addEEnumLiteral(methodTypeEEnum, MethodType.PUT);

		initEEnum(elementTypeEEnum, ElementType.class, "ElementType");
		addEEnumLiteral(elementTypeEEnum, ElementType.TEXT_BOX);
		addEEnumLiteral(elementTypeEEnum, ElementType.BUTTON);
		addEEnumLiteral(elementTypeEEnum, ElementType.CHECK_BOX);
		addEEnumLiteral(elementTypeEEnum, ElementType.RADIO_BUTTON);
		addEEnumLiteral(elementTypeEEnum, ElementType.DROP_DOWN);
		addEEnumLiteral(elementTypeEEnum, ElementType.TEXT_AREA);
		addEEnumLiteral(elementTypeEEnum, ElementType.DATE);

		initEEnum(displayModeEEnum, DisplayMode.class, "DisplayMode");
		addEEnumLiteral(displayModeEEnum, DisplayMode.LIGHT);
		addEEnumLiteral(displayModeEEnum, DisplayMode.DARK);

		// Initialize data types
		initEDataType(instantEDataType, Instant.class, "Instant", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore";
		addAnnotation
		  (this,
		   source,
		   new String[] {
		   });
		addAnnotation
		  (refactoredWebApplicationEClass,
		   source,
		   new String[] {
			   "constraints", "UniqueEntityNames"
		   });
		addAnnotation
		  (entityEClass,
		   source,
		   new String[] {
			   "constraints", "UniqueAttributeReferenceNames"
		   });
		addAnnotation
		  (pageEClass,
		   source,
		   new String[] {
			   "constraints", "OptimisePageLoad"
		   });
		addAnnotation
		  (formEClass,
		   source,
		   new String[] {
			   "constraints", "AtLeastOneElement"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations() {
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";
		addAnnotation
		  (getRefactoredWebApplication__UniquePageNames__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "pages.name->asSet()->size() = pages->size()"
		   });
		addAnnotation
		  (getRefactoredWebApplication__AtLeastOnePage__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "pages->size() >= 1"
		   });
		addAnnotation
		  (getRefactoredWebApplication__AtLeastOneEntity__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "entities->size() >= 1"
		   });
		addAnnotation
		  (getRefactoredWebApplication__UniqueEntityNames__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "entities.name->asSet()->size() = entities->size()"
		   });
		addAnnotation
		  (getEntity__PrimaryKeyName(),
		   source,
		   new String[] {
			   "body", "attributes->select(e | e.isPK = true).name ->first()"
		   });
		addAnnotation
		  (getEntity__OnePrimaryKey__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "attributes->select(e | e.isPK = true)-> size() = 1"
		   });
		addAnnotation
		  (getEntity__UniqueAttributeReferenceNames__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "attributes->isUnique(x | x.name)"
		   });
		addAnnotation
		  (getPage__IsNotEmpty(),
		   source,
		   new String[] {
			   "body", "contents -> notEmpty()"
		   });
		addAnnotation
		  (getPage__GetStaticContentQty(),
		   source,
		   new String[] {
			   "body", "contents ->select( e | e.oclIsKindOf(SContent))-> size()"
		   });
		addAnnotation
		  (getPage__GetDynamicContentQty(),
		   source,
		   new String[] {
			   "body", "contents ->select( e | e.oclIsKindOf(DContent))-> size()"
		   });
		addAnnotation
		  (getPage__OptimisePageLoad__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "totalMediaSize <= 50"
		   });
		addAnnotation
		  (getForm__GetElementQty(),
		   source,
		   new String[] {
			   "body", "elements -> size()"
		   });
		addAnnotation
		  (getForm__AtLeastOneElement__DiagnosticChain_Map(),
		   source,
		   new String[] {
			   "body", "elements->size() >= 1"
		   });
	}

} //RefactoredWebPackageImpl
