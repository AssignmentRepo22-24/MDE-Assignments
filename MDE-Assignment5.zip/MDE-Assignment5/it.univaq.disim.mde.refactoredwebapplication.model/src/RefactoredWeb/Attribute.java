/**
 */
package RefactoredWeb;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RefactoredWeb.Attribute#getType <em>Type</em>}</li>
 *   <li>{@link RefactoredWeb.Attribute#isIsPK <em>Is PK</em>}</li>
 * </ul>
 *
 * @see RefactoredWeb.RefactoredWebPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends NamedIdentifier {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link RefactoredWeb.DataType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see RefactoredWeb.DataType
	 * @see #setType(DataType)
	 * @see RefactoredWeb.RefactoredWebPackage#getAttribute_Type()
	 * @model
	 * @generated
	 */
	DataType getType();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Attribute#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see RefactoredWeb.DataType
	 * @see #getType()
	 * @generated
	 */
	void setType(DataType value);

	/**
	 * Returns the value of the '<em><b>Is PK</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is PK</em>' attribute.
	 * @see #setIsPK(boolean)
	 * @see RefactoredWeb.RefactoredWebPackage#getAttribute_IsPK()
	 * @model default="false" required="true"
	 * @generated
	 */
	boolean isIsPK();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Attribute#isIsPK <em>Is PK</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is PK</em>' attribute.
	 * @see #isIsPK()
	 * @generated
	 */
	void setIsPK(boolean value);

} // Attribute
