/**
 */
package RefactoredWeb;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>List</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RefactoredWeb.RefactoredWebPackage#getList()
 * @model
 * @generated
 */
public interface List extends DContent {
} // List
