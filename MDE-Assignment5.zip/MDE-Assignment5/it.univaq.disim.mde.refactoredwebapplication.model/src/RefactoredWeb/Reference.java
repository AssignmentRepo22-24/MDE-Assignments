/**
 */
package RefactoredWeb;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reference</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RefactoredWeb.Reference#getForeignKey <em>Foreign Key</em>}</li>
 * </ul>
 *
 * @see RefactoredWeb.RefactoredWebPackage#getReference()
 * @model
 * @generated
 */
public interface Reference extends NamedIdentifier {
	/**
	 * Returns the value of the '<em><b>Foreign Key</b></em>' reference list.
	 * The list contents are of type {@link RefactoredWeb.Entity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Foreign Key</em>' reference list.
	 * @see RefactoredWeb.RefactoredWebPackage#getReference_ForeignKey()
	 * @model
	 * @generated
	 */
	EList<Entity> getForeignKey();

} // Reference
