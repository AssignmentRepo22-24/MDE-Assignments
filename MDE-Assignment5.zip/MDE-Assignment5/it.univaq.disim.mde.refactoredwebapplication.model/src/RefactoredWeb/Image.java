/**
 */
package RefactoredWeb;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RefactoredWeb.RefactoredWebPackage#getImage()
 * @model
 * @generated
 */
public interface Image extends VisualMedia {
} // Image
