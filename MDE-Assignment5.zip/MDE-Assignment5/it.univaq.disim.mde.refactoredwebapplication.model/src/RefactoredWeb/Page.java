/**
 */
package RefactoredWeb;

import java.math.BigInteger;

import java.time.Instant;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Page</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RefactoredWeb.Page#getTotalMediaSize <em>Total Media Size</em>}</li>
 *   <li>{@link RefactoredWeb.Page#getLink <em>Link</em>}</li>
 *   <li>{@link RefactoredWeb.Page#getContents <em>Contents</em>}</li>
 *   <li>{@link RefactoredWeb.Page#getWebApplication <em>Web Application</em>}</li>
 *   <li>{@link RefactoredWeb.Page#getCreatedAt <em>Created At</em>}</li>
 * </ul>
 *
 * @see RefactoredWeb.RefactoredWebPackage#getPage()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='OptimisePageLoad'"
 * @generated
 */
public interface Page extends NamedIdentifier {
	/**
	 * Returns the value of the '<em><b>Total Media Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Media Size</em>' attribute.
	 * @see #setTotalMediaSize(double)
	 * @see RefactoredWeb.RefactoredWebPackage#getPage_TotalMediaSize()
	 * @model required="true" volatile="true" derived="true"
	 * @generated
	 */
	double getTotalMediaSize();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Page#getTotalMediaSize <em>Total Media Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Media Size</em>' attribute.
	 * @see #getTotalMediaSize()
	 * @generated
	 */
	void setTotalMediaSize(double value);

	/**
	 * Returns the value of the '<em><b>Link</b></em>' reference list.
	 * The list contents are of type {@link RefactoredWeb.Page}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Link</em>' reference list.
	 * @see RefactoredWeb.RefactoredWebPackage#getPage_Link()
	 * @model
	 * @generated
	 */
	EList<Page> getLink();

	/**
	 * Returns the value of the '<em><b>Contents</b></em>' containment reference list.
	 * The list contents are of type {@link RefactoredWeb.Content}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contents</em>' containment reference list.
	 * @see RefactoredWeb.RefactoredWebPackage#getPage_Contents()
	 * @model containment="true"
	 * @generated
	 */
	EList<Content> getContents();

	/**
	 * Returns the value of the '<em><b>Web Application</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link RefactoredWeb.RefactoredWebApplication#getPages <em>Pages</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Web Application</em>' container reference.
	 * @see #setWebApplication(RefactoredWebApplication)
	 * @see RefactoredWeb.RefactoredWebPackage#getPage_WebApplication()
	 * @see RefactoredWeb.RefactoredWebApplication#getPages
	 * @model opposite="pages" required="true" transient="false"
	 * @generated
	 */
	RefactoredWebApplication getWebApplication();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Page#getWebApplication <em>Web Application</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Web Application</em>' container reference.
	 * @see #getWebApplication()
	 * @generated
	 */
	void setWebApplication(RefactoredWebApplication value);

	/**
	 * Returns the value of the '<em><b>Created At</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Created At</em>' attribute.
	 * @see #setCreatedAt(Instant)
	 * @see RefactoredWeb.RefactoredWebPackage#getPage_CreatedAt()
	 * @model dataType="RefactoredWeb.Instant"
	 * @generated
	 */
	Instant getCreatedAt();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Page#getCreatedAt <em>Created At</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Created At</em>' attribute.
	 * @see #getCreatedAt()
	 * @generated
	 */
	void setCreatedAt(Instant value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='contents -&gt; notEmpty()'"
	 * @generated
	 */
	Boolean isNotEmpty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='contents -&gt;select( e | e.oclIsKindOf(SContent))-&gt; size()'"
	 * @generated
	 */
	BigInteger getStaticContentQty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='contents -&gt;select( e | e.oclIsKindOf(DContent))-&gt; size()'"
	 * @generated
	 */
	BigInteger getDynamicContentQty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='totalMediaSize &lt;= 50'"
	 * @generated
	 */
	boolean OptimisePageLoad(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Page
