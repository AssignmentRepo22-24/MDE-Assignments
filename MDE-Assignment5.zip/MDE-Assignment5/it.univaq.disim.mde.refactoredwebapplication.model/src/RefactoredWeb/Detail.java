/**
 */
package RefactoredWeb;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Detail</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see RefactoredWeb.RefactoredWebPackage#getDetail()
 * @model
 * @generated
 */
public interface Detail extends DContent {
} // Detail
