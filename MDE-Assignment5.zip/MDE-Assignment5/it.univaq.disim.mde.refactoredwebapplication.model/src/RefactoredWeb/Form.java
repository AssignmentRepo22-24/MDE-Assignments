/**
 */
package RefactoredWeb;

import java.math.BigInteger;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Form</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RefactoredWeb.Form#getMethod <em>Method</em>}</li>
 *   <li>{@link RefactoredWeb.Form#getElements <em>Elements</em>}</li>
 *   <li>{@link RefactoredWeb.Form#getEntity <em>Entity</em>}</li>
 * </ul>
 *
 * @see RefactoredWeb.RefactoredWebPackage#getForm()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='AtLeastOneElement'"
 * @generated
 */
public interface Form extends SContent {
	/**
	 * Returns the value of the '<em><b>Method</b></em>' attribute.
	 * The literals are from the enumeration {@link RefactoredWeb.MethodType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Method</em>' attribute.
	 * @see RefactoredWeb.MethodType
	 * @see #setMethod(MethodType)
	 * @see RefactoredWeb.RefactoredWebPackage#getForm_Method()
	 * @model
	 * @generated
	 */
	MethodType getMethod();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Form#getMethod <em>Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Method</em>' attribute.
	 * @see RefactoredWeb.MethodType
	 * @see #getMethod()
	 * @generated
	 */
	void setMethod(MethodType value);

	/**
	 * Returns the value of the '<em><b>Elements</b></em>' containment reference list.
	 * The list contents are of type {@link RefactoredWeb.Element}.
	 * It is bidirectional and its opposite is '{@link RefactoredWeb.Element#getForm <em>Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Elements</em>' containment reference list.
	 * @see RefactoredWeb.RefactoredWebPackage#getForm_Elements()
	 * @see RefactoredWeb.Element#getForm
	 * @model opposite="form" containment="true"
	 * @generated
	 */
	EList<Element> getElements();

	/**
	 * Returns the value of the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entity</em>' reference.
	 * @see #setEntity(Entity)
	 * @see RefactoredWeb.RefactoredWebPackage#getForm_Entity()
	 * @model required="true"
	 * @generated
	 */
	Entity getEntity();

	/**
	 * Sets the value of the '{@link RefactoredWeb.Form#getEntity <em>Entity</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entity</em>' reference.
	 * @see #getEntity()
	 * @generated
	 */
	void setEntity(Entity value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='elements -&gt; size()'"
	 * @generated
	 */
	BigInteger getElementQty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='elements-&gt;size() &gt;= 1'"
	 * @generated
	 */
	boolean AtLeastOneElement(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Form
