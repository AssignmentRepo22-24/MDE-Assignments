/**
 */
package RefactoredWeb;

import java.math.BigDecimal;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Visual Media</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link RefactoredWeb.VisualMedia#getSource <em>Source</em>}</li>
 *   <li>{@link RefactoredWeb.VisualMedia#getAltText <em>Alt Text</em>}</li>
 *   <li>{@link RefactoredWeb.VisualMedia#getSize <em>Size</em>}</li>
 *   <li>{@link RefactoredWeb.VisualMedia#getMediaClassification <em>Media Classification</em>}</li>
 * </ul>
 *
 * @see RefactoredWeb.RefactoredWebPackage#getVisualMedia()
 * @model abstract="true"
 * @generated
 */
public interface VisualMedia extends SContent {
	/**
	 * Returns the value of the '<em><b>Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' attribute.
	 * @see #setSource(String)
	 * @see RefactoredWeb.RefactoredWebPackage#getVisualMedia_Source()
	 * @model
	 * @generated
	 */
	String getSource();

	/**
	 * Sets the value of the '{@link RefactoredWeb.VisualMedia#getSource <em>Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' attribute.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(String value);

	/**
	 * Returns the value of the '<em><b>Alt Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Alt Text</em>' attribute.
	 * @see #setAltText(String)
	 * @see RefactoredWeb.RefactoredWebPackage#getVisualMedia_AltText()
	 * @model
	 * @generated
	 */
	String getAltText();

	/**
	 * Sets the value of the '{@link RefactoredWeb.VisualMedia#getAltText <em>Alt Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Alt Text</em>' attribute.
	 * @see #getAltText()
	 * @generated
	 */
	void setAltText(String value);

	/**
	 * Returns the value of the '<em><b>Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Size</em>' attribute.
	 * @see #setSize(BigDecimal)
	 * @see RefactoredWeb.RefactoredWebPackage#getVisualMedia_Size()
	 * @model required="true"
	 * @generated
	 */
	BigDecimal getSize();

	/**
	 * Sets the value of the '{@link RefactoredWeb.VisualMedia#getSize <em>Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Size</em>' attribute.
	 * @see #getSize()
	 * @generated
	 */
	void setSize(BigDecimal value);

	/**
	 * Returns the value of the '<em><b>Media Classification</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media Classification</em>' attribute.
	 * @see #setMediaClassification(String)
	 * @see RefactoredWeb.RefactoredWebPackage#getVisualMedia_MediaClassification()
	 * @model volatile="true" derived="true"
	 * @generated
	 */
	String getMediaClassification();

	/**
	 * Sets the value of the '{@link RefactoredWeb.VisualMedia#getMediaClassification <em>Media Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Media Classification</em>' attribute.
	 * @see #getMediaClassification()
	 * @generated
	 */
	void setMediaClassification(String value);

} // VisualMedia
