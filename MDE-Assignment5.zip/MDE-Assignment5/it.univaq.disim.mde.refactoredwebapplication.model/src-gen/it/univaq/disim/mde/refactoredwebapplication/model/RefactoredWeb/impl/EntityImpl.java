/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl;

import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebTables;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Reference;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.TypeId;

import org.eclipse.ocl.pivot.library.collection.CollectionSizeOperation;
import org.eclipse.ocl.pivot.library.collection.OrderedCollectionFirstOperation;

import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;

import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.OrderedSetValue;

import org.eclipse.ocl.pivot.values.OrderedSetValue.Accumulator;

import org.eclipse.ocl.pivot.values.SequenceValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entity</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.EntityImpl#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.EntityImpl#getReferences <em>References</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EntityImpl extends NamedIdentifierImpl implements Entity {
	/**
	 * The cached value of the '{@link #getAttributes() <em>Attributes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributes()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attributes;

	/**
	 * The cached value of the '{@link #getReferences() <em>References</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReferences()
	 * @generated
	 * @ordered
	 */
	protected EList<Reference> references;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RefactoredWebPackage.Literals.ENTITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attribute> getAttributes() {
		if (attributes == null) {
			attributes = new EObjectContainmentEList<Attribute>(Attribute.class, this,
					RefactoredWebPackage.ENTITY__ATTRIBUTES);
		}
		return attributes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Reference> getReferences() {
		if (references == null) {
			references = new EObjectContainmentEList<Reference>(Reference.class, this,
					RefactoredWebPackage.ENTITY__REFERENCES);
		}
		return references;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String primaryKeyName() {
		/**
		 * attributes->select(e | e.isPK = true).name->first()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ List<Attribute> attributes = this.getAttributes();
		final /*@NonInvalid*/ OrderedSetValue BOXED_attributes = idResolver
				.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Attribute, attributes);
		/*@Thrown*/ Accumulator accumulator = ValueUtil
				.createOrderedSetAccumulatorValue(RefactoredWebTables.ORD_CLSSid_Attribute);
		Iterator<Object> ITERATOR_e_0 = BOXED_attributes.iterator();
		/*@NonInvalid*/ OrderedSetValue select;
		while (true) {
			if (!ITERATOR_e_0.hasNext()) {
				select = accumulator;
				break;
			}
			/*@NonInvalid*/ Attribute e_0 = (Attribute) ITERATOR_e_0.next();
			/**
			 * e.isPK
			 */
			final /*@NonInvalid*/ boolean isPK = e_0.isIsPK();
			//
			if (isPK) {
				accumulator.add(e_0);
			}
		}
		/*@Thrown*/ org.eclipse.ocl.pivot.values.SequenceValue.Accumulator accumulator_0 = ValueUtil
				.createSequenceAccumulatorValue(RefactoredWebTables.SEQ_PRIMid_String);
		Iterator<Object> ITERATOR__1 = select.iterator();
		/*@Thrown*/ SequenceValue collect;
		while (true) {
			if (!ITERATOR__1.hasNext()) {
				collect = accumulator_0;
				break;
			}
			/*@NonInvalid*/ Attribute _1 = (Attribute) ITERATOR__1.next();
			/**
			 * name
			 */
			final /*@NonInvalid*/ String name = _1.getName();
			//
			accumulator_0.add(name);
		}
		final /*@Thrown*/ String first = (String) OrderedCollectionFirstOperation.INSTANCE.evaluate(collect);
		return first;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean OnePrimaryKey(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "Entity::OnePrimaryKey";
		try {
			/**
			 *
			 * inv OnePrimaryKey:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let
			 *         result : Boolean[1] = attributes->select(e | e.isPK = true)
			 *         ->size() = 1
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor,
					RefactoredWebPackage.Literals.ENTITY___ONE_PRIMARY_KEY__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE
					.evaluate(executor, severity_0, RefactoredWebTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean local_0;
			if (le) {
				local_0 = true;
			} else {
				final /*@NonInvalid*/ List<Attribute> attributes = this.getAttributes();
				final /*@NonInvalid*/ OrderedSetValue BOXED_attributes = idResolver
						.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Attribute, attributes);
				/*@Thrown*/ Accumulator accumulator = ValueUtil
						.createOrderedSetAccumulatorValue(RefactoredWebTables.ORD_CLSSid_Attribute);
				Iterator<Object> ITERATOR_e_0 = BOXED_attributes.iterator();
				/*@NonInvalid*/ OrderedSetValue select;
				while (true) {
					if (!ITERATOR_e_0.hasNext()) {
						select = accumulator;
						break;
					}
					/*@NonInvalid*/ Attribute e_0 = (Attribute) ITERATOR_e_0.next();
					/**
					 * e.isPK
					 */
					final /*@NonInvalid*/ boolean isPK = e_0.isIsPK();
					//
					if (isPK) {
						accumulator.add(e_0);
					}
				}
				final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(select);
				final /*@NonInvalid*/ boolean result = size.equals(RefactoredWebTables.INT_1);
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE
						.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object) null, diagnostics, context,
								(Object) null, severity_0, result, RefactoredWebTables.INT_0)
						.booleanValue();
				local_0 = logDiagnostic;
			}
			return local_0;
		} catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean UniqueAttributeReferenceNames(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "Entity::UniqueAttributeReferenceNames";
		try {
			/**
			 *
			 * inv UniqueAttributeReferenceNames:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = attributes->isUnique(x | x.name)
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor,
					RefactoredWebPackage.Literals.ENTITY___UNIQUE_ATTRIBUTE_REFERENCE_NAMES__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE
					.evaluate(executor, severity_0, RefactoredWebTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean local_0;
			if (le) {
				local_0 = true;
			} else {
				/*@Caught*/ Object CAUGHT_result;
				try {
					final /*@NonInvalid*/ List<Attribute> attributes = this.getAttributes();
					final /*@NonInvalid*/ OrderedSetValue BOXED_attributes = idResolver
							.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Attribute, attributes);
					/*@Thrown*/ org.eclipse.ocl.pivot.values.SetValue.Accumulator accumulator = ValueUtil
							.createSetAccumulatorValue(RefactoredWebTables.ORD_CLSSid_Attribute);
					Iterator<Object> ITERATOR_x = BOXED_attributes.iterator();
					/*@Thrown*/ boolean result;
					while (true) {
						if (!ITERATOR_x.hasNext()) {
							result = true;
							break;
						}
						/*@NonInvalid*/ Attribute x = (Attribute) ITERATOR_x.next();
						/**
						 * x.name
						 */
						final /*@NonInvalid*/ String name = x.getName();
						//
						if (accumulator.includes(name) == ValueUtil.TRUE_VALUE) {
							result = false;
							break; // Abort after second find
						} else {
							accumulator.add(name);
						}
					}
					CAUGHT_result = result;
				} catch (Exception e) {
					CAUGHT_result = ValueUtil.createInvalidValue(e);
				}
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE
						.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object) null, diagnostics, context,
								(Object) null, severity_0, CAUGHT_result, RefactoredWebTables.INT_0)
						.booleanValue();
				local_0 = logDiagnostic;
			}
			return local_0;
		} catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RefactoredWebPackage.ENTITY__ATTRIBUTES:
			return ((InternalEList<?>) getAttributes()).basicRemove(otherEnd, msgs);
		case RefactoredWebPackage.ENTITY__REFERENCES:
			return ((InternalEList<?>) getReferences()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RefactoredWebPackage.ENTITY__ATTRIBUTES:
			return getAttributes();
		case RefactoredWebPackage.ENTITY__REFERENCES:
			return getReferences();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RefactoredWebPackage.ENTITY__ATTRIBUTES:
			getAttributes().clear();
			getAttributes().addAll((Collection<? extends Attribute>) newValue);
			return;
		case RefactoredWebPackage.ENTITY__REFERENCES:
			getReferences().clear();
			getReferences().addAll((Collection<? extends Reference>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RefactoredWebPackage.ENTITY__ATTRIBUTES:
			getAttributes().clear();
			return;
		case RefactoredWebPackage.ENTITY__REFERENCES:
			getReferences().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RefactoredWebPackage.ENTITY__ATTRIBUTES:
			return attributes != null && !attributes.isEmpty();
		case RefactoredWebPackage.ENTITY__REFERENCES:
			return references != null && !references.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RefactoredWebPackage.ENTITY___PRIMARY_KEY_NAME:
			return primaryKeyName();
		case RefactoredWebPackage.ENTITY___ONE_PRIMARY_KEY__DIAGNOSTICCHAIN_MAP:
			return OnePrimaryKey((DiagnosticChain) arguments.get(0), (Map<Object, Object>) arguments.get(1));
		case RefactoredWebPackage.ENTITY___UNIQUE_ATTRIBUTE_REFERENCE_NAMES__DIAGNOSTICCHAIN_MAP:
			return UniqueAttributeReferenceNames((DiagnosticChain) arguments.get(0),
					(Map<Object, Object>) arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

} //EntityImpl
