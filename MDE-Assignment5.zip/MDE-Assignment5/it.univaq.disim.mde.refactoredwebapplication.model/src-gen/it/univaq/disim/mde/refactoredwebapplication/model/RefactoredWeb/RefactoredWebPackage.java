/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore"
 * @generated
 */
public interface RefactoredWebPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "RefactoredWeb";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "https://it.univaq.disim.mde/refactoredweb";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "RefactoredWeb";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	RefactoredWebPackage eINSTANCE = it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl
			.init();

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.NamedIdentifierImpl <em>Named Identifier</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.NamedIdentifierImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getNamedIdentifier()
	 * @generated
	 */
	int NAMED_IDENTIFIER = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_IDENTIFIER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_IDENTIFIER__ID = 1;

	/**
	 * The number of structural features of the '<em>Named Identifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_IDENTIFIER_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Named Identifier</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int NAMED_IDENTIFIER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebApplicationImpl <em>Application</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebApplicationImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getRefactoredWebApplication()
	 * @generated
	 */
	int REFACTORED_WEB_APPLICATION = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The feature id for the '<em><b>Entities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__ENTITIES = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Pages</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__PAGES = NAMED_IDENTIFIER_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Total Pages</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__TOTAL_PAGES = NAMED_IDENTIFIER_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Display Mode</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__DISPLAY_MODE = NAMED_IDENTIFIER_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Admin</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__ADMIN = NAMED_IDENTIFIER_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Current Sys Admin</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION__CURRENT_SYS_ADMIN = NAMED_IDENTIFIER_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Application</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 6;

	/**
	 * The operation id for the '<em>Unique Page Names</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION___UNIQUE_PAGE_NAMES__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>At Least One Page</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION___AT_LEAST_ONE_PAGE__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>At Least One Entity</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION___AT_LEAST_ONE_ENTITY__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Unique Entity Names</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION___UNIQUE_ENTITY_NAMES__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 3;

	/**
	 * The number of operations of the '<em>Application</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFACTORED_WEB_APPLICATION_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 4;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.EntityImpl <em>Entity</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.EntityImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getEntity()
	 * @generated
	 */
	int ENTITY = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__ATTRIBUTES = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>References</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY__REFERENCES = NAMED_IDENTIFIER_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 2;

	/**
	 * The operation id for the '<em>Primary Key Name</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY___PRIMARY_KEY_NAME = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>One Primary Key</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY___ONE_PRIMARY_KEY__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Unique Attribute Reference Names</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY___UNIQUE_ATTRIBUTE_REFERENCE_NAMES__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 2;

	/**
	 * The number of operations of the '<em>Entity</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ENTITY_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 3;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AttributeImpl <em>Attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AttributeImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getAttribute()
	 * @generated
	 */
	int ATTRIBUTE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__TYPE = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Is PK</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE__IS_PK = NAMED_IDENTIFIER_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ATTRIBUTE_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ReferenceImpl <em>Reference</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ReferenceImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getReference()
	 * @generated
	 */
	int REFERENCE = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The feature id for the '<em><b>Foreign Key</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE__FOREIGN_KEY = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Reference</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REFERENCE_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl <em>Page</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getPage()
	 * @generated
	 */
	int PAGE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The feature id for the '<em><b>Total Media Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__TOTAL_MEDIA_SIZE = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Link</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__LINK = NAMED_IDENTIFIER_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Contents</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__CONTENTS = NAMED_IDENTIFIER_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Web Application</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__WEB_APPLICATION = NAMED_IDENTIFIER_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Created At</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE__CREATED_AT = NAMED_IDENTIFIER_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Page</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 5;

	/**
	 * The operation id for the '<em>Is Not Empty</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE___IS_NOT_EMPTY = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>Get Static Content Qty</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE___GET_STATIC_CONTENT_QTY = NAMED_IDENTIFIER_OPERATION_COUNT + 1;

	/**
	 * The operation id for the '<em>Get Dynamic Content Qty</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE___GET_DYNAMIC_CONTENT_QTY = NAMED_IDENTIFIER_OPERATION_COUNT + 2;

	/**
	 * The operation id for the '<em>Optimise Page Load</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE___OPTIMISE_PAGE_LOAD__DIAGNOSTICCHAIN_MAP = NAMED_IDENTIFIER_OPERATION_COUNT + 3;

	/**
	 * The number of operations of the '<em>Page</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PAGE_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 4;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ContentImpl <em>Content</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ContentImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getContent()
	 * @generated
	 */
	int CONTENT = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The number of structural features of the '<em>Content</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Content</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONTENT_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DContentImpl <em>DContent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DContentImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDContent()
	 * @generated
	 */
	int DCONTENT = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DCONTENT__NAME = CONTENT__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DCONTENT__ID = CONTENT__ID;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DCONTENT__ATTRIBUTES = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DCONTENT__ENTITY = CONTENT_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>DContent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DCONTENT_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>DContent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DCONTENT_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ListImpl <em>List</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ListImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getList()
	 * @generated
	 */
	int LIST = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__NAME = DCONTENT__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__ID = DCONTENT__ID;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__ATTRIBUTES = DCONTENT__ATTRIBUTES;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST__ENTITY = DCONTENT__ENTITY;

	/**
	 * The number of structural features of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_FEATURE_COUNT = DCONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>List</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LIST_OPERATION_COUNT = DCONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DetailImpl <em>Detail</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DetailImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDetail()
	 * @generated
	 */
	int DETAIL = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETAIL__NAME = DCONTENT__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETAIL__ID = DCONTENT__ID;

	/**
	 * The feature id for the '<em><b>Attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETAIL__ATTRIBUTES = DCONTENT__ATTRIBUTES;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETAIL__ENTITY = DCONTENT__ENTITY;

	/**
	 * The number of structural features of the '<em>Detail</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETAIL_FEATURE_COUNT = DCONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Detail</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DETAIL_OPERATION_COUNT = DCONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.SContentImpl <em>SContent</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.SContentImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getSContent()
	 * @generated
	 */
	int SCONTENT = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCONTENT__NAME = CONTENT__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCONTENT__ID = CONTENT__ID;

	/**
	 * The number of structural features of the '<em>SContent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCONTENT_FEATURE_COUNT = CONTENT_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>SContent</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SCONTENT_OPERATION_COUNT = CONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.FormImpl <em>Form</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.FormImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getForm()
	 * @generated
	 */
	int FORM = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM__NAME = SCONTENT__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM__ID = SCONTENT__ID;

	/**
	 * The feature id for the '<em><b>Method</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM__METHOD = SCONTENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Elements</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM__ELEMENTS = SCONTENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Entity</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM__ENTITY = SCONTENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM_FEATURE_COUNT = SCONTENT_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Get Element Qty</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM___GET_ELEMENT_QTY = SCONTENT_OPERATION_COUNT + 0;

	/**
	 * The operation id for the '<em>At Least One Element</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM___AT_LEAST_ONE_ELEMENT__DIAGNOSTICCHAIN_MAP = SCONTENT_OPERATION_COUNT + 1;

	/**
	 * The number of operations of the '<em>Form</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FORM_OPERATION_COUNT = SCONTENT_OPERATION_COUNT + 2;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ElementImpl <em>Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ElementImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getElement()
	 * @generated
	 */
	int ELEMENT = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__NAME = NAMED_IDENTIFIER__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__ID = NAMED_IDENTIFIER__ID;

	/**
	 * The feature id for the '<em><b>Label</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__LABEL = NAMED_IDENTIFIER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Tooltip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__TOOLTIP = NAMED_IDENTIFIER_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Attribute</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__ATTRIBUTE = NAMED_IDENTIFIER_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__TYPE = NAMED_IDENTIFIER_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Form</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT__FORM = NAMED_IDENTIFIER_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_FEATURE_COUNT = NAMED_IDENTIFIER_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_OPERATION_COUNT = NAMED_IDENTIFIER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl <em>Visual Media</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getVisualMedia()
	 * @generated
	 */
	int VISUAL_MEDIA = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA__NAME = SCONTENT__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA__ID = SCONTENT__ID;

	/**
	 * The feature id for the '<em><b>Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA__SOURCE = SCONTENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Alt Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA__ALT_TEXT = SCONTENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA__SIZE = SCONTENT_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Media Classification</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA__MEDIA_CLASSIFICATION = SCONTENT_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Visual Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA_FEATURE_COUNT = SCONTENT_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Visual Media</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VISUAL_MEDIA_OPERATION_COUNT = SCONTENT_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AdministratorImpl <em>Administrator</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AdministratorImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getAdministrator()
	 * @generated
	 */
	int ADMINISTRATOR = 14;

	/**
	 * The feature id for the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADMINISTRATOR__FIRST_NAME = 0;

	/**
	 * The feature id for the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADMINISTRATOR__LAST_NAME = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADMINISTRATOR__ID = 2;

	/**
	 * The feature id for the '<em><b>Full Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADMINISTRATOR__FULL_NAME = 3;

	/**
	 * The number of structural features of the '<em>Administrator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADMINISTRATOR_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Administrator</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADMINISTRATOR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ImageImpl <em>Image</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ImageImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getImage()
	 * @generated
	 */
	int IMAGE = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__NAME = VISUAL_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__ID = VISUAL_MEDIA__ID;

	/**
	 * The feature id for the '<em><b>Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__SOURCE = VISUAL_MEDIA__SOURCE;

	/**
	 * The feature id for the '<em><b>Alt Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__ALT_TEXT = VISUAL_MEDIA__ALT_TEXT;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__SIZE = VISUAL_MEDIA__SIZE;

	/**
	 * The feature id for the '<em><b>Media Classification</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__MEDIA_CLASSIFICATION = VISUAL_MEDIA__MEDIA_CLASSIFICATION;

	/**
	 * The number of structural features of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_FEATURE_COUNT = VISUAL_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_OPERATION_COUNT = VISUAL_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VideoImpl <em>Video</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VideoImpl
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getVideo()
	 * @generated
	 */
	int VIDEO = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO__NAME = VISUAL_MEDIA__NAME;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO__ID = VISUAL_MEDIA__ID;

	/**
	 * The feature id for the '<em><b>Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO__SOURCE = VISUAL_MEDIA__SOURCE;

	/**
	 * The feature id for the '<em><b>Alt Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO__ALT_TEXT = VISUAL_MEDIA__ALT_TEXT;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO__SIZE = VISUAL_MEDIA__SIZE;

	/**
	 * The feature id for the '<em><b>Media Classification</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO__MEDIA_CLASSIFICATION = VISUAL_MEDIA__MEDIA_CLASSIFICATION;

	/**
	 * The number of structural features of the '<em>Video</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_FEATURE_COUNT = VISUAL_MEDIA_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Video</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VIDEO_OPERATION_COUNT = VISUAL_MEDIA_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DataType <em>Data Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DataType
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDataType()
	 * @generated
	 */
	int DATA_TYPE = 17;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.MethodType <em>Method Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.MethodType
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getMethodType()
	 * @generated
	 */
	int METHOD_TYPE = 18;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.ElementType <em>Element Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.ElementType
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getElementType()
	 * @generated
	 */
	int ELEMENT_TYPE = 19;

	/**
	 * The meta object id for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode <em>Display Mode</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDisplayMode()
	 * @generated
	 */
	int DISPLAY_MODE = 20;

	/**
	 * The meta object id for the '<em>Instant</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.time.Instant
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getInstant()
	 * @generated
	 */
	int INSTANT = 21;

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication <em>Application</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Application</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication
	 * @generated
	 */
	EClass getRefactoredWebApplication();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getEntities <em>Entities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Entities</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getEntities()
	 * @see #getRefactoredWebApplication()
	 * @generated
	 */
	EReference getRefactoredWebApplication_Entities();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getPages <em>Pages</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Pages</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getPages()
	 * @see #getRefactoredWebApplication()
	 * @generated
	 */
	EReference getRefactoredWebApplication_Pages();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getTotalPages <em>Total Pages</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Pages</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getTotalPages()
	 * @see #getRefactoredWebApplication()
	 * @generated
	 */
	EAttribute getRefactoredWebApplication_TotalPages();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getDisplayMode <em>Display Mode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Display Mode</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getDisplayMode()
	 * @see #getRefactoredWebApplication()
	 * @generated
	 */
	EAttribute getRefactoredWebApplication_DisplayMode();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getAdmin <em>Admin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Admin</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getAdmin()
	 * @see #getRefactoredWebApplication()
	 * @generated
	 */
	EReference getRefactoredWebApplication_Admin();

	/**
	 * Returns the meta object for the attribute list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getCurrentSysAdmin <em>Current Sys Admin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Current Sys Admin</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getCurrentSysAdmin()
	 * @see #getRefactoredWebApplication()
	 * @generated
	 */
	EAttribute getRefactoredWebApplication_CurrentSysAdmin();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#UniquePageNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Page Names</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Page Names</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#UniquePageNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getRefactoredWebApplication__UniquePageNames__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#AtLeastOnePage(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Page</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>At Least One Page</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#AtLeastOnePage(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getRefactoredWebApplication__AtLeastOnePage__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#AtLeastOneEntity(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Entity</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>At Least One Entity</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#AtLeastOneEntity(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getRefactoredWebApplication__AtLeastOneEntity__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#UniqueEntityNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Entity Names</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Entity Names</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#UniqueEntityNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getRefactoredWebApplication__UniqueEntityNames__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity <em>Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Entity</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity
	 * @generated
	 */
	EClass getEntity();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Attributes</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#getAttributes()
	 * @see #getEntity()
	 * @generated
	 */
	EReference getEntity_Attributes();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#getReferences <em>References</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>References</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#getReferences()
	 * @see #getEntity()
	 * @generated
	 */
	EReference getEntity_References();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#primaryKeyName() <em>Primary Key Name</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Primary Key Name</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#primaryKeyName()
	 * @generated
	 */
	EOperation getEntity__PrimaryKeyName();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#OnePrimaryKey(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>One Primary Key</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>One Primary Key</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#OnePrimaryKey(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getEntity__OnePrimaryKey__DiagnosticChain_Map();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#UniqueAttributeReferenceNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Attribute Reference Names</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Unique Attribute Reference Names</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity#UniqueAttributeReferenceNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getEntity__UniqueAttributeReferenceNames__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Attribute</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute
	 * @generated
	 */
	EClass getAttribute();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute#getType()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_Type();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute#isIsPK <em>Is PK</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is PK</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Attribute#isIsPK()
	 * @see #getAttribute()
	 * @generated
	 */
	EAttribute getAttribute_IsPK();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Reference <em>Reference</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reference</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Reference
	 * @generated
	 */
	EClass getReference();

	/**
	 * Returns the meta object for the reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Reference#getForeignKey <em>Foreign Key</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Foreign Key</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Reference#getForeignKey()
	 * @see #getReference()
	 * @generated
	 */
	EReference getReference_ForeignKey();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.NamedIdentifier <em>Named Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Named Identifier</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.NamedIdentifier
	 * @generated
	 */
	EClass getNamedIdentifier();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.NamedIdentifier#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.NamedIdentifier#getName()
	 * @see #getNamedIdentifier()
	 * @generated
	 */
	EAttribute getNamedIdentifier_Name();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.NamedIdentifier#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.NamedIdentifier#getId()
	 * @see #getNamedIdentifier()
	 * @generated
	 */
	EAttribute getNamedIdentifier_Id();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page <em>Page</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Page</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page
	 * @generated
	 */
	EClass getPage();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getTotalMediaSize <em>Total Media Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Media Size</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getTotalMediaSize()
	 * @see #getPage()
	 * @generated
	 */
	EAttribute getPage_TotalMediaSize();

	/**
	 * Returns the meta object for the reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getLink <em>Link</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Link</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getLink()
	 * @see #getPage()
	 * @generated
	 */
	EReference getPage_Link();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getContents <em>Contents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Contents</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getContents()
	 * @see #getPage()
	 * @generated
	 */
	EReference getPage_Contents();

	/**
	 * Returns the meta object for the container reference '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getWebApplication <em>Web Application</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Web Application</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getWebApplication()
	 * @see #getPage()
	 * @generated
	 */
	EReference getPage_WebApplication();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getCreatedAt <em>Created At</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Created At</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getCreatedAt()
	 * @see #getPage()
	 * @generated
	 */
	EAttribute getPage_CreatedAt();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#isNotEmpty() <em>Is Not Empty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Is Not Empty</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#isNotEmpty()
	 * @generated
	 */
	EOperation getPage__IsNotEmpty();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getStaticContentQty() <em>Get Static Content Qty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Static Content Qty</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getStaticContentQty()
	 * @generated
	 */
	EOperation getPage__GetStaticContentQty();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getDynamicContentQty() <em>Get Dynamic Content Qty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Dynamic Content Qty</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getDynamicContentQty()
	 * @generated
	 */
	EOperation getPage__GetDynamicContentQty();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#OptimisePageLoad(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Optimise Page Load</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Optimise Page Load</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#OptimisePageLoad(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getPage__OptimisePageLoad__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Content <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Content</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Content
	 * @generated
	 */
	EClass getContent();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DContent <em>DContent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DContent</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DContent
	 * @generated
	 */
	EClass getDContent();

	/**
	 * Returns the meta object for the reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DContent#getAttributes <em>Attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Attributes</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DContent#getAttributes()
	 * @see #getDContent()
	 * @generated
	 */
	EReference getDContent_Attributes();

	/**
	 * Returns the meta object for the reference '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DContent#getEntity <em>Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Entity</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DContent#getEntity()
	 * @see #getDContent()
	 * @generated
	 */
	EReference getDContent_Entity();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.List <em>List</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>List</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.List
	 * @generated
	 */
	EClass getList();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Detail <em>Detail</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Detail</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Detail
	 * @generated
	 */
	EClass getDetail();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.SContent <em>SContent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>SContent</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.SContent
	 * @generated
	 */
	EClass getSContent();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form <em>Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Form</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form
	 * @generated
	 */
	EClass getForm();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getMethod <em>Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Method</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getMethod()
	 * @see #getForm()
	 * @generated
	 */
	EAttribute getForm_Method();

	/**
	 * Returns the meta object for the containment reference list '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getElements <em>Elements</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Elements</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getElements()
	 * @see #getForm()
	 * @generated
	 */
	EReference getForm_Elements();

	/**
	 * Returns the meta object for the reference '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getEntity <em>Entity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Entity</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getEntity()
	 * @see #getForm()
	 * @generated
	 */
	EReference getForm_Entity();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getElementQty() <em>Get Element Qty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Get Element Qty</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#getElementQty()
	 * @generated
	 */
	EOperation getForm__GetElementQty();

	/**
	 * Returns the meta object for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#AtLeastOneElement(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Element</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>At Least One Element</em>' operation.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Form#AtLeastOneElement(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	EOperation getForm__AtLeastOneElement__DiagnosticChain_Map();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element <em>Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Element</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element
	 * @generated
	 */
	EClass getElement();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Label</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getLabel()
	 * @see #getElement()
	 * @generated
	 */
	EAttribute getElement_Label();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getTooltip <em>Tooltip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tooltip</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getTooltip()
	 * @see #getElement()
	 * @generated
	 */
	EAttribute getElement_Tooltip();

	/**
	 * Returns the meta object for the reference '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getAttribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Attribute</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getAttribute()
	 * @see #getElement()
	 * @generated
	 */
	EReference getElement_Attribute();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getType()
	 * @see #getElement()
	 * @generated
	 */
	EAttribute getElement_Type();

	/**
	 * Returns the meta object for the container reference '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getForm <em>Form</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Form</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Element#getForm()
	 * @see #getElement()
	 * @generated
	 */
	EReference getElement_Form();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia <em>Visual Media</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Visual Media</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia
	 * @generated
	 */
	EClass getVisualMedia();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getSource <em>Source</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Source</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getSource()
	 * @see #getVisualMedia()
	 * @generated
	 */
	EAttribute getVisualMedia_Source();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getAltText <em>Alt Text</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Alt Text</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getAltText()
	 * @see #getVisualMedia()
	 * @generated
	 */
	EAttribute getVisualMedia_AltText();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getSize <em>Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Size</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getSize()
	 * @see #getVisualMedia()
	 * @generated
	 */
	EAttribute getVisualMedia_Size();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getMediaClassification <em>Media Classification</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Media Classification</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia#getMediaClassification()
	 * @see #getVisualMedia()
	 * @generated
	 */
	EAttribute getVisualMedia_MediaClassification();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator <em>Administrator</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Administrator</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator
	 * @generated
	 */
	EClass getAdministrator();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFirstName <em>First Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>First Name</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFirstName()
	 * @see #getAdministrator()
	 * @generated
	 */
	EAttribute getAdministrator_FirstName();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getLastName <em>Last Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Name</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getLastName()
	 * @see #getAdministrator()
	 * @generated
	 */
	EAttribute getAdministrator_LastName();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getId()
	 * @see #getAdministrator()
	 * @generated
	 */
	EAttribute getAdministrator_Id();

	/**
	 * Returns the meta object for the attribute '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFullName <em>Full Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Full Name</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFullName()
	 * @see #getAdministrator()
	 * @generated
	 */
	EAttribute getAdministrator_FullName();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Image</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Image
	 * @generated
	 */
	EClass getImage();

	/**
	 * Returns the meta object for class '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Video <em>Video</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Video</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Video
	 * @generated
	 */
	EClass getVideo();

	/**
	 * Returns the meta object for enum '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DataType <em>Data Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Data Type</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DataType
	 * @generated
	 */
	EEnum getDataType();

	/**
	 * Returns the meta object for enum '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.MethodType <em>Method Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Method Type</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.MethodType
	 * @generated
	 */
	EEnum getMethodType();

	/**
	 * Returns the meta object for enum '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.ElementType <em>Element Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Element Type</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.ElementType
	 * @generated
	 */
	EEnum getElementType();

	/**
	 * Returns the meta object for enum '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode <em>Display Mode</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Display Mode</em>'.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode
	 * @generated
	 */
	EEnum getDisplayMode();

	/**
	 * Returns the meta object for data type '{@link java.time.Instant <em>Instant</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Instant</em>'.
	 * @see java.time.Instant
	 * @model instanceClass="java.time.Instant"
	 * @generated
	 */
	EDataType getInstant();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	RefactoredWebFactory getRefactoredWebFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebApplicationImpl <em>Application</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebApplicationImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getRefactoredWebApplication()
		 * @generated
		 */
		EClass REFACTORED_WEB_APPLICATION = eINSTANCE.getRefactoredWebApplication();

		/**
		 * The meta object literal for the '<em><b>Entities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFACTORED_WEB_APPLICATION__ENTITIES = eINSTANCE.getRefactoredWebApplication_Entities();

		/**
		 * The meta object literal for the '<em><b>Pages</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFACTORED_WEB_APPLICATION__PAGES = eINSTANCE.getRefactoredWebApplication_Pages();

		/**
		 * The meta object literal for the '<em><b>Total Pages</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFACTORED_WEB_APPLICATION__TOTAL_PAGES = eINSTANCE.getRefactoredWebApplication_TotalPages();

		/**
		 * The meta object literal for the '<em><b>Display Mode</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFACTORED_WEB_APPLICATION__DISPLAY_MODE = eINSTANCE.getRefactoredWebApplication_DisplayMode();

		/**
		 * The meta object literal for the '<em><b>Admin</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFACTORED_WEB_APPLICATION__ADMIN = eINSTANCE.getRefactoredWebApplication_Admin();

		/**
		 * The meta object literal for the '<em><b>Current Sys Admin</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute REFACTORED_WEB_APPLICATION__CURRENT_SYS_ADMIN = eINSTANCE
				.getRefactoredWebApplication_CurrentSysAdmin();

		/**
		 * The meta object literal for the '<em><b>Unique Page Names</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REFACTORED_WEB_APPLICATION___UNIQUE_PAGE_NAMES__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getRefactoredWebApplication__UniquePageNames__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>At Least One Page</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REFACTORED_WEB_APPLICATION___AT_LEAST_ONE_PAGE__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getRefactoredWebApplication__AtLeastOnePage__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>At Least One Entity</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REFACTORED_WEB_APPLICATION___AT_LEAST_ONE_ENTITY__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getRefactoredWebApplication__AtLeastOneEntity__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Unique Entity Names</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation REFACTORED_WEB_APPLICATION___UNIQUE_ENTITY_NAMES__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getRefactoredWebApplication__UniqueEntityNames__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.EntityImpl <em>Entity</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.EntityImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getEntity()
		 * @generated
		 */
		EClass ENTITY = eINSTANCE.getEntity();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY__ATTRIBUTES = eINSTANCE.getEntity_Attributes();

		/**
		 * The meta object literal for the '<em><b>References</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ENTITY__REFERENCES = eINSTANCE.getEntity_References();

		/**
		 * The meta object literal for the '<em><b>Primary Key Name</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ENTITY___PRIMARY_KEY_NAME = eINSTANCE.getEntity__PrimaryKeyName();

		/**
		 * The meta object literal for the '<em><b>One Primary Key</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ENTITY___ONE_PRIMARY_KEY__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getEntity__OnePrimaryKey__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '<em><b>Unique Attribute Reference Names</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation ENTITY___UNIQUE_ATTRIBUTE_REFERENCE_NAMES__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getEntity__UniqueAttributeReferenceNames__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AttributeImpl <em>Attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AttributeImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getAttribute()
		 * @generated
		 */
		EClass ATTRIBUTE = eINSTANCE.getAttribute();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__TYPE = eINSTANCE.getAttribute_Type();

		/**
		 * The meta object literal for the '<em><b>Is PK</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ATTRIBUTE__IS_PK = eINSTANCE.getAttribute_IsPK();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ReferenceImpl <em>Reference</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ReferenceImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getReference()
		 * @generated
		 */
		EClass REFERENCE = eINSTANCE.getReference();

		/**
		 * The meta object literal for the '<em><b>Foreign Key</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference REFERENCE__FOREIGN_KEY = eINSTANCE.getReference_ForeignKey();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.NamedIdentifierImpl <em>Named Identifier</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.NamedIdentifierImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getNamedIdentifier()
		 * @generated
		 */
		EClass NAMED_IDENTIFIER = eINSTANCE.getNamedIdentifier();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAMED_IDENTIFIER__NAME = eINSTANCE.getNamedIdentifier_Name();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute NAMED_IDENTIFIER__ID = eINSTANCE.getNamedIdentifier_Id();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl <em>Page</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getPage()
		 * @generated
		 */
		EClass PAGE = eINSTANCE.getPage();

		/**
		 * The meta object literal for the '<em><b>Total Media Size</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGE__TOTAL_MEDIA_SIZE = eINSTANCE.getPage_TotalMediaSize();

		/**
		 * The meta object literal for the '<em><b>Link</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGE__LINK = eINSTANCE.getPage_Link();

		/**
		 * The meta object literal for the '<em><b>Contents</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGE__CONTENTS = eINSTANCE.getPage_Contents();

		/**
		 * The meta object literal for the '<em><b>Web Application</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PAGE__WEB_APPLICATION = eINSTANCE.getPage_WebApplication();

		/**
		 * The meta object literal for the '<em><b>Created At</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PAGE__CREATED_AT = eINSTANCE.getPage_CreatedAt();

		/**
		 * The meta object literal for the '<em><b>Is Not Empty</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAGE___IS_NOT_EMPTY = eINSTANCE.getPage__IsNotEmpty();

		/**
		 * The meta object literal for the '<em><b>Get Static Content Qty</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAGE___GET_STATIC_CONTENT_QTY = eINSTANCE.getPage__GetStaticContentQty();

		/**
		 * The meta object literal for the '<em><b>Get Dynamic Content Qty</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAGE___GET_DYNAMIC_CONTENT_QTY = eINSTANCE.getPage__GetDynamicContentQty();

		/**
		 * The meta object literal for the '<em><b>Optimise Page Load</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation PAGE___OPTIMISE_PAGE_LOAD__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getPage__OptimisePageLoad__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ContentImpl <em>Content</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ContentImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getContent()
		 * @generated
		 */
		EClass CONTENT = eINSTANCE.getContent();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DContentImpl <em>DContent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DContentImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDContent()
		 * @generated
		 */
		EClass DCONTENT = eINSTANCE.getDContent();

		/**
		 * The meta object literal for the '<em><b>Attributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DCONTENT__ATTRIBUTES = eINSTANCE.getDContent_Attributes();

		/**
		 * The meta object literal for the '<em><b>Entity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DCONTENT__ENTITY = eINSTANCE.getDContent_Entity();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ListImpl <em>List</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ListImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getList()
		 * @generated
		 */
		EClass LIST = eINSTANCE.getList();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DetailImpl <em>Detail</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.DetailImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDetail()
		 * @generated
		 */
		EClass DETAIL = eINSTANCE.getDetail();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.SContentImpl <em>SContent</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.SContentImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getSContent()
		 * @generated
		 */
		EClass SCONTENT = eINSTANCE.getSContent();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.FormImpl <em>Form</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.FormImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getForm()
		 * @generated
		 */
		EClass FORM = eINSTANCE.getForm();

		/**
		 * The meta object literal for the '<em><b>Method</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FORM__METHOD = eINSTANCE.getForm_Method();

		/**
		 * The meta object literal for the '<em><b>Elements</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FORM__ELEMENTS = eINSTANCE.getForm_Elements();

		/**
		 * The meta object literal for the '<em><b>Entity</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FORM__ENTITY = eINSTANCE.getForm_Entity();

		/**
		 * The meta object literal for the '<em><b>Get Element Qty</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FORM___GET_ELEMENT_QTY = eINSTANCE.getForm__GetElementQty();

		/**
		 * The meta object literal for the '<em><b>At Least One Element</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation FORM___AT_LEAST_ONE_ELEMENT__DIAGNOSTICCHAIN_MAP = eINSTANCE
				.getForm__AtLeastOneElement__DiagnosticChain_Map();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ElementImpl <em>Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ElementImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getElement()
		 * @generated
		 */
		EClass ELEMENT = eINSTANCE.getElement();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT__LABEL = eINSTANCE.getElement_Label();

		/**
		 * The meta object literal for the '<em><b>Tooltip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT__TOOLTIP = eINSTANCE.getElement_Tooltip();

		/**
		 * The meta object literal for the '<em><b>Attribute</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEMENT__ATTRIBUTE = eINSTANCE.getElement_Attribute();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ELEMENT__TYPE = eINSTANCE.getElement_Type();

		/**
		 * The meta object literal for the '<em><b>Form</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ELEMENT__FORM = eINSTANCE.getElement_Form();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl <em>Visual Media</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getVisualMedia()
		 * @generated
		 */
		EClass VISUAL_MEDIA = eINSTANCE.getVisualMedia();

		/**
		 * The meta object literal for the '<em><b>Source</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VISUAL_MEDIA__SOURCE = eINSTANCE.getVisualMedia_Source();

		/**
		 * The meta object literal for the '<em><b>Alt Text</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VISUAL_MEDIA__ALT_TEXT = eINSTANCE.getVisualMedia_AltText();

		/**
		 * The meta object literal for the '<em><b>Size</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VISUAL_MEDIA__SIZE = eINSTANCE.getVisualMedia_Size();

		/**
		 * The meta object literal for the '<em><b>Media Classification</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute VISUAL_MEDIA__MEDIA_CLASSIFICATION = eINSTANCE.getVisualMedia_MediaClassification();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AdministratorImpl <em>Administrator</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.AdministratorImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getAdministrator()
		 * @generated
		 */
		EClass ADMINISTRATOR = eINSTANCE.getAdministrator();

		/**
		 * The meta object literal for the '<em><b>First Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADMINISTRATOR__FIRST_NAME = eINSTANCE.getAdministrator_FirstName();

		/**
		 * The meta object literal for the '<em><b>Last Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADMINISTRATOR__LAST_NAME = eINSTANCE.getAdministrator_LastName();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADMINISTRATOR__ID = eINSTANCE.getAdministrator_Id();

		/**
		 * The meta object literal for the '<em><b>Full Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ADMINISTRATOR__FULL_NAME = eINSTANCE.getAdministrator_FullName();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ImageImpl <em>Image</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.ImageImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getImage()
		 * @generated
		 */
		EClass IMAGE = eINSTANCE.getImage();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VideoImpl <em>Video</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VideoImpl
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getVideo()
		 * @generated
		 */
		EClass VIDEO = eINSTANCE.getVideo();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DataType <em>Data Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DataType
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDataType()
		 * @generated
		 */
		EEnum DATA_TYPE = eINSTANCE.getDataType();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.MethodType <em>Method Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.MethodType
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getMethodType()
		 * @generated
		 */
		EEnum METHOD_TYPE = eINSTANCE.getMethodType();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.ElementType <em>Element Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.ElementType
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getElementType()
		 * @generated
		 */
		EEnum ELEMENT_TYPE = eINSTANCE.getElementType();

		/**
		 * The meta object literal for the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode <em>Display Mode</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getDisplayMode()
		 * @generated
		 */
		EEnum DISPLAY_MODE = eINSTANCE.getDisplayMode();

		/**
		 * The meta object literal for the '<em>Instant</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.time.Instant
		 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.RefactoredWebPackageImpl#getInstant()
		 * @generated
		 */
		EDataType INSTANT = eINSTANCE.getInstant();

	}

} //RefactoredWebPackage
