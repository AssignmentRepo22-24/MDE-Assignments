/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl;

import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebTables;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia;

import java.math.BigDecimal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.RealValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Visual Media</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl#getSource <em>Source</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl#getAltText <em>Alt Text</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl#getSize <em>Size</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.VisualMediaImpl#getMediaClassification <em>Media Classification</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class VisualMediaImpl extends SContentImpl implements VisualMedia {
	/**
	 * The default value of the '{@link #getSource() <em>Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected static final String SOURCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSource() <em>Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected String source = SOURCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAltText() <em>Alt Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAltText()
	 * @generated
	 * @ordered
	 */
	protected static final String ALT_TEXT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAltText() <em>Alt Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAltText()
	 * @generated
	 * @ordered
	 */
	protected String altText = ALT_TEXT_EDEFAULT;

	/**
	 * The default value of the '{@link #getSize() <em>Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal SIZE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSize() <em>Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal size = SIZE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMediaClassification() <em>Media Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMediaClassification()
	 * @generated
	 * @ordered
	 */
	protected static final String MEDIA_CLASSIFICATION_EDEFAULT = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VisualMediaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RefactoredWebPackage.Literals.VISUAL_MEDIA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSource() {
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource(String newSource) {
		String oldSource = source;
		source = newSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RefactoredWebPackage.VISUAL_MEDIA__SOURCE, oldSource,
					source));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAltText() {
		return altText;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAltText(String newAltText) {
		String oldAltText = altText;
		altText = newAltText;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RefactoredWebPackage.VISUAL_MEDIA__ALT_TEXT,
					oldAltText, altText));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getSize() {
		return size;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSize(BigDecimal newSize) {
		BigDecimal oldSize = size;
		size = newSize;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RefactoredWebPackage.VISUAL_MEDIA__SIZE, oldSize,
					size));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMediaClassification() {
		/**
		 * if size < 20 then 'Small size media' else 'Large size media' endif
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ BigDecimal size = this.getSize();
		final /*@NonInvalid*/ RealValue BOXED_size = ValueUtil.realValueOf(size);
		final /*@NonInvalid*/ boolean lt = OclComparableLessThanOperation.INSTANCE
				.evaluate(executor, BOXED_size, RefactoredWebTables.INT_20).booleanValue();
		/*@NonInvalid*/ String local_0;
		if (lt) {
			local_0 = RefactoredWebTables.STR_Small_32_size_32_media;
		} else {
			local_0 = RefactoredWebTables.STR_Large_32_size_32_media;
		}
		return local_0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMediaClassification(String newMediaClassification) {
		// TODO: implement this method to set the 'Media Classification' attribute
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RefactoredWebPackage.VISUAL_MEDIA__SOURCE:
			return getSource();
		case RefactoredWebPackage.VISUAL_MEDIA__ALT_TEXT:
			return getAltText();
		case RefactoredWebPackage.VISUAL_MEDIA__SIZE:
			return getSize();
		case RefactoredWebPackage.VISUAL_MEDIA__MEDIA_CLASSIFICATION:
			return getMediaClassification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RefactoredWebPackage.VISUAL_MEDIA__SOURCE:
			setSource((String) newValue);
			return;
		case RefactoredWebPackage.VISUAL_MEDIA__ALT_TEXT:
			setAltText((String) newValue);
			return;
		case RefactoredWebPackage.VISUAL_MEDIA__SIZE:
			setSize((BigDecimal) newValue);
			return;
		case RefactoredWebPackage.VISUAL_MEDIA__MEDIA_CLASSIFICATION:
			setMediaClassification((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RefactoredWebPackage.VISUAL_MEDIA__SOURCE:
			setSource(SOURCE_EDEFAULT);
			return;
		case RefactoredWebPackage.VISUAL_MEDIA__ALT_TEXT:
			setAltText(ALT_TEXT_EDEFAULT);
			return;
		case RefactoredWebPackage.VISUAL_MEDIA__SIZE:
			setSize(SIZE_EDEFAULT);
			return;
		case RefactoredWebPackage.VISUAL_MEDIA__MEDIA_CLASSIFICATION:
			setMediaClassification(MEDIA_CLASSIFICATION_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RefactoredWebPackage.VISUAL_MEDIA__SOURCE:
			return SOURCE_EDEFAULT == null ? source != null : !SOURCE_EDEFAULT.equals(source);
		case RefactoredWebPackage.VISUAL_MEDIA__ALT_TEXT:
			return ALT_TEXT_EDEFAULT == null ? altText != null : !ALT_TEXT_EDEFAULT.equals(altText);
		case RefactoredWebPackage.VISUAL_MEDIA__SIZE:
			return SIZE_EDEFAULT == null ? size != null : !SIZE_EDEFAULT.equals(size);
		case RefactoredWebPackage.VISUAL_MEDIA__MEDIA_CLASSIFICATION:
			return MEDIA_CLASSIFICATION_EDEFAULT == null ? getMediaClassification() != null
					: !MEDIA_CLASSIFICATION_EDEFAULT.equals(getMediaClassification());
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (source: ");
		result.append(source);
		result.append(", altText: ");
		result.append(altText);
		result.append(", size: ");
		result.append(size);
		result.append(')');
		return result.toString();
	}

} //VisualMediaImpl
