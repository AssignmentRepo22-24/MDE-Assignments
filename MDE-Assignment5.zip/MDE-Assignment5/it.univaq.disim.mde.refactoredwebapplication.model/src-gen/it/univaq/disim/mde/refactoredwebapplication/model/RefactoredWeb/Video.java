/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Video</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getVideo()
 * @model
 * @generated
 */
public interface Video extends VisualMedia {
} // Video
