/*******************************************************************************
 *************************************************************************
 * This code is 100% auto-generated
 * from:
 *   /it.univaq.disim.mde.refactoredwebapplication.model/model/RefactoredWeb.ecore
 * using:
 *   /it.univaq.disim.mde.refactoredwebapplication.model/model/RefactoredWeb.genmodel
 *   org.eclipse.ocl.examples.codegen.oclinecore.OCLinEcoreTables
 *
 * Do not edit it.
 *******************************************************************************/
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

// import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage;
// import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebTables;
import java.lang.String;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.ocl.pivot.ParameterTypes;
import org.eclipse.ocl.pivot.TemplateParameters;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.DataTypeId;
import org.eclipse.ocl.pivot.ids.EnumerationId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.RootPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumeration;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumerationLiteral;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorPackage;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorType;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreLibraryOppositeProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorFragment;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorOperation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorPropertyWithImplementation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorStandardLibrary;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorType;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.AbstractTables;
import org.eclipse.ocl.pivot.utilities.TypeUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;

/**
 * RefactoredWebTables provides the dispatch tables for the RefactoredWeb for use by the OCL dispatcher.
 *
 * In order to ensure correct static initialization, a top level class element must be accessed
 * before any nested class element. Therefore an access to PACKAGE.getClass() is recommended.
 */
public class RefactoredWebTables extends AbstractTables
{
	static {
		Init.initStart();
	}

	/**
	 *	The package descriptor for the package.
	 */
	public static final EcoreExecutorPackage PACKAGE = new EcoreExecutorPackage(RefactoredWebPackage.eINSTANCE);

	/**
	 *	The library of all packages and types.
	 */
	public static final ExecutorStandardLibrary LIBRARY = OCLstdlibTables.LIBRARY;

	/**
	 *	Constants used by auto-generated code.
	 */
	public static final /*@NonInvalid*/ RootPackageId PACKid_$metamodel$ = IdManager.getRootPackageId("$metamodel$");
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore = IdManager.getNsURIPackageId("http://www.eclipse.org/emf/2002/Ecore", null, EcorePackage.eINSTANCE);
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb = IdManager.getNsURIPackageId("https://it.univaq.disim.mde/refactoredweb", null, RefactoredWebPackage.eINSTANCE);
	public static final /*@NonInvalid*/ ClassId CLSSid_Administrator = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Administrator", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Attribute = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Attribute", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Class = RefactoredWebTables.PACKid_$metamodel$.getClassId("Class", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Content = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Content", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_DContent = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("DContent", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Element = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Element", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Entity = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Entity", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Form = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Form", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Page = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Page", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_RefactoredWebApplication = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("RefactoredWebApplication", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Reference = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("Reference", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_SContent = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("SContent", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_VisualMedia = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getClassId("VisualMedia", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EDouble = RefactoredWebTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EDouble", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EInt = RefactoredWebTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EInt", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_Instant = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getDataTypeId("Instant", 0);
	public static final /*@NonInvalid*/ EnumerationId ENUMid_DataType = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getEnumerationId("DataType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_DisplayMode = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getEnumerationId("DisplayMode");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_ElementType = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getEnumerationId("ElementType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_MethodType = RefactoredWebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_refactoredweb.getEnumerationId("MethodType");
	public static final /*@NonInvalid*/ IntegerValue INT_0 = ValueUtil.integerValueOf("0");
	public static final /*@NonInvalid*/ IntegerValue INT_1 = ValueUtil.integerValueOf("1");
	public static final /*@NonInvalid*/ IntegerValue INT_20 = ValueUtil.integerValueOf("20");
	public static final /*@NonInvalid*/ IntegerValue INT_50 = ValueUtil.integerValueOf("50");
	public static final /*@NonInvalid*/ CollectionTypeId ORD_PRIMid_String = TypeId.ORDERED_SET.getSpecializedId(TypeId.STRING);
	public static final /*@NonInvalid*/ CollectionTypeId SEQ_PRIMid_Real = TypeId.SEQUENCE.getSpecializedId(TypeId.REAL);
	public static final /*@NonInvalid*/ CollectionTypeId SEQ_PRIMid_String = TypeId.SEQUENCE.getSpecializedId(TypeId.STRING);
	public static final /*@NonInvalid*/ CollectionTypeId SET_PRIMid_String = TypeId.SET.getSpecializedId(TypeId.STRING);
	public static final /*@NonInvalid*/ String STR_Large_32_size_32_media = "Large size media";
	public static final /*@NonInvalid*/ String STR_Small_32_size_32_media = "Small size media";
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_DContent = TypeId.BAG.getSpecializedId(RefactoredWebTables.CLSSid_DContent);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Element = TypeId.BAG.getSpecializedId(RefactoredWebTables.CLSSid_Element);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Form = TypeId.BAG.getSpecializedId(RefactoredWebTables.CLSSid_Form);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Page = TypeId.BAG.getSpecializedId(RefactoredWebTables.CLSSid_Page);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Reference = TypeId.BAG.getSpecializedId(RefactoredWebTables.CLSSid_Reference);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Administrator = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Administrator);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Attribute = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Attribute);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Content = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Content);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Element = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Element);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Entity = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Entity);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Page = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Page);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Reference = TypeId.ORDERED_SET.getSpecializedId(RefactoredWebTables.CLSSid_Reference);

	/**
	 *	The type parameters for templated types and operations.
	 */
	public static class TypeParameters {
		static {
			Init.initStart();
			RefactoredWebTables.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::TypeParameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The type descriptors for each type.
	 */
	public static class Types {
		static {
			Init.initStart();
			TypeParameters.init();
		}

		public static final EcoreExecutorType _Administrator = new EcoreExecutorType(RefactoredWebPackage.Literals.ADMINISTRATOR, PACKAGE, 0);
		public static final EcoreExecutorType _Attribute = new EcoreExecutorType(RefactoredWebPackage.Literals.ATTRIBUTE, PACKAGE, 0);
		public static final EcoreExecutorType _Content = new EcoreExecutorType(RefactoredWebPackage.Literals.CONTENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _DContent = new EcoreExecutorType(RefactoredWebPackage.Literals.DCONTENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorEnumeration _DataType = new EcoreExecutorEnumeration(RefactoredWebPackage.Literals.DATA_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _Detail = new EcoreExecutorType(RefactoredWebPackage.Literals.DETAIL, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _DisplayMode = new EcoreExecutorEnumeration(RefactoredWebPackage.Literals.DISPLAY_MODE, PACKAGE, 0);
		public static final EcoreExecutorType _Element = new EcoreExecutorType(RefactoredWebPackage.Literals.ELEMENT, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _ElementType = new EcoreExecutorEnumeration(RefactoredWebPackage.Literals.ELEMENT_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _Entity = new EcoreExecutorType(RefactoredWebPackage.Literals.ENTITY, PACKAGE, 0);
		public static final EcoreExecutorType _Form = new EcoreExecutorType(RefactoredWebPackage.Literals.FORM, PACKAGE, 0);
		public static final EcoreExecutorType _Image = new EcoreExecutorType(RefactoredWebPackage.Literals.IMAGE, PACKAGE, 0);
		public static final EcoreExecutorType _Instant = new EcoreExecutorType("Instant", PACKAGE, 0);
		public static final EcoreExecutorType _List = new EcoreExecutorType(RefactoredWebPackage.Literals.LIST, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _MethodType = new EcoreExecutorEnumeration(RefactoredWebPackage.Literals.METHOD_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _NamedIdentifier = new EcoreExecutorType(RefactoredWebPackage.Literals.NAMED_IDENTIFIER, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Page = new EcoreExecutorType(RefactoredWebPackage.Literals.PAGE, PACKAGE, 0);
		public static final EcoreExecutorType _RefactoredWebApplication = new EcoreExecutorType(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION, PACKAGE, 0);
		public static final EcoreExecutorType _Reference = new EcoreExecutorType(RefactoredWebPackage.Literals.REFERENCE, PACKAGE, 0);
		public static final EcoreExecutorType _SContent = new EcoreExecutorType(RefactoredWebPackage.Literals.SCONTENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Video = new EcoreExecutorType(RefactoredWebPackage.Literals.VIDEO, PACKAGE, 0);
		public static final EcoreExecutorType _VisualMedia = new EcoreExecutorType(RefactoredWebPackage.Literals.VISUAL_MEDIA, PACKAGE, 0 | ExecutorType.ABSTRACT);

		private static final EcoreExecutorType /*@NonNull*/ [] types = {
			_Administrator,
			_Attribute,
			_Content,
			_DContent,
			_DataType,
			_Detail,
			_DisplayMode,
			_Element,
			_ElementType,
			_Entity,
			_Form,
			_Image,
			_Instant,
			_List,
			_MethodType,
			_NamedIdentifier,
			_Page,
			_RefactoredWebApplication,
			_Reference,
			_SContent,
			_Video,
			_VisualMedia
		};

		/*
		 *	Install the type descriptors in the package descriptor.
		 */
		static {
			PACKAGE.init(LIBRARY, types);
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::Types and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragment descriptors for the local elements of each type and its supertypes.
	 */
	public static class Fragments {
		static {
			Init.initStart();
			Types.init();
		}

		private static final ExecutorFragment _Administrator__Administrator = new ExecutorFragment(Types._Administrator, RefactoredWebTables.Types._Administrator);
		private static final ExecutorFragment _Administrator__OclAny = new ExecutorFragment(Types._Administrator, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Administrator__OclElement = new ExecutorFragment(Types._Administrator, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Attribute__Attribute = new ExecutorFragment(Types._Attribute, RefactoredWebTables.Types._Attribute);
		private static final ExecutorFragment _Attribute__NamedIdentifier = new ExecutorFragment(Types._Attribute, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Attribute__OclAny = new ExecutorFragment(Types._Attribute, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Attribute__OclElement = new ExecutorFragment(Types._Attribute, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Content__Content = new ExecutorFragment(Types._Content, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _Content__NamedIdentifier = new ExecutorFragment(Types._Content, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Content__OclAny = new ExecutorFragment(Types._Content, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Content__OclElement = new ExecutorFragment(Types._Content, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _DContent__Content = new ExecutorFragment(Types._DContent, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _DContent__DContent = new ExecutorFragment(Types._DContent, RefactoredWebTables.Types._DContent);
		private static final ExecutorFragment _DContent__NamedIdentifier = new ExecutorFragment(Types._DContent, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _DContent__OclAny = new ExecutorFragment(Types._DContent, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _DContent__OclElement = new ExecutorFragment(Types._DContent, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _DataType__DataType = new ExecutorFragment(Types._DataType, RefactoredWebTables.Types._DataType);
		private static final ExecutorFragment _DataType__OclAny = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _DataType__OclElement = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _DataType__OclEnumeration = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _DataType__OclType = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Detail__Content = new ExecutorFragment(Types._Detail, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _Detail__DContent = new ExecutorFragment(Types._Detail, RefactoredWebTables.Types._DContent);
		private static final ExecutorFragment _Detail__Detail = new ExecutorFragment(Types._Detail, RefactoredWebTables.Types._Detail);
		private static final ExecutorFragment _Detail__NamedIdentifier = new ExecutorFragment(Types._Detail, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Detail__OclAny = new ExecutorFragment(Types._Detail, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Detail__OclElement = new ExecutorFragment(Types._Detail, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _DisplayMode__DisplayMode = new ExecutorFragment(Types._DisplayMode, RefactoredWebTables.Types._DisplayMode);
		private static final ExecutorFragment _DisplayMode__OclAny = new ExecutorFragment(Types._DisplayMode, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _DisplayMode__OclElement = new ExecutorFragment(Types._DisplayMode, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _DisplayMode__OclEnumeration = new ExecutorFragment(Types._DisplayMode, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _DisplayMode__OclType = new ExecutorFragment(Types._DisplayMode, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Element__Element = new ExecutorFragment(Types._Element, RefactoredWebTables.Types._Element);
		private static final ExecutorFragment _Element__NamedIdentifier = new ExecutorFragment(Types._Element, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Element__OclAny = new ExecutorFragment(Types._Element, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Element__OclElement = new ExecutorFragment(Types._Element, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _ElementType__ElementType = new ExecutorFragment(Types._ElementType, RefactoredWebTables.Types._ElementType);
		private static final ExecutorFragment _ElementType__OclAny = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _ElementType__OclElement = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _ElementType__OclEnumeration = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _ElementType__OclType = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Entity__Entity = new ExecutorFragment(Types._Entity, RefactoredWebTables.Types._Entity);
		private static final ExecutorFragment _Entity__NamedIdentifier = new ExecutorFragment(Types._Entity, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Entity__OclAny = new ExecutorFragment(Types._Entity, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Entity__OclElement = new ExecutorFragment(Types._Entity, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Form__Content = new ExecutorFragment(Types._Form, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _Form__Form = new ExecutorFragment(Types._Form, RefactoredWebTables.Types._Form);
		private static final ExecutorFragment _Form__NamedIdentifier = new ExecutorFragment(Types._Form, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Form__OclAny = new ExecutorFragment(Types._Form, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Form__OclElement = new ExecutorFragment(Types._Form, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Form__SContent = new ExecutorFragment(Types._Form, RefactoredWebTables.Types._SContent);

		private static final ExecutorFragment _Image__Content = new ExecutorFragment(Types._Image, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _Image__Image = new ExecutorFragment(Types._Image, RefactoredWebTables.Types._Image);
		private static final ExecutorFragment _Image__NamedIdentifier = new ExecutorFragment(Types._Image, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Image__OclAny = new ExecutorFragment(Types._Image, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Image__OclElement = new ExecutorFragment(Types._Image, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Image__SContent = new ExecutorFragment(Types._Image, RefactoredWebTables.Types._SContent);
		private static final ExecutorFragment _Image__VisualMedia = new ExecutorFragment(Types._Image, RefactoredWebTables.Types._VisualMedia);

		private static final ExecutorFragment _Instant__Instant = new ExecutorFragment(Types._Instant, RefactoredWebTables.Types._Instant);
		private static final ExecutorFragment _Instant__OclAny = new ExecutorFragment(Types._Instant, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Instant__OclComparable = new ExecutorFragment(Types._Instant, OCLstdlibTables.Types._OclComparable);

		private static final ExecutorFragment _List__Content = new ExecutorFragment(Types._List, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _List__DContent = new ExecutorFragment(Types._List, RefactoredWebTables.Types._DContent);
		private static final ExecutorFragment _List__List = new ExecutorFragment(Types._List, RefactoredWebTables.Types._List);
		private static final ExecutorFragment _List__NamedIdentifier = new ExecutorFragment(Types._List, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _List__OclAny = new ExecutorFragment(Types._List, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _List__OclElement = new ExecutorFragment(Types._List, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _MethodType__MethodType = new ExecutorFragment(Types._MethodType, RefactoredWebTables.Types._MethodType);
		private static final ExecutorFragment _MethodType__OclAny = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _MethodType__OclElement = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _MethodType__OclEnumeration = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _MethodType__OclType = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _NamedIdentifier__NamedIdentifier = new ExecutorFragment(Types._NamedIdentifier, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _NamedIdentifier__OclAny = new ExecutorFragment(Types._NamedIdentifier, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _NamedIdentifier__OclElement = new ExecutorFragment(Types._NamedIdentifier, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Page__NamedIdentifier = new ExecutorFragment(Types._Page, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Page__OclAny = new ExecutorFragment(Types._Page, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Page__OclElement = new ExecutorFragment(Types._Page, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Page__Page = new ExecutorFragment(Types._Page, RefactoredWebTables.Types._Page);

		private static final ExecutorFragment _RefactoredWebApplication__NamedIdentifier = new ExecutorFragment(Types._RefactoredWebApplication, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _RefactoredWebApplication__OclAny = new ExecutorFragment(Types._RefactoredWebApplication, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _RefactoredWebApplication__OclElement = new ExecutorFragment(Types._RefactoredWebApplication, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _RefactoredWebApplication__RefactoredWebApplication = new ExecutorFragment(Types._RefactoredWebApplication, RefactoredWebTables.Types._RefactoredWebApplication);

		private static final ExecutorFragment _Reference__NamedIdentifier = new ExecutorFragment(Types._Reference, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Reference__OclAny = new ExecutorFragment(Types._Reference, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Reference__OclElement = new ExecutorFragment(Types._Reference, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Reference__Reference = new ExecutorFragment(Types._Reference, RefactoredWebTables.Types._Reference);

		private static final ExecutorFragment _SContent__Content = new ExecutorFragment(Types._SContent, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _SContent__NamedIdentifier = new ExecutorFragment(Types._SContent, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _SContent__OclAny = new ExecutorFragment(Types._SContent, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _SContent__OclElement = new ExecutorFragment(Types._SContent, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _SContent__SContent = new ExecutorFragment(Types._SContent, RefactoredWebTables.Types._SContent);

		private static final ExecutorFragment _Video__Content = new ExecutorFragment(Types._Video, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _Video__NamedIdentifier = new ExecutorFragment(Types._Video, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _Video__OclAny = new ExecutorFragment(Types._Video, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Video__OclElement = new ExecutorFragment(Types._Video, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Video__SContent = new ExecutorFragment(Types._Video, RefactoredWebTables.Types._SContent);
		private static final ExecutorFragment _Video__Video = new ExecutorFragment(Types._Video, RefactoredWebTables.Types._Video);
		private static final ExecutorFragment _Video__VisualMedia = new ExecutorFragment(Types._Video, RefactoredWebTables.Types._VisualMedia);

		private static final ExecutorFragment _VisualMedia__Content = new ExecutorFragment(Types._VisualMedia, RefactoredWebTables.Types._Content);
		private static final ExecutorFragment _VisualMedia__NamedIdentifier = new ExecutorFragment(Types._VisualMedia, RefactoredWebTables.Types._NamedIdentifier);
		private static final ExecutorFragment _VisualMedia__OclAny = new ExecutorFragment(Types._VisualMedia, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _VisualMedia__OclElement = new ExecutorFragment(Types._VisualMedia, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _VisualMedia__SContent = new ExecutorFragment(Types._VisualMedia, RefactoredWebTables.Types._SContent);
		private static final ExecutorFragment _VisualMedia__VisualMedia = new ExecutorFragment(Types._VisualMedia, RefactoredWebTables.Types._VisualMedia);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::Fragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The parameter lists shared by operations.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Parameters {
		static {
			Init.initStart();
			Fragments.init();
		}

		public static final ParameterTypes _OclSelf = TypeUtil.createParameterTypes(OCLstdlibTables.Types._OclSelf);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::Parameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The operation descriptors for each operation of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Operations {
		static {
			Init.initStart();
			Parameters.init();
		}

		public static final ExecutorOperation _Entity__primaryKeyName = new ExecutorOperation("primaryKeyName", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Entity,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Form__getElementQty = new ExecutorOperation("getElementQty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Form,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Instant__compareTo = new ExecutorOperation("compareTo", Parameters._OclSelf, Types._Instant,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Page__getDynamicContentQty = new ExecutorOperation("getDynamicContentQty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Page,
			0, TemplateParameters.EMPTY_LIST, null);
		public static final ExecutorOperation _Page__getStaticContentQty = new ExecutorOperation("getStaticContentQty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Page,
			1, TemplateParameters.EMPTY_LIST, null);
		public static final ExecutorOperation _Page__isNotEmpty = new ExecutorOperation("isNotEmpty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Page,
			2, TemplateParameters.EMPTY_LIST, null);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::Operations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The property descriptors for each property of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Properties {
		static {
			Init.initStart();
			Operations.init();
		}

		public static final ExecutorProperty _Administrator__firstName = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ADMINISTRATOR__FIRST_NAME, Types._Administrator, 0);
		public static final ExecutorProperty _Administrator__fullName = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ADMINISTRATOR__FULL_NAME, Types._Administrator, 1);
		public static final ExecutorProperty _Administrator__id = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ADMINISTRATOR__ID, Types._Administrator, 2);
		public static final ExecutorProperty _Administrator__lastName = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ADMINISTRATOR__LAST_NAME, Types._Administrator, 3);
		public static final ExecutorProperty _Administrator__RefactoredWebApplication__admin = new ExecutorPropertyWithImplementation("RefactoredWebApplication", Types._Administrator, 4, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__ADMIN));

		public static final ExecutorProperty _Attribute__isPK = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ATTRIBUTE__IS_PK, Types._Attribute, 0);
		public static final ExecutorProperty _Attribute__type = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ATTRIBUTE__TYPE, Types._Attribute, 1);
		public static final ExecutorProperty _Attribute__DContent__attributes = new ExecutorPropertyWithImplementation("DContent", Types._Attribute, 2, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.DCONTENT__ATTRIBUTES));
		public static final ExecutorProperty _Attribute__Element__attribute = new ExecutorPropertyWithImplementation("Element", Types._Attribute, 3, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.ELEMENT__ATTRIBUTE));
		public static final ExecutorProperty _Attribute__Entity__attributes = new ExecutorPropertyWithImplementation("Entity", Types._Attribute, 4, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.ENTITY__ATTRIBUTES));

		public static final ExecutorProperty _Content__Page__contents = new ExecutorPropertyWithImplementation("Page", Types._Content, 0, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.PAGE__CONTENTS));

		public static final ExecutorProperty _DContent__attributes = new EcoreExecutorProperty(RefactoredWebPackage.Literals.DCONTENT__ATTRIBUTES, Types._DContent, 0);
		public static final ExecutorProperty _DContent__entity = new EcoreExecutorProperty(RefactoredWebPackage.Literals.DCONTENT__ENTITY, Types._DContent, 1);

		public static final ExecutorProperty _Element__attribute = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ELEMENT__ATTRIBUTE, Types._Element, 0);
		public static final ExecutorProperty _Element__form = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ELEMENT__FORM, Types._Element, 1);
		public static final ExecutorProperty _Element__label = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ELEMENT__LABEL, Types._Element, 2);
		public static final ExecutorProperty _Element__tooltip = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ELEMENT__TOOLTIP, Types._Element, 3);
		public static final ExecutorProperty _Element__type = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ELEMENT__TYPE, Types._Element, 4);

		public static final ExecutorProperty _Entity__attributes = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ENTITY__ATTRIBUTES, Types._Entity, 0);
		public static final ExecutorProperty _Entity__references = new EcoreExecutorProperty(RefactoredWebPackage.Literals.ENTITY__REFERENCES, Types._Entity, 1);
		public static final ExecutorProperty _Entity__DContent__entity = new ExecutorPropertyWithImplementation("DContent", Types._Entity, 2, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.DCONTENT__ENTITY));
		public static final ExecutorProperty _Entity__Form__entity = new ExecutorPropertyWithImplementation("Form", Types._Entity, 3, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.FORM__ENTITY));
		public static final ExecutorProperty _Entity__RefactoredWebApplication__entities = new ExecutorPropertyWithImplementation("RefactoredWebApplication", Types._Entity, 4, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__ENTITIES));
		public static final ExecutorProperty _Entity__Reference__foreignKey = new ExecutorPropertyWithImplementation("Reference", Types._Entity, 5, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.REFERENCE__FOREIGN_KEY));

		public static final ExecutorProperty _Form__elements = new EcoreExecutorProperty(RefactoredWebPackage.Literals.FORM__ELEMENTS, Types._Form, 0);
		public static final ExecutorProperty _Form__entity = new EcoreExecutorProperty(RefactoredWebPackage.Literals.FORM__ENTITY, Types._Form, 1);
		public static final ExecutorProperty _Form__method = new EcoreExecutorProperty(RefactoredWebPackage.Literals.FORM__METHOD, Types._Form, 2);

		public static final ExecutorProperty _NamedIdentifier__id = new EcoreExecutorProperty(RefactoredWebPackage.Literals.NAMED_IDENTIFIER__ID, Types._NamedIdentifier, 0);
		public static final ExecutorProperty _NamedIdentifier__name = new EcoreExecutorProperty(RefactoredWebPackage.Literals.NAMED_IDENTIFIER__NAME, Types._NamedIdentifier, 1);

		public static final ExecutorProperty _Page__contents = new EcoreExecutorProperty(RefactoredWebPackage.Literals.PAGE__CONTENTS, Types._Page, 0);
		public static final ExecutorProperty _Page__createdAt = new EcoreExecutorProperty(RefactoredWebPackage.Literals.PAGE__CREATED_AT, Types._Page, 1);
		public static final ExecutorProperty _Page__link = new EcoreExecutorProperty(RefactoredWebPackage.Literals.PAGE__LINK, Types._Page, 2);
		public static final ExecutorProperty _Page__totalMediaSize = new EcoreExecutorProperty(RefactoredWebPackage.Literals.PAGE__TOTAL_MEDIA_SIZE, Types._Page, 3);
		public static final ExecutorProperty _Page__webApplication = new EcoreExecutorProperty(RefactoredWebPackage.Literals.PAGE__WEB_APPLICATION, Types._Page, 4);
		public static final ExecutorProperty _Page__Page__link = new ExecutorPropertyWithImplementation("Page", Types._Page, 5, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.PAGE__LINK));

		public static final ExecutorProperty _RefactoredWebApplication__admin = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__ADMIN, Types._RefactoredWebApplication, 0);
		public static final ExecutorProperty _RefactoredWebApplication__currentSysAdmin = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__CURRENT_SYS_ADMIN, Types._RefactoredWebApplication, 1);
		public static final ExecutorProperty _RefactoredWebApplication__displayMode = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__DISPLAY_MODE, Types._RefactoredWebApplication, 2);
		public static final ExecutorProperty _RefactoredWebApplication__entities = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__ENTITIES, Types._RefactoredWebApplication, 3);
		public static final ExecutorProperty _RefactoredWebApplication__pages = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__PAGES, Types._RefactoredWebApplication, 4);
		public static final ExecutorProperty _RefactoredWebApplication__totalPages = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFACTORED_WEB_APPLICATION__TOTAL_PAGES, Types._RefactoredWebApplication, 5);

		public static final ExecutorProperty _Reference__foreignKey = new EcoreExecutorProperty(RefactoredWebPackage.Literals.REFERENCE__FOREIGN_KEY, Types._Reference, 0);
		public static final ExecutorProperty _Reference__Entity__references = new ExecutorPropertyWithImplementation("Entity", Types._Reference, 1, new EcoreLibraryOppositeProperty(RefactoredWebPackage.Literals.ENTITY__REFERENCES));

		public static final ExecutorProperty _VisualMedia__altText = new EcoreExecutorProperty(RefactoredWebPackage.Literals.VISUAL_MEDIA__ALT_TEXT, Types._VisualMedia, 0);
		public static final ExecutorProperty _VisualMedia__mediaClassification = new EcoreExecutorProperty(RefactoredWebPackage.Literals.VISUAL_MEDIA__MEDIA_CLASSIFICATION, Types._VisualMedia, 1);
		public static final ExecutorProperty _VisualMedia__size = new EcoreExecutorProperty(RefactoredWebPackage.Literals.VISUAL_MEDIA__SIZE, Types._VisualMedia, 2);
		public static final ExecutorProperty _VisualMedia__source = new EcoreExecutorProperty(RefactoredWebPackage.Literals.VISUAL_MEDIA__SOURCE, Types._VisualMedia, 3);
		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::Properties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragments for all base types in depth order: OclAny first, OclSelf last.
	 */
	public static class TypeFragments {
		static {
			Init.initStart();
			Properties.init();
		}

		private static final ExecutorFragment /*@NonNull*/ [] _Administrator =
			{
				Fragments._Administrator__OclAny /* 0 */,
				Fragments._Administrator__OclElement /* 1 */,
				Fragments._Administrator__Administrator /* 2 */
			};
		private static final int /*@NonNull*/ [] __Administrator = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Attribute =
			{
				Fragments._Attribute__OclAny /* 0 */,
				Fragments._Attribute__OclElement /* 1 */,
				Fragments._Attribute__NamedIdentifier /* 2 */,
				Fragments._Attribute__Attribute /* 3 */
			};
		private static final int /*@NonNull*/ [] __Attribute = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Content =
			{
				Fragments._Content__OclAny /* 0 */,
				Fragments._Content__OclElement /* 1 */,
				Fragments._Content__NamedIdentifier /* 2 */,
				Fragments._Content__Content /* 3 */
			};
		private static final int /*@NonNull*/ [] __Content = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _DContent =
			{
				Fragments._DContent__OclAny /* 0 */,
				Fragments._DContent__OclElement /* 1 */,
				Fragments._DContent__NamedIdentifier /* 2 */,
				Fragments._DContent__Content /* 3 */,
				Fragments._DContent__DContent /* 4 */
			};
		private static final int /*@NonNull*/ [] __DContent = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _DataType =
			{
				Fragments._DataType__OclAny /* 0 */,
				Fragments._DataType__OclElement /* 1 */,
				Fragments._DataType__OclType /* 2 */,
				Fragments._DataType__OclEnumeration /* 3 */,
				Fragments._DataType__DataType /* 4 */
			};
		private static final int /*@NonNull*/ [] __DataType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Detail =
			{
				Fragments._Detail__OclAny /* 0 */,
				Fragments._Detail__OclElement /* 1 */,
				Fragments._Detail__NamedIdentifier /* 2 */,
				Fragments._Detail__Content /* 3 */,
				Fragments._Detail__DContent /* 4 */,
				Fragments._Detail__Detail /* 5 */
			};
		private static final int /*@NonNull*/ [] __Detail = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _DisplayMode =
			{
				Fragments._DisplayMode__OclAny /* 0 */,
				Fragments._DisplayMode__OclElement /* 1 */,
				Fragments._DisplayMode__OclType /* 2 */,
				Fragments._DisplayMode__OclEnumeration /* 3 */,
				Fragments._DisplayMode__DisplayMode /* 4 */
			};
		private static final int /*@NonNull*/ [] __DisplayMode = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Element =
			{
				Fragments._Element__OclAny /* 0 */,
				Fragments._Element__OclElement /* 1 */,
				Fragments._Element__NamedIdentifier /* 2 */,
				Fragments._Element__Element /* 3 */
			};
		private static final int /*@NonNull*/ [] __Element = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _ElementType =
			{
				Fragments._ElementType__OclAny /* 0 */,
				Fragments._ElementType__OclElement /* 1 */,
				Fragments._ElementType__OclType /* 2 */,
				Fragments._ElementType__OclEnumeration /* 3 */,
				Fragments._ElementType__ElementType /* 4 */
			};
		private static final int /*@NonNull*/ [] __ElementType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Entity =
			{
				Fragments._Entity__OclAny /* 0 */,
				Fragments._Entity__OclElement /* 1 */,
				Fragments._Entity__NamedIdentifier /* 2 */,
				Fragments._Entity__Entity /* 3 */
			};
		private static final int /*@NonNull*/ [] __Entity = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Form =
			{
				Fragments._Form__OclAny /* 0 */,
				Fragments._Form__OclElement /* 1 */,
				Fragments._Form__NamedIdentifier /* 2 */,
				Fragments._Form__Content /* 3 */,
				Fragments._Form__SContent /* 4 */,
				Fragments._Form__Form /* 5 */
			};
		private static final int /*@NonNull*/ [] __Form = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Image =
			{
				Fragments._Image__OclAny /* 0 */,
				Fragments._Image__OclElement /* 1 */,
				Fragments._Image__NamedIdentifier /* 2 */,
				Fragments._Image__Content /* 3 */,
				Fragments._Image__SContent /* 4 */,
				Fragments._Image__VisualMedia /* 5 */,
				Fragments._Image__Image /* 6 */
			};
		private static final int /*@NonNull*/ [] __Image = { 1,1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Instant =
			{
				Fragments._Instant__OclAny /* 0 */,
				Fragments._Instant__OclComparable /* 1 */,
				Fragments._Instant__Instant /* 2 */
			};
		private static final int /*@NonNull*/ [] __Instant = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _List =
			{
				Fragments._List__OclAny /* 0 */,
				Fragments._List__OclElement /* 1 */,
				Fragments._List__NamedIdentifier /* 2 */,
				Fragments._List__Content /* 3 */,
				Fragments._List__DContent /* 4 */,
				Fragments._List__List /* 5 */
			};
		private static final int /*@NonNull*/ [] __List = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _MethodType =
			{
				Fragments._MethodType__OclAny /* 0 */,
				Fragments._MethodType__OclElement /* 1 */,
				Fragments._MethodType__OclType /* 2 */,
				Fragments._MethodType__OclEnumeration /* 3 */,
				Fragments._MethodType__MethodType /* 4 */
			};
		private static final int /*@NonNull*/ [] __MethodType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _NamedIdentifier =
			{
				Fragments._NamedIdentifier__OclAny /* 0 */,
				Fragments._NamedIdentifier__OclElement /* 1 */,
				Fragments._NamedIdentifier__NamedIdentifier /* 2 */
			};
		private static final int /*@NonNull*/ [] __NamedIdentifier = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Page =
			{
				Fragments._Page__OclAny /* 0 */,
				Fragments._Page__OclElement /* 1 */,
				Fragments._Page__NamedIdentifier /* 2 */,
				Fragments._Page__Page /* 3 */
			};
		private static final int /*@NonNull*/ [] __Page = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _RefactoredWebApplication =
			{
				Fragments._RefactoredWebApplication__OclAny /* 0 */,
				Fragments._RefactoredWebApplication__OclElement /* 1 */,
				Fragments._RefactoredWebApplication__NamedIdentifier /* 2 */,
				Fragments._RefactoredWebApplication__RefactoredWebApplication /* 3 */
			};
		private static final int /*@NonNull*/ [] __RefactoredWebApplication = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Reference =
			{
				Fragments._Reference__OclAny /* 0 */,
				Fragments._Reference__OclElement /* 1 */,
				Fragments._Reference__NamedIdentifier /* 2 */,
				Fragments._Reference__Reference /* 3 */
			};
		private static final int /*@NonNull*/ [] __Reference = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _SContent =
			{
				Fragments._SContent__OclAny /* 0 */,
				Fragments._SContent__OclElement /* 1 */,
				Fragments._SContent__NamedIdentifier /* 2 */,
				Fragments._SContent__Content /* 3 */,
				Fragments._SContent__SContent /* 4 */
			};
		private static final int /*@NonNull*/ [] __SContent = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Video =
			{
				Fragments._Video__OclAny /* 0 */,
				Fragments._Video__OclElement /* 1 */,
				Fragments._Video__NamedIdentifier /* 2 */,
				Fragments._Video__Content /* 3 */,
				Fragments._Video__SContent /* 4 */,
				Fragments._Video__VisualMedia /* 5 */,
				Fragments._Video__Video /* 6 */
			};
		private static final int /*@NonNull*/ [] __Video = { 1,1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _VisualMedia =
			{
				Fragments._VisualMedia__OclAny /* 0 */,
				Fragments._VisualMedia__OclElement /* 1 */,
				Fragments._VisualMedia__NamedIdentifier /* 2 */,
				Fragments._VisualMedia__Content /* 3 */,
				Fragments._VisualMedia__SContent /* 4 */,
				Fragments._VisualMedia__VisualMedia /* 5 */
			};
		private static final int /*@NonNull*/ [] __VisualMedia = { 1,1,1,1,1,1 };

		/**
		 *	Install the fragment descriptors in the class descriptors.
		 */
		static {
			Types._Administrator.initFragments(_Administrator, __Administrator);
			Types._Attribute.initFragments(_Attribute, __Attribute);
			Types._Content.initFragments(_Content, __Content);
			Types._DContent.initFragments(_DContent, __DContent);
			Types._DataType.initFragments(_DataType, __DataType);
			Types._Detail.initFragments(_Detail, __Detail);
			Types._DisplayMode.initFragments(_DisplayMode, __DisplayMode);
			Types._Element.initFragments(_Element, __Element);
			Types._ElementType.initFragments(_ElementType, __ElementType);
			Types._Entity.initFragments(_Entity, __Entity);
			Types._Form.initFragments(_Form, __Form);
			Types._Image.initFragments(_Image, __Image);
			Types._Instant.initFragments(_Instant, __Instant);
			Types._List.initFragments(_List, __List);
			Types._MethodType.initFragments(_MethodType, __MethodType);
			Types._NamedIdentifier.initFragments(_NamedIdentifier, __NamedIdentifier);
			Types._Page.initFragments(_Page, __Page);
			Types._RefactoredWebApplication.initFragments(_RefactoredWebApplication, __RefactoredWebApplication);
			Types._Reference.initFragments(_Reference, __Reference);
			Types._SContent.initFragments(_SContent, __SContent);
			Types._Video.initFragments(_Video, __Video);
			Types._VisualMedia.initFragments(_VisualMedia, __VisualMedia);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::TypeFragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local operations or local operation overrides for each fragment of each type.
	 */
	public static class FragmentOperations {
		static {
			Init.initStart();
			TypeFragments.init();
		}

		private static final ExecutorOperation /*@NonNull*/ [] _Administrator__Administrator = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Administrator__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Administrator__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__Attribute = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Content__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Content__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Content__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Content__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _DContent__DContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DContent__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DContent__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DContent__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DContent__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _DataType__DataType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Detail__Detail = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Detail__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Detail__DContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Detail__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Detail__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Detail__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _DisplayMode__DisplayMode = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DisplayMode__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DisplayMode__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DisplayMode__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DisplayMode__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Element__Element = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Element__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Element__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Element__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__ElementType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Entity__Entity = {
			RefactoredWebTables.Operations._Entity__primaryKeyName /* primaryKeyName() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Entity__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Entity__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Entity__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Form__Form = {
			RefactoredWebTables.Operations._Form__getElementQty /* getElementQty() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__SContent = {};

		private static final ExecutorOperation /*@NonNull*/ [] _Image__Image = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Image__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Image__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Image__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Image__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Image__SContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Image__VisualMedia = {};

		private static final ExecutorOperation /*@NonNull*/ [] _Instant__Instant = {
			RefactoredWebTables.Operations._Instant__compareTo /* compareTo(OclSelf[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Instant__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Instant__OclComparable = {
			OCLstdlibTables.Operations._OclComparable___lt_ /* _'<'(OclSelf[1]) */,
			OCLstdlibTables.Operations._OclComparable___lt__eq_ /* _'<='(OclSelf[1]) */,
			OCLstdlibTables.Operations._OclComparable___gt_ /* _'>'(OclSelf[1]) */,
			OCLstdlibTables.Operations._OclComparable___gt__eq_ /* _'>='(OclSelf[1]) */,
			RefactoredWebTables.Operations._Instant__compareTo /* compareTo(OclSelf[1]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _List__List = {};
		private static final ExecutorOperation /*@NonNull*/ [] _List__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _List__DContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _List__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _List__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _List__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__MethodType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _NamedIdentifier__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _NamedIdentifier__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _NamedIdentifier__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Page__Page = {
			RefactoredWebTables.Operations._Page__getDynamicContentQty /* getDynamicContentQty() */,
			RefactoredWebTables.Operations._Page__getStaticContentQty /* getStaticContentQty() */,
			RefactoredWebTables.Operations._Page__isNotEmpty /* isNotEmpty() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Page__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Page__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Page__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _RefactoredWebApplication__RefactoredWebApplication = {};
		private static final ExecutorOperation /*@NonNull*/ [] _RefactoredWebApplication__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _RefactoredWebApplication__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _RefactoredWebApplication__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Reference__Reference = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _SContent__SContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _SContent__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _SContent__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _SContent__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _SContent__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Video__Video = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Video__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Video__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Video__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Video__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Video__SContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Video__VisualMedia = {};

		private static final ExecutorOperation /*@NonNull*/ [] _VisualMedia__VisualMedia = {};
		private static final ExecutorOperation /*@NonNull*/ [] _VisualMedia__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _VisualMedia__NamedIdentifier = {};
		private static final ExecutorOperation /*@NonNull*/ [] _VisualMedia__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _VisualMedia__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _VisualMedia__SContent = {};

		/*
		 *	Install the operation descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Administrator__Administrator.initOperations(_Administrator__Administrator);
			Fragments._Administrator__OclAny.initOperations(_Administrator__OclAny);
			Fragments._Administrator__OclElement.initOperations(_Administrator__OclElement);

			Fragments._Attribute__Attribute.initOperations(_Attribute__Attribute);
			Fragments._Attribute__NamedIdentifier.initOperations(_Attribute__NamedIdentifier);
			Fragments._Attribute__OclAny.initOperations(_Attribute__OclAny);
			Fragments._Attribute__OclElement.initOperations(_Attribute__OclElement);

			Fragments._Content__Content.initOperations(_Content__Content);
			Fragments._Content__NamedIdentifier.initOperations(_Content__NamedIdentifier);
			Fragments._Content__OclAny.initOperations(_Content__OclAny);
			Fragments._Content__OclElement.initOperations(_Content__OclElement);

			Fragments._DContent__Content.initOperations(_DContent__Content);
			Fragments._DContent__DContent.initOperations(_DContent__DContent);
			Fragments._DContent__NamedIdentifier.initOperations(_DContent__NamedIdentifier);
			Fragments._DContent__OclAny.initOperations(_DContent__OclAny);
			Fragments._DContent__OclElement.initOperations(_DContent__OclElement);

			Fragments._DataType__DataType.initOperations(_DataType__DataType);
			Fragments._DataType__OclAny.initOperations(_DataType__OclAny);
			Fragments._DataType__OclElement.initOperations(_DataType__OclElement);
			Fragments._DataType__OclEnumeration.initOperations(_DataType__OclEnumeration);
			Fragments._DataType__OclType.initOperations(_DataType__OclType);

			Fragments._Detail__Content.initOperations(_Detail__Content);
			Fragments._Detail__DContent.initOperations(_Detail__DContent);
			Fragments._Detail__Detail.initOperations(_Detail__Detail);
			Fragments._Detail__NamedIdentifier.initOperations(_Detail__NamedIdentifier);
			Fragments._Detail__OclAny.initOperations(_Detail__OclAny);
			Fragments._Detail__OclElement.initOperations(_Detail__OclElement);

			Fragments._DisplayMode__DisplayMode.initOperations(_DisplayMode__DisplayMode);
			Fragments._DisplayMode__OclAny.initOperations(_DisplayMode__OclAny);
			Fragments._DisplayMode__OclElement.initOperations(_DisplayMode__OclElement);
			Fragments._DisplayMode__OclEnumeration.initOperations(_DisplayMode__OclEnumeration);
			Fragments._DisplayMode__OclType.initOperations(_DisplayMode__OclType);

			Fragments._Element__Element.initOperations(_Element__Element);
			Fragments._Element__NamedIdentifier.initOperations(_Element__NamedIdentifier);
			Fragments._Element__OclAny.initOperations(_Element__OclAny);
			Fragments._Element__OclElement.initOperations(_Element__OclElement);

			Fragments._ElementType__ElementType.initOperations(_ElementType__ElementType);
			Fragments._ElementType__OclAny.initOperations(_ElementType__OclAny);
			Fragments._ElementType__OclElement.initOperations(_ElementType__OclElement);
			Fragments._ElementType__OclEnumeration.initOperations(_ElementType__OclEnumeration);
			Fragments._ElementType__OclType.initOperations(_ElementType__OclType);

			Fragments._Entity__Entity.initOperations(_Entity__Entity);
			Fragments._Entity__NamedIdentifier.initOperations(_Entity__NamedIdentifier);
			Fragments._Entity__OclAny.initOperations(_Entity__OclAny);
			Fragments._Entity__OclElement.initOperations(_Entity__OclElement);

			Fragments._Form__Content.initOperations(_Form__Content);
			Fragments._Form__Form.initOperations(_Form__Form);
			Fragments._Form__NamedIdentifier.initOperations(_Form__NamedIdentifier);
			Fragments._Form__OclAny.initOperations(_Form__OclAny);
			Fragments._Form__OclElement.initOperations(_Form__OclElement);
			Fragments._Form__SContent.initOperations(_Form__SContent);

			Fragments._Image__Content.initOperations(_Image__Content);
			Fragments._Image__Image.initOperations(_Image__Image);
			Fragments._Image__NamedIdentifier.initOperations(_Image__NamedIdentifier);
			Fragments._Image__OclAny.initOperations(_Image__OclAny);
			Fragments._Image__OclElement.initOperations(_Image__OclElement);
			Fragments._Image__SContent.initOperations(_Image__SContent);
			Fragments._Image__VisualMedia.initOperations(_Image__VisualMedia);

			Fragments._Instant__Instant.initOperations(_Instant__Instant);
			Fragments._Instant__OclAny.initOperations(_Instant__OclAny);
			Fragments._Instant__OclComparable.initOperations(_Instant__OclComparable);

			Fragments._List__Content.initOperations(_List__Content);
			Fragments._List__DContent.initOperations(_List__DContent);
			Fragments._List__List.initOperations(_List__List);
			Fragments._List__NamedIdentifier.initOperations(_List__NamedIdentifier);
			Fragments._List__OclAny.initOperations(_List__OclAny);
			Fragments._List__OclElement.initOperations(_List__OclElement);

			Fragments._MethodType__MethodType.initOperations(_MethodType__MethodType);
			Fragments._MethodType__OclAny.initOperations(_MethodType__OclAny);
			Fragments._MethodType__OclElement.initOperations(_MethodType__OclElement);
			Fragments._MethodType__OclEnumeration.initOperations(_MethodType__OclEnumeration);
			Fragments._MethodType__OclType.initOperations(_MethodType__OclType);

			Fragments._NamedIdentifier__NamedIdentifier.initOperations(_NamedIdentifier__NamedIdentifier);
			Fragments._NamedIdentifier__OclAny.initOperations(_NamedIdentifier__OclAny);
			Fragments._NamedIdentifier__OclElement.initOperations(_NamedIdentifier__OclElement);

			Fragments._Page__NamedIdentifier.initOperations(_Page__NamedIdentifier);
			Fragments._Page__OclAny.initOperations(_Page__OclAny);
			Fragments._Page__OclElement.initOperations(_Page__OclElement);
			Fragments._Page__Page.initOperations(_Page__Page);

			Fragments._RefactoredWebApplication__NamedIdentifier.initOperations(_RefactoredWebApplication__NamedIdentifier);
			Fragments._RefactoredWebApplication__OclAny.initOperations(_RefactoredWebApplication__OclAny);
			Fragments._RefactoredWebApplication__OclElement.initOperations(_RefactoredWebApplication__OclElement);
			Fragments._RefactoredWebApplication__RefactoredWebApplication.initOperations(_RefactoredWebApplication__RefactoredWebApplication);

			Fragments._Reference__NamedIdentifier.initOperations(_Reference__NamedIdentifier);
			Fragments._Reference__OclAny.initOperations(_Reference__OclAny);
			Fragments._Reference__OclElement.initOperations(_Reference__OclElement);
			Fragments._Reference__Reference.initOperations(_Reference__Reference);

			Fragments._SContent__Content.initOperations(_SContent__Content);
			Fragments._SContent__NamedIdentifier.initOperations(_SContent__NamedIdentifier);
			Fragments._SContent__OclAny.initOperations(_SContent__OclAny);
			Fragments._SContent__OclElement.initOperations(_SContent__OclElement);
			Fragments._SContent__SContent.initOperations(_SContent__SContent);

			Fragments._Video__Content.initOperations(_Video__Content);
			Fragments._Video__NamedIdentifier.initOperations(_Video__NamedIdentifier);
			Fragments._Video__OclAny.initOperations(_Video__OclAny);
			Fragments._Video__OclElement.initOperations(_Video__OclElement);
			Fragments._Video__SContent.initOperations(_Video__SContent);
			Fragments._Video__Video.initOperations(_Video__Video);
			Fragments._Video__VisualMedia.initOperations(_Video__VisualMedia);

			Fragments._VisualMedia__Content.initOperations(_VisualMedia__Content);
			Fragments._VisualMedia__NamedIdentifier.initOperations(_VisualMedia__NamedIdentifier);
			Fragments._VisualMedia__OclAny.initOperations(_VisualMedia__OclAny);
			Fragments._VisualMedia__OclElement.initOperations(_VisualMedia__OclElement);
			Fragments._VisualMedia__SContent.initOperations(_VisualMedia__SContent);
			Fragments._VisualMedia__VisualMedia.initOperations(_VisualMedia__VisualMedia);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::FragmentOperations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local properties for the local fragment of each type.
	 */
	public static class FragmentProperties {
		static {
			Init.initStart();
			FragmentOperations.init();
		}

		private static final ExecutorProperty /*@NonNull*/ [] _Administrator = {
			RefactoredWebTables.Properties._Administrator__firstName,
			RefactoredWebTables.Properties._Administrator__fullName,
			RefactoredWebTables.Properties._Administrator__id,
			RefactoredWebTables.Properties._Administrator__lastName,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Attribute = {
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._Attribute__isPK,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._Attribute__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Content = {
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _DContent = {
			RefactoredWebTables.Properties._DContent__attributes,
			RefactoredWebTables.Properties._DContent__entity,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _DataType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Detail = {
			RefactoredWebTables.Properties._DContent__attributes,
			RefactoredWebTables.Properties._DContent__entity,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _DisplayMode = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Element = {
			RefactoredWebTables.Properties._Element__attribute,
			RefactoredWebTables.Properties._Element__form,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._Element__label,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._Element__tooltip,
			RefactoredWebTables.Properties._Element__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _ElementType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Entity = {
			RefactoredWebTables.Properties._Entity__attributes,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._Entity__references
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Form = {
			RefactoredWebTables.Properties._Form__elements,
			RefactoredWebTables.Properties._Form__entity,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._Form__method,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Image = {
			RefactoredWebTables.Properties._VisualMedia__altText,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._VisualMedia__mediaClassification,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._VisualMedia__size,
			RefactoredWebTables.Properties._VisualMedia__source
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Instant = {};

		private static final ExecutorProperty /*@NonNull*/ [] _List = {
			RefactoredWebTables.Properties._DContent__attributes,
			RefactoredWebTables.Properties._DContent__entity,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _MethodType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _NamedIdentifier = {
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Page = {
			RefactoredWebTables.Properties._Page__contents,
			RefactoredWebTables.Properties._Page__createdAt,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._Page__link,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._Page__totalMediaSize,
			RefactoredWebTables.Properties._Page__webApplication
		};

		private static final ExecutorProperty /*@NonNull*/ [] _RefactoredWebApplication = {
			RefactoredWebTables.Properties._RefactoredWebApplication__admin,
			RefactoredWebTables.Properties._RefactoredWebApplication__currentSysAdmin,
			RefactoredWebTables.Properties._RefactoredWebApplication__displayMode,
			RefactoredWebTables.Properties._RefactoredWebApplication__entities,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._RefactoredWebApplication__pages,
			RefactoredWebTables.Properties._RefactoredWebApplication__totalPages
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Reference = {
			RefactoredWebTables.Properties._Reference__foreignKey,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _SContent = {
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Video = {
			RefactoredWebTables.Properties._VisualMedia__altText,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._VisualMedia__mediaClassification,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._VisualMedia__size,
			RefactoredWebTables.Properties._VisualMedia__source
		};

		private static final ExecutorProperty /*@NonNull*/ [] _VisualMedia = {
			RefactoredWebTables.Properties._VisualMedia__altText,
			RefactoredWebTables.Properties._NamedIdentifier__id,
			RefactoredWebTables.Properties._VisualMedia__mediaClassification,
			RefactoredWebTables.Properties._NamedIdentifier__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			RefactoredWebTables.Properties._VisualMedia__size,
			RefactoredWebTables.Properties._VisualMedia__source
		};

		/**
		 *	Install the property descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Administrator__Administrator.initProperties(_Administrator);
			Fragments._Attribute__Attribute.initProperties(_Attribute);
			Fragments._Content__Content.initProperties(_Content);
			Fragments._DContent__DContent.initProperties(_DContent);
			Fragments._DataType__DataType.initProperties(_DataType);
			Fragments._Detail__Detail.initProperties(_Detail);
			Fragments._DisplayMode__DisplayMode.initProperties(_DisplayMode);
			Fragments._Element__Element.initProperties(_Element);
			Fragments._ElementType__ElementType.initProperties(_ElementType);
			Fragments._Entity__Entity.initProperties(_Entity);
			Fragments._Form__Form.initProperties(_Form);
			Fragments._Image__Image.initProperties(_Image);
			Fragments._Instant__Instant.initProperties(_Instant);
			Fragments._List__List.initProperties(_List);
			Fragments._MethodType__MethodType.initProperties(_MethodType);
			Fragments._NamedIdentifier__NamedIdentifier.initProperties(_NamedIdentifier);
			Fragments._Page__Page.initProperties(_Page);
			Fragments._RefactoredWebApplication__RefactoredWebApplication.initProperties(_RefactoredWebApplication);
			Fragments._Reference__Reference.initProperties(_Reference);
			Fragments._SContent__SContent.initProperties(_SContent);
			Fragments._Video__Video.initProperties(_Video);
			Fragments._VisualMedia__VisualMedia.initProperties(_VisualMedia);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::FragmentProperties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of enumeration literals for each enumeration.
	 */
	public static class EnumerationLiterals {
		static {
			Init.initStart();
			FragmentProperties.init();
		}

		public static final EcoreExecutorEnumerationLiteral _DataType__string = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("string"), Types._DataType, 0);
		public static final EcoreExecutorEnumerationLiteral _DataType__int = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("int"), Types._DataType, 1);
		public static final EcoreExecutorEnumerationLiteral _DataType__text = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("text"), Types._DataType, 2);
		public static final EcoreExecutorEnumerationLiteral _DataType__bool = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("bool"), Types._DataType, 3);
		public static final EcoreExecutorEnumerationLiteral _DataType__date = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("date"), Types._DataType, 4);
		public static final EcoreExecutorEnumerationLiteral _DataType__file = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("file"), Types._DataType, 5);
		public static final EcoreExecutorEnumerationLiteral _DataType__currency = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("currency"), Types._DataType, 6);
		public static final EcoreExecutorEnumerationLiteral _DataType__percent = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("percent"), Types._DataType, 7);
		public static final EcoreExecutorEnumerationLiteral _DataType__image = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("image"), Types._DataType, 8);
		public static final EcoreExecutorEnumerationLiteral _DataType__images = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("images"), Types._DataType, 9);
		public static final EcoreExecutorEnumerationLiteral _DataType__email = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("email"), Types._DataType, 10);
		public static final EcoreExecutorEnumerationLiteral _DataType__password = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DATA_TYPE.getEEnumLiteral("password"), Types._DataType, 11);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _DataType = {
			_DataType__string,
			_DataType__int,
			_DataType__text,
			_DataType__bool,
			_DataType__date,
			_DataType__file,
			_DataType__currency,
			_DataType__percent,
			_DataType__image,
			_DataType__images,
			_DataType__email,
			_DataType__password
		};

		public static final EcoreExecutorEnumerationLiteral _DisplayMode__light = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DISPLAY_MODE.getEEnumLiteral("light"), Types._DisplayMode, 0);
		public static final EcoreExecutorEnumerationLiteral _DisplayMode__dark = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.DISPLAY_MODE.getEEnumLiteral("dark"), Types._DisplayMode, 1);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _DisplayMode = {
			_DisplayMode__light,
			_DisplayMode__dark
		};

		public static final EcoreExecutorEnumerationLiteral _ElementType__textBox = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("textBox"), Types._ElementType, 0);
		public static final EcoreExecutorEnumerationLiteral _ElementType__button = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("button"), Types._ElementType, 1);
		public static final EcoreExecutorEnumerationLiteral _ElementType__checkBox = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("checkBox"), Types._ElementType, 2);
		public static final EcoreExecutorEnumerationLiteral _ElementType__radioButton = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("radioButton"), Types._ElementType, 3);
		public static final EcoreExecutorEnumerationLiteral _ElementType__dropDown = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("dropDown"), Types._ElementType, 4);
		public static final EcoreExecutorEnumerationLiteral _ElementType__textArea = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("textArea"), Types._ElementType, 5);
		public static final EcoreExecutorEnumerationLiteral _ElementType__date = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("date"), Types._ElementType, 6);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _ElementType = {
			_ElementType__textBox,
			_ElementType__button,
			_ElementType__checkBox,
			_ElementType__radioButton,
			_ElementType__dropDown,
			_ElementType__textArea,
			_ElementType__date
		};

		public static final EcoreExecutorEnumerationLiteral _MethodType__POST = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.METHOD_TYPE.getEEnumLiteral("POST"), Types._MethodType, 0);
		public static final EcoreExecutorEnumerationLiteral _MethodType__PUT = new EcoreExecutorEnumerationLiteral(RefactoredWebPackage.Literals.METHOD_TYPE.getEEnumLiteral("PUT"), Types._MethodType, 1);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _MethodType = {
			_MethodType__POST,
			_MethodType__PUT
		};

		/**
		 *	Install the enumeration literals in the enumerations.
		 */
		static {
			Types._DataType.initLiterals(_DataType);
			Types._DisplayMode.initLiterals(_DisplayMode);
			Types._ElementType.initLiterals(_ElementType);
			Types._MethodType.initLiterals(_MethodType);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of RefactoredWebTables::EnumerationLiterals and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 * The multiple packages above avoid problems with the Java 65536 byte limit but introduce a difficulty in ensuring that
	 * static construction occurs in the disciplined order of the packages when construction may start in any of the packages.
	 * The problem is resolved by ensuring that the static construction of each package first initializes its immediate predecessor.
	 * On completion of predecessor initialization, the residual packages are initialized by starting an initialization in the last package.
	 * This class maintains a count so that the various predecessors can distinguish whether they are the starting point and so
	 * ensure that residual construction occurs just once after all predecessors.
	 */
	private static class Init {
		/**
		 * Counter of nested static constructions. On return to zero residual construction starts. -ve once residual construction started.
		 */
		private static int initCount = 0;

		/**
		 * Invoked at the start of a static construction to defer residual construction until primary constructions complete.
		 */
		private static void initStart() {
			if (initCount >= 0) {
				initCount++;
			}
		}

		/**
		 * Invoked at the end of a static construction to activate residual construction once primary constructions complete.
		 */
		private static void initEnd() {
			if (initCount > 0) {
				if (--initCount == 0) {
					initCount = -1;
					EnumerationLiterals.init();
				}
			}
		}
	}

	static {
		Init.initEnd();
	}

	/*
	 * Force initialization of outer fields. Inner fields are lazily initialized.
	 */
	public static void init() {
		new RefactoredWebTables();
	}

	private RefactoredWebTables() {
		super(RefactoredWebPackage.eNS_URI);
	}
}
