/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl;

import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.SContent;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SContent</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class SContentImpl extends ContentImpl implements SContent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SContentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RefactoredWebPackage.Literals.SCONTENT;
	}

} //SContentImpl
