/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getEntities <em>Entities</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getPages <em>Pages</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getTotalPages <em>Total Pages</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getDisplayMode <em>Display Mode</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getAdmin <em>Admin</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getCurrentSysAdmin <em>Current Sys Admin</em>}</li>
 * </ul>
 *
 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueEntityNames'"
 * @generated
 */
public interface RefactoredWebApplication extends NamedIdentifier {
	/**
	 * Returns the value of the '<em><b>Entities</b></em>' containment reference list.
	 * The list contents are of type {@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Entity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entities</em>' containment reference list.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication_Entities()
	 * @model containment="true"
	 * @generated
	 */
	EList<Entity> getEntities();

	/**
	 * Returns the value of the '<em><b>Pages</b></em>' containment reference list.
	 * The list contents are of type {@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page}.
	 * It is bidirectional and its opposite is '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getWebApplication <em>Web Application</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pages</em>' containment reference list.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication_Pages()
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page#getWebApplication
	 * @model opposite="webApplication" containment="true"
	 * @generated
	 */
	EList<Page> getPages();

	/**
	 * Returns the value of the '<em><b>Total Pages</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Pages</em>' attribute.
	 * @see #setTotalPages(int)
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication_TotalPages()
	 * @model required="true" volatile="true" derived="true"
	 * @generated
	 */
	int getTotalPages();

	/**
	 * Sets the value of the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getTotalPages <em>Total Pages</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Pages</em>' attribute.
	 * @see #getTotalPages()
	 * @generated
	 */
	void setTotalPages(int value);

	/**
	 * Returns the value of the '<em><b>Display Mode</b></em>' attribute.
	 * The literals are from the enumeration {@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Display Mode</em>' attribute.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode
	 * @see #setDisplayMode(DisplayMode)
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication_DisplayMode()
	 * @model
	 * @generated
	 */
	DisplayMode getDisplayMode();

	/**
	 * Sets the value of the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication#getDisplayMode <em>Display Mode</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Display Mode</em>' attribute.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.DisplayMode
	 * @see #getDisplayMode()
	 * @generated
	 */
	void setDisplayMode(DisplayMode value);

	/**
	 * Returns the value of the '<em><b>Admin</b></em>' containment reference list.
	 * The list contents are of type {@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Admin</em>' containment reference list.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication_Admin()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Administrator> getAdmin();

	/**
	 * Returns the value of the '<em><b>Current Sys Admin</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Current Sys Admin</em>' attribute list.
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getRefactoredWebApplication_CurrentSysAdmin()
	 * @model required="true"
	 * @generated
	 */
	EList<String> getCurrentSysAdmin();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='pages.name-&gt;asSet()-&gt;size() = pages-&gt;size()'"
	 * @generated
	 */
	boolean UniquePageNames(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='pages-&gt;size() &gt;= 1'"
	 * @generated
	 */
	boolean AtLeastOnePage(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='entities-&gt;size() &gt;= 1'"
	 * @generated
	 */
	boolean AtLeastOneEntity(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='entities.name-&gt;asSet()-&gt;size() = entities-&gt;size()'"
	 * @generated
	 */
	boolean UniqueEntityNames(DiagnosticChain diagnostics, Map<Object, Object> context);

} // RefactoredWebApplication
