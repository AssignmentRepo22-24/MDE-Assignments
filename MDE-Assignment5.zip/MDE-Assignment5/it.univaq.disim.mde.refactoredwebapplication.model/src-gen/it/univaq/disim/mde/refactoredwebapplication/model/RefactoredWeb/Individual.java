/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Individual</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getIndividual()
 * @model
 * @generated
 */
public interface Individual extends DContent {
} // Individual
