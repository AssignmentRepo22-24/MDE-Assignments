/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Administrator</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFirstName <em>First Name</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getLastName <em>Last Name</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getId <em>Id</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFullName <em>Full Name</em>}</li>
 * </ul>
 *
 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getAdministrator()
 * @model
 * @generated
 */
public interface Administrator extends EObject {
	/**
	 * Returns the value of the '<em><b>First Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>First Name</em>' attribute.
	 * @see #setFirstName(String)
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getAdministrator_FirstName()
	 * @model required="true"
	 * @generated
	 */
	String getFirstName();

	/**
	 * Sets the value of the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFirstName <em>First Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>First Name</em>' attribute.
	 * @see #getFirstName()
	 * @generated
	 */
	void setFirstName(String value);

	/**
	 * Returns the value of the '<em><b>Last Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Last Name</em>' attribute.
	 * @see #setLastName(String)
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getAdministrator_LastName()
	 * @model required="true"
	 * @generated
	 */
	String getLastName();

	/**
	 * Sets the value of the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getLastName <em>Last Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Last Name</em>' attribute.
	 * @see #getLastName()
	 * @generated
	 */
	void setLastName(String value);

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(int)
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getAdministrator_Id()
	 * @model required="true"
	 * @generated
	 */
	int getId();

	/**
	 * Sets the value of the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	void setId(int value);

	/**
	 * Returns the value of the '<em><b>Full Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Full Name</em>' attribute.
	 * @see #setFullName(String)
	 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getAdministrator_FullName()
	 * @model required="true"
	 * @generated
	 */
	String getFullName();

	/**
	 * Sets the value of the '{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Administrator#getFullName <em>Full Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Full Name</em>' attribute.
	 * @see #getFullName()
	 * @generated
	 */
	void setFullName(String value);

} // Administrator
