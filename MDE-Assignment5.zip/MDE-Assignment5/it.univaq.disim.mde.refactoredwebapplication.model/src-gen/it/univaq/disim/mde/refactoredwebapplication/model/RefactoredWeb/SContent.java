/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SContent</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage#getSContent()
 * @model abstract="true"
 * @generated
 */
public interface SContent extends Content {
} // SContent
