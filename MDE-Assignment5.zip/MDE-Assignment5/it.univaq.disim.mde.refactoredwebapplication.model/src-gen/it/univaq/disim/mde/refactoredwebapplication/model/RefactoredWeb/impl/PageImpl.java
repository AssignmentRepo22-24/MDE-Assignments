/**
 */
package it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl;

import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Content;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.Page;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebApplication;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebPackage;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.RefactoredWebTables;
import it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.VisualMedia;

import java.lang.reflect.InvocationTargetException;

import java.math.BigDecimal;
import java.math.BigInteger;

import java.time.Instant;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.ocl.pivot.evaluation.Executor;

import org.eclipse.ocl.pivot.ids.IdResolver;
import org.eclipse.ocl.pivot.ids.TypeId;

import org.eclipse.ocl.pivot.library.collection.CollectionNotEmptyOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionSizeOperation;
import org.eclipse.ocl.pivot.library.collection.CollectionSumOperation;

import org.eclipse.ocl.pivot.library.oclany.OclAnyOclAsTypeOperation;
import org.eclipse.ocl.pivot.library.oclany.OclAnyOclIsKindOfOperation;
import org.eclipse.ocl.pivot.library.oclany.OclAnyOclIsTypeOfOperation;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanEqualOperation;

import org.eclipse.ocl.pivot.library.string.CGStringGetSeverityOperation;
import org.eclipse.ocl.pivot.library.string.CGStringLogDiagnosticOperation;

import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;

import org.eclipse.ocl.pivot.values.IntegerValue;
import org.eclipse.ocl.pivot.values.OrderedSetValue;

import org.eclipse.ocl.pivot.values.OrderedSetValue.Accumulator;

import org.eclipse.ocl.pivot.values.RealValue;
import org.eclipse.ocl.pivot.values.SequenceValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Page</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl#getTotalMediaSize <em>Total Media Size</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl#getLink <em>Link</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl#getContents <em>Contents</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl#getWebApplication <em>Web Application</em>}</li>
 *   <li>{@link it.univaq.disim.mde.refactoredwebapplication.model.RefactoredWeb.impl.PageImpl#getCreatedAt <em>Created At</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PageImpl extends NamedIdentifierImpl implements Page {
	/**
	 * The default value of the '{@link #getTotalMediaSize() <em>Total Media Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTotalMediaSize()
	 * @generated
	 * @ordered
	 */
	protected static final double TOTAL_MEDIA_SIZE_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getLink() <em>Link</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLink()
	 * @generated
	 * @ordered
	 */
	protected EList<Page> link;

	/**
	 * The cached value of the '{@link #getContents() <em>Contents</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContents()
	 * @generated
	 * @ordered
	 */
	protected EList<Content> contents;

	/**
	 * The default value of the '{@link #getCreatedAt() <em>Created At</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreatedAt()
	 * @generated
	 * @ordered
	 */
	protected static final Instant CREATED_AT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCreatedAt() <em>Created At</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCreatedAt()
	 * @generated
	 * @ordered
	 */
	protected Instant createdAt = CREATED_AT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RefactoredWebPackage.Literals.PAGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getTotalMediaSize() {
		/**
		 *
		 * contents->select(e | e.oclIsTypeOf(VisualMedia))
		 * ->collect(e | e.oclAsType(VisualMedia).size)
		 * ->sum()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ List<Content> contents = this.getContents();
		final /*@NonInvalid*/ OrderedSetValue BOXED_contents = idResolver
				.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Content, contents);
		/*@Thrown*/ Accumulator accumulator = ValueUtil
				.createOrderedSetAccumulatorValue(RefactoredWebTables.ORD_CLSSid_Content);
		Iterator<Object> ITERATOR_e_0 = BOXED_contents.iterator();
		/*@NonInvalid*/ OrderedSetValue select;
		while (true) {
			if (!ITERATOR_e_0.hasNext()) {
				select = accumulator;
				break;
			}
			/*@NonInvalid*/ Content e_0 = (Content) ITERATOR_e_0.next();
			/**
			 * e.oclIsTypeOf(VisualMedia)
			 */
			final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_RefactoredWeb_c_c_VisualMedia_0 = idResolver
					.getClass(RefactoredWebTables.CLSSid_VisualMedia, null);
			final /*@NonInvalid*/ boolean oclIsTypeOf = OclAnyOclIsTypeOfOperation.INSTANCE
					.evaluate(executor, e_0, TYP_RefactoredWeb_c_c_VisualMedia_0).booleanValue();
			//
			if (oclIsTypeOf) {
				accumulator.add(e_0);
			}
		}
		/*@Thrown*/ org.eclipse.ocl.pivot.values.SequenceValue.Accumulator accumulator_0 = ValueUtil
				.createSequenceAccumulatorValue(RefactoredWebTables.SEQ_PRIMid_Real);
		Iterator<Object> ITERATOR_e_1 = select.iterator();
		/*@Thrown*/ SequenceValue collect;
		while (true) {
			if (!ITERATOR_e_1.hasNext()) {
				collect = accumulator_0;
				break;
			}
			/*@NonInvalid*/ Content e_1 = (Content) ITERATOR_e_1.next();
			/**
			 * e.oclAsType(VisualMedia).size
			 */
			final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_RefactoredWeb_c_c_VisualMedia_1 = idResolver
					.getClass(RefactoredWebTables.CLSSid_VisualMedia, null);
			final /*@Thrown*/ VisualMedia oclAsType = (VisualMedia) OclAnyOclAsTypeOperation.INSTANCE.evaluate(executor,
					e_1, TYP_RefactoredWeb_c_c_VisualMedia_1);
			final /*@Thrown*/ BigDecimal size = oclAsType.getSize();
			final /*@Thrown*/ RealValue BOXED_size = ValueUtil.realValueOf(size);
			//
			accumulator_0.add(BOXED_size);
		}
		final /*@Thrown*/ RealValue sum = (RealValue) CollectionSumOperation.INSTANCE.evaluate(executor, TypeId.REAL,
				collect);
		final /*@Thrown*/ double ECORE_sum = ValueUtil.doubleValueOf(sum);
		return ECORE_sum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTotalMediaSize(double newTotalMediaSize) {
		// TODO: implement this method to set the 'Total Media Size' attribute
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Page> getLink() {
		if (link == null) {
			link = new EObjectResolvingEList<Page>(Page.class, this, RefactoredWebPackage.PAGE__LINK);
		}
		return link;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Content> getContents() {
		if (contents == null) {
			contents = new EObjectContainmentEList<Content>(Content.class, this, RefactoredWebPackage.PAGE__CONTENTS);
		}
		return contents;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RefactoredWebApplication getWebApplication() {
		if (eContainerFeatureID() != RefactoredWebPackage.PAGE__WEB_APPLICATION)
			return null;
		return (RefactoredWebApplication) eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetWebApplication(RefactoredWebApplication newWebApplication,
			NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject) newWebApplication, RefactoredWebPackage.PAGE__WEB_APPLICATION,
				msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWebApplication(RefactoredWebApplication newWebApplication) {
		if (newWebApplication != eInternalContainer()
				|| (eContainerFeatureID() != RefactoredWebPackage.PAGE__WEB_APPLICATION && newWebApplication != null)) {
			if (EcoreUtil.isAncestor(this, newWebApplication))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newWebApplication != null)
				msgs = ((InternalEObject) newWebApplication).eInverseAdd(this,
						RefactoredWebPackage.REFACTORED_WEB_APPLICATION__PAGES, RefactoredWebApplication.class, msgs);
			msgs = basicSetWebApplication(newWebApplication, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RefactoredWebPackage.PAGE__WEB_APPLICATION,
					newWebApplication, newWebApplication));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Instant getCreatedAt() {
		return createdAt;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCreatedAt(Instant newCreatedAt) {
		Instant oldCreatedAt = createdAt;
		createdAt = newCreatedAt;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, RefactoredWebPackage.PAGE__CREATED_AT, oldCreatedAt,
					createdAt));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Boolean isNotEmpty() {
		/**
		 * contents->notEmpty()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ List<Content> contents = this.getContents();
		final /*@NonInvalid*/ OrderedSetValue BOXED_contents = idResolver
				.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Content, contents);
		final /*@NonInvalid*/ boolean notEmpty = CollectionNotEmptyOperation.INSTANCE.evaluate(BOXED_contents)
				.booleanValue();
		return notEmpty;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigInteger getStaticContentQty() {
		/**
		 *
		 * contents->select(e | e.oclIsKindOf(SContent))
		 * ->size()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ List<Content> contents = this.getContents();
		final /*@NonInvalid*/ OrderedSetValue BOXED_contents = idResolver
				.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Content, contents);
		/*@Thrown*/ Accumulator accumulator = ValueUtil
				.createOrderedSetAccumulatorValue(RefactoredWebTables.ORD_CLSSid_Content);
		Iterator<Object> ITERATOR_e_0 = BOXED_contents.iterator();
		/*@NonInvalid*/ OrderedSetValue select;
		while (true) {
			if (!ITERATOR_e_0.hasNext()) {
				select = accumulator;
				break;
			}
			/*@NonInvalid*/ Content e_0 = (Content) ITERATOR_e_0.next();
			/**
			 * e.oclIsKindOf(SContent)
			 */
			final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_RefactoredWeb_c_c_SContent_0 = idResolver
					.getClass(RefactoredWebTables.CLSSid_SContent, null);
			final /*@NonInvalid*/ boolean oclIsKindOf = OclAnyOclIsKindOfOperation.INSTANCE
					.evaluate(executor, e_0, TYP_RefactoredWeb_c_c_SContent_0).booleanValue();
			//
			if (oclIsKindOf) {
				accumulator.add(e_0);
			}
		}
		final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(select);
		final BigInteger ECORE_size = ValueUtil.bigIntegerValueOf(size);
		return ECORE_size;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigInteger getDynamicContentQty() {
		/**
		 *
		 * contents->select(e | e.oclIsKindOf(DContent))
		 * ->size()
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ IdResolver idResolver = executor.getIdResolver();
		final /*@NonInvalid*/ List<Content> contents = this.getContents();
		final /*@NonInvalid*/ OrderedSetValue BOXED_contents = idResolver
				.createOrderedSetOfAll(RefactoredWebTables.ORD_CLSSid_Content, contents);
		/*@Thrown*/ Accumulator accumulator = ValueUtil
				.createOrderedSetAccumulatorValue(RefactoredWebTables.ORD_CLSSid_Content);
		Iterator<Object> ITERATOR_e_0 = BOXED_contents.iterator();
		/*@NonInvalid*/ OrderedSetValue select;
		while (true) {
			if (!ITERATOR_e_0.hasNext()) {
				select = accumulator;
				break;
			}
			/*@NonInvalid*/ Content e_0 = (Content) ITERATOR_e_0.next();
			/**
			 * e.oclIsKindOf(DContent)
			 */
			final /*@NonInvalid*/ org.eclipse.ocl.pivot.Class TYP_RefactoredWeb_c_c_DContent_0 = idResolver
					.getClass(RefactoredWebTables.CLSSid_DContent, null);
			final /*@NonInvalid*/ boolean oclIsKindOf = OclAnyOclIsKindOfOperation.INSTANCE
					.evaluate(executor, e_0, TYP_RefactoredWeb_c_c_DContent_0).booleanValue();
			//
			if (oclIsKindOf) {
				accumulator.add(e_0);
			}
		}
		final /*@NonInvalid*/ IntegerValue size = CollectionSizeOperation.INSTANCE.evaluate(select);
		final BigInteger ECORE_size = ValueUtil.bigIntegerValueOf(size);
		return ECORE_size;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean OptimisePageLoad(final DiagnosticChain diagnostics, final Map<Object, Object> context) {
		final String constraintName = "Page::OptimisePageLoad";
		try {
			/**
			 *
			 * inv OptimisePageLoad:
			 *   let severity : Integer[1] = constraintName.getSeverity()
			 *   in
			 *     if severity <= 0
			 *     then true
			 *     else
			 *       let result : Boolean[1] = totalMediaSize <= 50
			 *       in
			 *         constraintName.logDiagnostic(self, null, diagnostics, context, null, severity, result, 0)
			 *     endif
			 */
			final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this, context);
			final /*@NonInvalid*/ IntegerValue severity_0 = CGStringGetSeverityOperation.INSTANCE.evaluate(executor,
					RefactoredWebPackage.Literals.PAGE___OPTIMISE_PAGE_LOAD__DIAGNOSTICCHAIN_MAP);
			final /*@NonInvalid*/ boolean le = OclComparableLessThanEqualOperation.INSTANCE
					.evaluate(executor, severity_0, RefactoredWebTables.INT_0).booleanValue();
			/*@NonInvalid*/ boolean local_0;
			if (le) {
				local_0 = true;
			} else {
				final /*@NonInvalid*/ double totalMediaSize = this.getTotalMediaSize();
				final /*@NonInvalid*/ RealValue BOXED_totalMediaSize = ValueUtil.realValueOf(totalMediaSize);
				final /*@NonInvalid*/ boolean result = OclComparableLessThanEqualOperation.INSTANCE
						.evaluate(executor, BOXED_totalMediaSize, RefactoredWebTables.INT_50).booleanValue();
				final /*@NonInvalid*/ boolean logDiagnostic = CGStringLogDiagnosticOperation.INSTANCE
						.evaluate(executor, TypeId.BOOLEAN, constraintName, this, (Object) null, diagnostics, context,
								(Object) null, severity_0, result, RefactoredWebTables.INT_0)
						.booleanValue();
				local_0 = logDiagnostic;
			}
			return local_0;
		} catch (Throwable e) {
			return ValueUtil.validationFailedDiagnostic(constraintName, this, diagnostics, context, e);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			return basicSetWebApplication((RefactoredWebApplication) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case RefactoredWebPackage.PAGE__CONTENTS:
			return ((InternalEList<?>) getContents()).basicRemove(otherEnd, msgs);
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			return basicSetWebApplication(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			return eInternalContainer().eInverseRemove(this, RefactoredWebPackage.REFACTORED_WEB_APPLICATION__PAGES,
					RefactoredWebApplication.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case RefactoredWebPackage.PAGE__TOTAL_MEDIA_SIZE:
			return getTotalMediaSize();
		case RefactoredWebPackage.PAGE__LINK:
			return getLink();
		case RefactoredWebPackage.PAGE__CONTENTS:
			return getContents();
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			return getWebApplication();
		case RefactoredWebPackage.PAGE__CREATED_AT:
			return getCreatedAt();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case RefactoredWebPackage.PAGE__TOTAL_MEDIA_SIZE:
			setTotalMediaSize((Double) newValue);
			return;
		case RefactoredWebPackage.PAGE__LINK:
			getLink().clear();
			getLink().addAll((Collection<? extends Page>) newValue);
			return;
		case RefactoredWebPackage.PAGE__CONTENTS:
			getContents().clear();
			getContents().addAll((Collection<? extends Content>) newValue);
			return;
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			setWebApplication((RefactoredWebApplication) newValue);
			return;
		case RefactoredWebPackage.PAGE__CREATED_AT:
			setCreatedAt((Instant) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case RefactoredWebPackage.PAGE__TOTAL_MEDIA_SIZE:
			setTotalMediaSize(TOTAL_MEDIA_SIZE_EDEFAULT);
			return;
		case RefactoredWebPackage.PAGE__LINK:
			getLink().clear();
			return;
		case RefactoredWebPackage.PAGE__CONTENTS:
			getContents().clear();
			return;
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			setWebApplication((RefactoredWebApplication) null);
			return;
		case RefactoredWebPackage.PAGE__CREATED_AT:
			setCreatedAt(CREATED_AT_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case RefactoredWebPackage.PAGE__TOTAL_MEDIA_SIZE:
			return getTotalMediaSize() != TOTAL_MEDIA_SIZE_EDEFAULT;
		case RefactoredWebPackage.PAGE__LINK:
			return link != null && !link.isEmpty();
		case RefactoredWebPackage.PAGE__CONTENTS:
			return contents != null && !contents.isEmpty();
		case RefactoredWebPackage.PAGE__WEB_APPLICATION:
			return getWebApplication() != null;
		case RefactoredWebPackage.PAGE__CREATED_AT:
			return CREATED_AT_EDEFAULT == null ? createdAt != null : !CREATED_AT_EDEFAULT.equals(createdAt);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	@SuppressWarnings("unchecked")
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case RefactoredWebPackage.PAGE___IS_NOT_EMPTY:
			return isNotEmpty();
		case RefactoredWebPackage.PAGE___GET_STATIC_CONTENT_QTY:
			return getStaticContentQty();
		case RefactoredWebPackage.PAGE___GET_DYNAMIC_CONTENT_QTY:
			return getDynamicContentQty();
		case RefactoredWebPackage.PAGE___OPTIMISE_PAGE_LOAD__DIAGNOSTICCHAIN_MAP:
			return OptimisePageLoad((DiagnosticChain) arguments.get(0), (Map<Object, Object>) arguments.get(1));
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (createdAt: ");
		result.append(createdAt);
		result.append(')');
		return result.toString();
	}

} //PageImpl
