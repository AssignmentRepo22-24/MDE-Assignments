/**
 */
package Web;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Individual</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Web.WebPackage#getIndividual()
 * @model
 * @generated
 */
public interface Individual extends DynamicContent {
} // Individual
