/**
 */
package Web;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Web.WebApplication#getEntities <em>Entities</em>}</li>
 *   <li>{@link Web.WebApplication#getPages <em>Pages</em>}</li>
 *   <li>{@link Web.WebApplication#getTotalPages <em>Total Pages</em>}</li>
 * </ul>
 *
 * @see Web.WebPackage#getWebApplication()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='UniqueEntityNames'"
 * @generated
 */
public interface WebApplication extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Entities</b></em>' containment reference list.
	 * The list contents are of type {@link Web.Entity}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entities</em>' containment reference list.
	 * @see Web.WebPackage#getWebApplication_Entities()
	 * @model containment="true"
	 * @generated
	 */
	EList<Entity> getEntities();

	/**
	 * Returns the value of the '<em><b>Pages</b></em>' containment reference list.
	 * The list contents are of type {@link Web.Page}.
	 * It is bidirectional and its opposite is '{@link Web.Page#getWebApplication <em>Web Application</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pages</em>' containment reference list.
	 * @see Web.WebPackage#getWebApplication_Pages()
	 * @see Web.Page#getWebApplication
	 * @model opposite="webApplication" containment="true"
	 * @generated
	 */
	EList<Page> getPages();

	/**
	 * Returns the value of the '<em><b>Total Pages</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Pages</em>' attribute.
	 * @see #setTotalPages(int)
	 * @see Web.WebPackage#getWebApplication_TotalPages()
	 * @model required="true" volatile="true" derived="true"
	 * @generated
	 */
	int getTotalPages();

	/**
	 * Sets the value of the '{@link Web.WebApplication#getTotalPages <em>Total Pages</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Pages</em>' attribute.
	 * @see #getTotalPages()
	 * @generated
	 */
	void setTotalPages(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='pages.name-&gt;asSet()-&gt;size() = pages-&gt;size()'"
	 * @generated
	 */
	boolean UniquePageNames(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='pages-&gt;size() &gt;= 1'"
	 * @generated
	 */
	boolean AtLeastOnePage(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='entities-&gt;size() &gt;= 1'"
	 * @generated
	 */
	boolean AtLeastOneEntity(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='entities.name-&gt;asSet()-&gt;size() = entities-&gt;size()'"
	 * @generated
	 */
	boolean UniqueEntityNames(DiagnosticChain diagnostics, Map<Object, Object> context);

} // WebApplication
