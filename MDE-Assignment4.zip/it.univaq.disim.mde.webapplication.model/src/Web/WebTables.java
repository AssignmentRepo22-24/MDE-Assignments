/*******************************************************************************
 *************************************************************************
 * This code is 100% auto-generated
 * from:
 *   /it.univaq.disim.mde.webapplication.model/WebApplication.ecore
 * using:
 *   /it.univaq.disim.mde.webapplication.model/WebApplication.genmodel
 *   org.eclipse.ocl.examples.codegen.oclinecore.OCLinEcoreTables
 *
 * Do not edit it.
 *******************************************************************************/
package Web;

// import Web.WebPackage;
// import Web.WebTables;
import java.lang.String;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.ocl.pivot.ParameterTypes;
import org.eclipse.ocl.pivot.TemplateParameters;
import org.eclipse.ocl.pivot.ids.ClassId;
import org.eclipse.ocl.pivot.ids.CollectionTypeId;
import org.eclipse.ocl.pivot.ids.DataTypeId;
import org.eclipse.ocl.pivot.ids.EnumerationId;
import org.eclipse.ocl.pivot.ids.IdManager;
import org.eclipse.ocl.pivot.ids.NsURIPackageId;
import org.eclipse.ocl.pivot.ids.RootPackageId;
import org.eclipse.ocl.pivot.ids.TypeId;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumeration;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorEnumerationLiteral;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorPackage;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreExecutorType;
import org.eclipse.ocl.pivot.internal.library.ecore.EcoreLibraryOppositeProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorFragment;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorOperation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorProperty;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorPropertyWithImplementation;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorStandardLibrary;
import org.eclipse.ocl.pivot.internal.library.executor.ExecutorType;
import org.eclipse.ocl.pivot.oclstdlib.OCLstdlibTables;
import org.eclipse.ocl.pivot.utilities.AbstractTables;
import org.eclipse.ocl.pivot.utilities.TypeUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.IntegerValue;

/**
 * WebTables provides the dispatch tables for the Web for use by the OCL dispatcher.
 *
 * In order to ensure correct static initialization, a top level class element must be accessed
 * before any nested class element. Therefore an access to PACKAGE.getClass() is recommended.
 */
public class WebTables extends AbstractTables
{
	static {
		Init.initStart();
	}

	/**
	 *	The package descriptor for the package.
	 */
	public static final EcoreExecutorPackage PACKAGE = new EcoreExecutorPackage(WebPackage.eINSTANCE);

	/**
	 *	The library of all packages and types.
	 */
	public static final ExecutorStandardLibrary LIBRARY = OCLstdlibTables.LIBRARY;

	/**
	 *	Constants used by auto-generated code.
	 */
	public static final /*@NonInvalid*/ RootPackageId PACKid_$metamodel$ = IdManager.getRootPackageId("$metamodel$");
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore = IdManager.getNsURIPackageId("http://www.eclipse.org/emf/2002/Ecore", null, EcorePackage.eINSTANCE);
	public static final /*@NonInvalid*/ NsURIPackageId PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication = IdManager.getNsURIPackageId("https://it.univaq.disim.mde/webapplication", null, WebPackage.eINSTANCE);
	public static final /*@NonInvalid*/ ClassId CLSSid_Attribute = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Attribute", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Class = WebTables.PACKid_$metamodel$.getClassId("Class", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Content = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Content", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_DynamicContent = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("DynamicContent", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Element = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Element", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Entity = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Entity", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Feature = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Feature", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Form = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Form", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Media = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Media", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Page = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Page", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_Reference = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("Reference", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_StaticContent = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("StaticContent", 0);
	public static final /*@NonInvalid*/ ClassId CLSSid_WebApplication = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getClassId("WebApplication", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EDouble = WebTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EDouble", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_EInt = WebTables.PACKid_http_c_s_s_www_eclipse_org_s_emf_s_2002_s_Ecore.getDataTypeId("EInt", 0);
	public static final /*@NonInvalid*/ DataTypeId DATAid_Instant = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getDataTypeId("Instant", 0);
	public static final /*@NonInvalid*/ EnumerationId ENUMid_DataType = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getEnumerationId("DataType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_ElementType = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getEnumerationId("ElementType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_MediaType = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getEnumerationId("MediaType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_MethodType = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getEnumerationId("MethodType");
	public static final /*@NonInvalid*/ EnumerationId ENUMid_PartOfPage = WebTables.PACKid_https_c_s_s_it_univaq_disim_mde_s_webapplication.getEnumerationId("PartOfPage");
	public static final /*@NonInvalid*/ IntegerValue INT_0 = ValueUtil.integerValueOf("0");
	public static final /*@NonInvalid*/ IntegerValue INT_1 = ValueUtil.integerValueOf("1");
	public static final /*@NonInvalid*/ IntegerValue INT_20 = ValueUtil.integerValueOf("20");
	public static final /*@NonInvalid*/ IntegerValue INT_50 = ValueUtil.integerValueOf("50");
	public static final /*@NonInvalid*/ CollectionTypeId SEQ_PRIMid_Real = TypeId.SEQUENCE.getSpecializedId(TypeId.REAL);
	public static final /*@NonInvalid*/ CollectionTypeId SEQ_PRIMid_String = TypeId.SEQUENCE.getSpecializedId(TypeId.STRING);
	public static final /*@NonInvalid*/ CollectionTypeId SET_PRIMid_String = TypeId.SET.getSpecializedId(TypeId.STRING);
	public static final /*@NonInvalid*/ String STR_Large_32_size_32_media = "Large size media";
	public static final /*@NonInvalid*/ String STR_Small_32_size_32_media = "Small size media";
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_DynamicContent = TypeId.BAG.getSpecializedId(WebTables.CLSSid_DynamicContent);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Element = TypeId.BAG.getSpecializedId(WebTables.CLSSid_Element);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Form = TypeId.BAG.getSpecializedId(WebTables.CLSSid_Form);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Page = TypeId.BAG.getSpecializedId(WebTables.CLSSid_Page);
	public static final /*@NonInvalid*/ CollectionTypeId BAG_CLSSid_Reference = TypeId.BAG.getSpecializedId(WebTables.CLSSid_Reference);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Attribute = TypeId.ORDERED_SET.getSpecializedId(WebTables.CLSSid_Attribute);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Content = TypeId.ORDERED_SET.getSpecializedId(WebTables.CLSSid_Content);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Element = TypeId.ORDERED_SET.getSpecializedId(WebTables.CLSSid_Element);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Entity = TypeId.ORDERED_SET.getSpecializedId(WebTables.CLSSid_Entity);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Feature = TypeId.ORDERED_SET.getSpecializedId(WebTables.CLSSid_Feature);
	public static final /*@NonInvalid*/ CollectionTypeId ORD_CLSSid_Page = TypeId.ORDERED_SET.getSpecializedId(WebTables.CLSSid_Page);

	/**
	 *	The type parameters for templated types and operations.
	 */
	public static class TypeParameters {
		static {
			Init.initStart();
			WebTables.init();
		}

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::TypeParameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The type descriptors for each type.
	 */
	public static class Types {
		static {
			Init.initStart();
			TypeParameters.init();
		}

		public static final EcoreExecutorType _Attribute = new EcoreExecutorType(WebPackage.Literals.ATTRIBUTE, PACKAGE, 0);
		public static final EcoreExecutorType _Content = new EcoreExecutorType(WebPackage.Literals.CONTENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorEnumeration _DataType = new EcoreExecutorEnumeration(WebPackage.Literals.DATA_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _DynamicContent = new EcoreExecutorType(WebPackage.Literals.DYNAMIC_CONTENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Element = new EcoreExecutorType(WebPackage.Literals.ELEMENT, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _ElementType = new EcoreExecutorEnumeration(WebPackage.Literals.ELEMENT_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _Entity = new EcoreExecutorType(WebPackage.Literals.ENTITY, PACKAGE, 0);
		public static final EcoreExecutorType _Feature = new EcoreExecutorType(WebPackage.Literals.FEATURE, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Form = new EcoreExecutorType(WebPackage.Literals.FORM, PACKAGE, 0);
		public static final EcoreExecutorType _Index = new EcoreExecutorType(WebPackage.Literals.INDEX, PACKAGE, 0);
		public static final EcoreExecutorType _Individual = new EcoreExecutorType(WebPackage.Literals.INDIVIDUAL, PACKAGE, 0);
		public static final EcoreExecutorType _Instant = new EcoreExecutorType("Instant", PACKAGE, 0);
		public static final EcoreExecutorType _Media = new EcoreExecutorType(WebPackage.Literals.MEDIA, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _MediaType = new EcoreExecutorEnumeration(WebPackage.Literals.MEDIA_TYPE, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _MethodType = new EcoreExecutorEnumeration(WebPackage.Literals.METHOD_TYPE, PACKAGE, 0);
		public static final EcoreExecutorType _NamedElement = new EcoreExecutorType(WebPackage.Literals.NAMED_ELEMENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _Page = new EcoreExecutorType(WebPackage.Literals.PAGE, PACKAGE, 0);
		public static final EcoreExecutorEnumeration _PartOfPage = new EcoreExecutorEnumeration(WebPackage.Literals.PART_OF_PAGE, PACKAGE, 0);
		public static final EcoreExecutorType _Reference = new EcoreExecutorType(WebPackage.Literals.REFERENCE, PACKAGE, 0);
		public static final EcoreExecutorType _StaticContent = new EcoreExecutorType(WebPackage.Literals.STATIC_CONTENT, PACKAGE, 0 | ExecutorType.ABSTRACT);
		public static final EcoreExecutorType _WebApplication = new EcoreExecutorType(WebPackage.Literals.WEB_APPLICATION, PACKAGE, 0);

		private static final EcoreExecutorType /*@NonNull*/ [] types = {
			_Attribute,
			_Content,
			_DataType,
			_DynamicContent,
			_Element,
			_ElementType,
			_Entity,
			_Feature,
			_Form,
			_Index,
			_Individual,
			_Instant,
			_Media,
			_MediaType,
			_MethodType,
			_NamedElement,
			_Page,
			_PartOfPage,
			_Reference,
			_StaticContent,
			_WebApplication
		};

		/*
		 *	Install the type descriptors in the package descriptor.
		 */
		static {
			PACKAGE.init(LIBRARY, types);
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::Types and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragment descriptors for the local elements of each type and its supertypes.
	 */
	public static class Fragments {
		static {
			Init.initStart();
			Types.init();
		}

		private static final ExecutorFragment _Attribute__Attribute = new ExecutorFragment(Types._Attribute, WebTables.Types._Attribute);
		private static final ExecutorFragment _Attribute__Feature = new ExecutorFragment(Types._Attribute, WebTables.Types._Feature);
		private static final ExecutorFragment _Attribute__NamedElement = new ExecutorFragment(Types._Attribute, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Attribute__OclAny = new ExecutorFragment(Types._Attribute, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Attribute__OclElement = new ExecutorFragment(Types._Attribute, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Content__Content = new ExecutorFragment(Types._Content, WebTables.Types._Content);
		private static final ExecutorFragment _Content__NamedElement = new ExecutorFragment(Types._Content, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Content__OclAny = new ExecutorFragment(Types._Content, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Content__OclElement = new ExecutorFragment(Types._Content, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _DataType__DataType = new ExecutorFragment(Types._DataType, WebTables.Types._DataType);
		private static final ExecutorFragment _DataType__OclAny = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _DataType__OclElement = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _DataType__OclEnumeration = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _DataType__OclType = new ExecutorFragment(Types._DataType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _DynamicContent__Content = new ExecutorFragment(Types._DynamicContent, WebTables.Types._Content);
		private static final ExecutorFragment _DynamicContent__DynamicContent = new ExecutorFragment(Types._DynamicContent, WebTables.Types._DynamicContent);
		private static final ExecutorFragment _DynamicContent__NamedElement = new ExecutorFragment(Types._DynamicContent, WebTables.Types._NamedElement);
		private static final ExecutorFragment _DynamicContent__OclAny = new ExecutorFragment(Types._DynamicContent, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _DynamicContent__OclElement = new ExecutorFragment(Types._DynamicContent, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Element__Element = new ExecutorFragment(Types._Element, WebTables.Types._Element);
		private static final ExecutorFragment _Element__NamedElement = new ExecutorFragment(Types._Element, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Element__OclAny = new ExecutorFragment(Types._Element, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Element__OclElement = new ExecutorFragment(Types._Element, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _ElementType__ElementType = new ExecutorFragment(Types._ElementType, WebTables.Types._ElementType);
		private static final ExecutorFragment _ElementType__OclAny = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _ElementType__OclElement = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _ElementType__OclEnumeration = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _ElementType__OclType = new ExecutorFragment(Types._ElementType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _Entity__Entity = new ExecutorFragment(Types._Entity, WebTables.Types._Entity);
		private static final ExecutorFragment _Entity__NamedElement = new ExecutorFragment(Types._Entity, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Entity__OclAny = new ExecutorFragment(Types._Entity, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Entity__OclElement = new ExecutorFragment(Types._Entity, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Feature__Feature = new ExecutorFragment(Types._Feature, WebTables.Types._Feature);
		private static final ExecutorFragment _Feature__NamedElement = new ExecutorFragment(Types._Feature, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Feature__OclAny = new ExecutorFragment(Types._Feature, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Feature__OclElement = new ExecutorFragment(Types._Feature, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Form__Content = new ExecutorFragment(Types._Form, WebTables.Types._Content);
		private static final ExecutorFragment _Form__Form = new ExecutorFragment(Types._Form, WebTables.Types._Form);
		private static final ExecutorFragment _Form__NamedElement = new ExecutorFragment(Types._Form, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Form__OclAny = new ExecutorFragment(Types._Form, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Form__OclElement = new ExecutorFragment(Types._Form, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Form__StaticContent = new ExecutorFragment(Types._Form, WebTables.Types._StaticContent);

		private static final ExecutorFragment _Index__Content = new ExecutorFragment(Types._Index, WebTables.Types._Content);
		private static final ExecutorFragment _Index__DynamicContent = new ExecutorFragment(Types._Index, WebTables.Types._DynamicContent);
		private static final ExecutorFragment _Index__Index = new ExecutorFragment(Types._Index, WebTables.Types._Index);
		private static final ExecutorFragment _Index__NamedElement = new ExecutorFragment(Types._Index, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Index__OclAny = new ExecutorFragment(Types._Index, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Index__OclElement = new ExecutorFragment(Types._Index, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Individual__Content = new ExecutorFragment(Types._Individual, WebTables.Types._Content);
		private static final ExecutorFragment _Individual__DynamicContent = new ExecutorFragment(Types._Individual, WebTables.Types._DynamicContent);
		private static final ExecutorFragment _Individual__Individual = new ExecutorFragment(Types._Individual, WebTables.Types._Individual);
		private static final ExecutorFragment _Individual__NamedElement = new ExecutorFragment(Types._Individual, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Individual__OclAny = new ExecutorFragment(Types._Individual, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Individual__OclElement = new ExecutorFragment(Types._Individual, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Instant__Instant = new ExecutorFragment(Types._Instant, WebTables.Types._Instant);
		private static final ExecutorFragment _Instant__OclAny = new ExecutorFragment(Types._Instant, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Instant__OclComparable = new ExecutorFragment(Types._Instant, OCLstdlibTables.Types._OclComparable);

		private static final ExecutorFragment _Media__Content = new ExecutorFragment(Types._Media, WebTables.Types._Content);
		private static final ExecutorFragment _Media__Media = new ExecutorFragment(Types._Media, WebTables.Types._Media);
		private static final ExecutorFragment _Media__NamedElement = new ExecutorFragment(Types._Media, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Media__OclAny = new ExecutorFragment(Types._Media, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Media__OclElement = new ExecutorFragment(Types._Media, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Media__StaticContent = new ExecutorFragment(Types._Media, WebTables.Types._StaticContent);

		private static final ExecutorFragment _MediaType__MediaType = new ExecutorFragment(Types._MediaType, WebTables.Types._MediaType);
		private static final ExecutorFragment _MediaType__OclAny = new ExecutorFragment(Types._MediaType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _MediaType__OclElement = new ExecutorFragment(Types._MediaType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _MediaType__OclEnumeration = new ExecutorFragment(Types._MediaType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _MediaType__OclType = new ExecutorFragment(Types._MediaType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _MethodType__MethodType = new ExecutorFragment(Types._MethodType, WebTables.Types._MethodType);
		private static final ExecutorFragment _MethodType__OclAny = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _MethodType__OclElement = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _MethodType__OclEnumeration = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _MethodType__OclType = new ExecutorFragment(Types._MethodType, OCLstdlibTables.Types._OclType);

		private static final ExecutorFragment _NamedElement__NamedElement = new ExecutorFragment(Types._NamedElement, WebTables.Types._NamedElement);
		private static final ExecutorFragment _NamedElement__OclAny = new ExecutorFragment(Types._NamedElement, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _NamedElement__OclElement = new ExecutorFragment(Types._NamedElement, OCLstdlibTables.Types._OclElement);

		private static final ExecutorFragment _Page__NamedElement = new ExecutorFragment(Types._Page, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Page__OclAny = new ExecutorFragment(Types._Page, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Page__OclElement = new ExecutorFragment(Types._Page, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Page__Page = new ExecutorFragment(Types._Page, WebTables.Types._Page);

		private static final ExecutorFragment _PartOfPage__OclAny = new ExecutorFragment(Types._PartOfPage, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _PartOfPage__OclElement = new ExecutorFragment(Types._PartOfPage, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _PartOfPage__OclEnumeration = new ExecutorFragment(Types._PartOfPage, OCLstdlibTables.Types._OclEnumeration);
		private static final ExecutorFragment _PartOfPage__OclType = new ExecutorFragment(Types._PartOfPage, OCLstdlibTables.Types._OclType);
		private static final ExecutorFragment _PartOfPage__PartOfPage = new ExecutorFragment(Types._PartOfPage, WebTables.Types._PartOfPage);

		private static final ExecutorFragment _Reference__Feature = new ExecutorFragment(Types._Reference, WebTables.Types._Feature);
		private static final ExecutorFragment _Reference__NamedElement = new ExecutorFragment(Types._Reference, WebTables.Types._NamedElement);
		private static final ExecutorFragment _Reference__OclAny = new ExecutorFragment(Types._Reference, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _Reference__OclElement = new ExecutorFragment(Types._Reference, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _Reference__Reference = new ExecutorFragment(Types._Reference, WebTables.Types._Reference);

		private static final ExecutorFragment _StaticContent__Content = new ExecutorFragment(Types._StaticContent, WebTables.Types._Content);
		private static final ExecutorFragment _StaticContent__NamedElement = new ExecutorFragment(Types._StaticContent, WebTables.Types._NamedElement);
		private static final ExecutorFragment _StaticContent__OclAny = new ExecutorFragment(Types._StaticContent, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _StaticContent__OclElement = new ExecutorFragment(Types._StaticContent, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _StaticContent__StaticContent = new ExecutorFragment(Types._StaticContent, WebTables.Types._StaticContent);

		private static final ExecutorFragment _WebApplication__NamedElement = new ExecutorFragment(Types._WebApplication, WebTables.Types._NamedElement);
		private static final ExecutorFragment _WebApplication__OclAny = new ExecutorFragment(Types._WebApplication, OCLstdlibTables.Types._OclAny);
		private static final ExecutorFragment _WebApplication__OclElement = new ExecutorFragment(Types._WebApplication, OCLstdlibTables.Types._OclElement);
		private static final ExecutorFragment _WebApplication__WebApplication = new ExecutorFragment(Types._WebApplication, WebTables.Types._WebApplication);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::Fragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The parameter lists shared by operations.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Parameters {
		static {
			Init.initStart();
			Fragments.init();
		}

		public static final ParameterTypes _OclSelf = TypeUtil.createParameterTypes(OCLstdlibTables.Types._OclSelf);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::Parameters and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The operation descriptors for each operation of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Operations {
		static {
			Init.initStart();
			Parameters.init();
		}

		public static final ExecutorOperation _Entity__primaryKeyName = new ExecutorOperation("primaryKeyName", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Entity,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Form__getElementQty = new ExecutorOperation("getElementQty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Form,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Instant__compareTo = new ExecutorOperation("compareTo", Parameters._OclSelf, Types._Instant,
			0, TemplateParameters.EMPTY_LIST, null);

		public static final ExecutorOperation _Page__getDynamicContentQty = new ExecutorOperation("getDynamicContentQty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Page,
			0, TemplateParameters.EMPTY_LIST, null);
		public static final ExecutorOperation _Page__getStaticContentQty = new ExecutorOperation("getStaticContentQty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Page,
			1, TemplateParameters.EMPTY_LIST, null);
		public static final ExecutorOperation _Page__isNotEmpty = new ExecutorOperation("isNotEmpty", TypeUtil.EMPTY_PARAMETER_TYPES, Types._Page,
			2, TemplateParameters.EMPTY_LIST, null);

		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::Operations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The property descriptors for each property of each type.
	 *
	 * @noextend This class is not intended to be subclassed by clients.
	 * @noinstantiate This class is not intended to be instantiated by clients.
	 * @noreference This class is not intended to be referenced by clients.
	 */
	public static class Properties {
		static {
			Init.initStart();
			Operations.init();
		}

		public static final ExecutorProperty _Attribute__isPK = new EcoreExecutorProperty(WebPackage.Literals.ATTRIBUTE__IS_PK, Types._Attribute, 0);
		public static final ExecutorProperty _Attribute__type = new EcoreExecutorProperty(WebPackage.Literals.ATTRIBUTE__TYPE, Types._Attribute, 1);
		public static final ExecutorProperty _Attribute__DynamicContent__attributes = new ExecutorPropertyWithImplementation("DynamicContent", Types._Attribute, 2, new EcoreLibraryOppositeProperty(WebPackage.Literals.DYNAMIC_CONTENT__ATTRIBUTES));
		public static final ExecutorProperty _Attribute__Element__attribute = new ExecutorPropertyWithImplementation("Element", Types._Attribute, 3, new EcoreLibraryOppositeProperty(WebPackage.Literals.ELEMENT__ATTRIBUTE));

		public static final ExecutorProperty _Content__partOfPage = new EcoreExecutorProperty(WebPackage.Literals.CONTENT__PART_OF_PAGE, Types._Content, 0);
		public static final ExecutorProperty _Content__Page__contents = new ExecutorPropertyWithImplementation("Page", Types._Content, 1, new EcoreLibraryOppositeProperty(WebPackage.Literals.PAGE__CONTENTS));

		public static final ExecutorProperty _DynamicContent__attributes = new EcoreExecutorProperty(WebPackage.Literals.DYNAMIC_CONTENT__ATTRIBUTES, Types._DynamicContent, 0);
		public static final ExecutorProperty _DynamicContent__entities = new EcoreExecutorProperty(WebPackage.Literals.DYNAMIC_CONTENT__ENTITIES, Types._DynamicContent, 1);

		public static final ExecutorProperty _Element__attribute = new EcoreExecutorProperty(WebPackage.Literals.ELEMENT__ATTRIBUTE, Types._Element, 0);
		public static final ExecutorProperty _Element__form = new EcoreExecutorProperty(WebPackage.Literals.ELEMENT__FORM, Types._Element, 1);
		public static final ExecutorProperty _Element__label = new EcoreExecutorProperty(WebPackage.Literals.ELEMENT__LABEL, Types._Element, 2);
		public static final ExecutorProperty _Element__tooltip = new EcoreExecutorProperty(WebPackage.Literals.ELEMENT__TOOLTIP, Types._Element, 3);
		public static final ExecutorProperty _Element__type = new EcoreExecutorProperty(WebPackage.Literals.ELEMENT__TYPE, Types._Element, 4);

		public static final ExecutorProperty _Entity__features = new EcoreExecutorProperty(WebPackage.Literals.ENTITY__FEATURES, Types._Entity, 0);
		public static final ExecutorProperty _Entity__DynamicContent__entities = new ExecutorPropertyWithImplementation("DynamicContent", Types._Entity, 1, new EcoreLibraryOppositeProperty(WebPackage.Literals.DYNAMIC_CONTENT__ENTITIES));
		public static final ExecutorProperty _Entity__Form__entity = new ExecutorPropertyWithImplementation("Form", Types._Entity, 2, new EcoreLibraryOppositeProperty(WebPackage.Literals.FORM__ENTITY));
		public static final ExecutorProperty _Entity__Reference__foreignKey = new ExecutorPropertyWithImplementation("Reference", Types._Entity, 3, new EcoreLibraryOppositeProperty(WebPackage.Literals.REFERENCE__FOREIGN_KEY));
		public static final ExecutorProperty _Entity__WebApplication__entities = new ExecutorPropertyWithImplementation("WebApplication", Types._Entity, 4, new EcoreLibraryOppositeProperty(WebPackage.Literals.WEB_APPLICATION__ENTITIES));

		public static final ExecutorProperty _Feature__Entity__features = new ExecutorPropertyWithImplementation("Entity", Types._Feature, 0, new EcoreLibraryOppositeProperty(WebPackage.Literals.ENTITY__FEATURES));

		public static final ExecutorProperty _Form__elements = new EcoreExecutorProperty(WebPackage.Literals.FORM__ELEMENTS, Types._Form, 0);
		public static final ExecutorProperty _Form__entity = new EcoreExecutorProperty(WebPackage.Literals.FORM__ENTITY, Types._Form, 1);
		public static final ExecutorProperty _Form__method = new EcoreExecutorProperty(WebPackage.Literals.FORM__METHOD, Types._Form, 2);

		public static final ExecutorProperty _Media__altText = new EcoreExecutorProperty(WebPackage.Literals.MEDIA__ALT_TEXT, Types._Media, 0);
		public static final ExecutorProperty _Media__mediaClassification = new EcoreExecutorProperty(WebPackage.Literals.MEDIA__MEDIA_CLASSIFICATION, Types._Media, 1);
		public static final ExecutorProperty _Media__size = new EcoreExecutorProperty(WebPackage.Literals.MEDIA__SIZE, Types._Media, 2);
		public static final ExecutorProperty _Media__source = new EcoreExecutorProperty(WebPackage.Literals.MEDIA__SOURCE, Types._Media, 3);
		public static final ExecutorProperty _Media__type = new EcoreExecutorProperty(WebPackage.Literals.MEDIA__TYPE, Types._Media, 4);

		public static final ExecutorProperty _NamedElement__name = new EcoreExecutorProperty(WebPackage.Literals.NAMED_ELEMENT__NAME, Types._NamedElement, 0);

		public static final ExecutorProperty _Page__contents = new EcoreExecutorProperty(WebPackage.Literals.PAGE__CONTENTS, Types._Page, 0);
		public static final ExecutorProperty _Page__createdAt = new EcoreExecutorProperty(WebPackage.Literals.PAGE__CREATED_AT, Types._Page, 1);
		public static final ExecutorProperty _Page__link = new EcoreExecutorProperty(WebPackage.Literals.PAGE__LINK, Types._Page, 2);
		public static final ExecutorProperty _Page__totalMediaSize = new EcoreExecutorProperty(WebPackage.Literals.PAGE__TOTAL_MEDIA_SIZE, Types._Page, 3);
		public static final ExecutorProperty _Page__webApplication = new EcoreExecutorProperty(WebPackage.Literals.PAGE__WEB_APPLICATION, Types._Page, 4);
		public static final ExecutorProperty _Page__Page__link = new ExecutorPropertyWithImplementation("Page", Types._Page, 5, new EcoreLibraryOppositeProperty(WebPackage.Literals.PAGE__LINK));

		public static final ExecutorProperty _Reference__foreignKey = new EcoreExecutorProperty(WebPackage.Literals.REFERENCE__FOREIGN_KEY, Types._Reference, 0);

		public static final ExecutorProperty _WebApplication__entities = new EcoreExecutorProperty(WebPackage.Literals.WEB_APPLICATION__ENTITIES, Types._WebApplication, 0);
		public static final ExecutorProperty _WebApplication__pages = new EcoreExecutorProperty(WebPackage.Literals.WEB_APPLICATION__PAGES, Types._WebApplication, 1);
		public static final ExecutorProperty _WebApplication__totalPages = new EcoreExecutorProperty(WebPackage.Literals.WEB_APPLICATION__TOTAL_PAGES, Types._WebApplication, 2);
		static {
			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::Properties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The fragments for all base types in depth order: OclAny first, OclSelf last.
	 */
	public static class TypeFragments {
		static {
			Init.initStart();
			Properties.init();
		}

		private static final ExecutorFragment /*@NonNull*/ [] _Attribute =
			{
				Fragments._Attribute__OclAny /* 0 */,
				Fragments._Attribute__OclElement /* 1 */,
				Fragments._Attribute__NamedElement /* 2 */,
				Fragments._Attribute__Feature /* 3 */,
				Fragments._Attribute__Attribute /* 4 */
			};
		private static final int /*@NonNull*/ [] __Attribute = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Content =
			{
				Fragments._Content__OclAny /* 0 */,
				Fragments._Content__OclElement /* 1 */,
				Fragments._Content__NamedElement /* 2 */,
				Fragments._Content__Content /* 3 */
			};
		private static final int /*@NonNull*/ [] __Content = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _DataType =
			{
				Fragments._DataType__OclAny /* 0 */,
				Fragments._DataType__OclElement /* 1 */,
				Fragments._DataType__OclType /* 2 */,
				Fragments._DataType__OclEnumeration /* 3 */,
				Fragments._DataType__DataType /* 4 */
			};
		private static final int /*@NonNull*/ [] __DataType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _DynamicContent =
			{
				Fragments._DynamicContent__OclAny /* 0 */,
				Fragments._DynamicContent__OclElement /* 1 */,
				Fragments._DynamicContent__NamedElement /* 2 */,
				Fragments._DynamicContent__Content /* 3 */,
				Fragments._DynamicContent__DynamicContent /* 4 */
			};
		private static final int /*@NonNull*/ [] __DynamicContent = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Element =
			{
				Fragments._Element__OclAny /* 0 */,
				Fragments._Element__OclElement /* 1 */,
				Fragments._Element__NamedElement /* 2 */,
				Fragments._Element__Element /* 3 */
			};
		private static final int /*@NonNull*/ [] __Element = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _ElementType =
			{
				Fragments._ElementType__OclAny /* 0 */,
				Fragments._ElementType__OclElement /* 1 */,
				Fragments._ElementType__OclType /* 2 */,
				Fragments._ElementType__OclEnumeration /* 3 */,
				Fragments._ElementType__ElementType /* 4 */
			};
		private static final int /*@NonNull*/ [] __ElementType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Entity =
			{
				Fragments._Entity__OclAny /* 0 */,
				Fragments._Entity__OclElement /* 1 */,
				Fragments._Entity__NamedElement /* 2 */,
				Fragments._Entity__Entity /* 3 */
			};
		private static final int /*@NonNull*/ [] __Entity = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Feature =
			{
				Fragments._Feature__OclAny /* 0 */,
				Fragments._Feature__OclElement /* 1 */,
				Fragments._Feature__NamedElement /* 2 */,
				Fragments._Feature__Feature /* 3 */
			};
		private static final int /*@NonNull*/ [] __Feature = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Form =
			{
				Fragments._Form__OclAny /* 0 */,
				Fragments._Form__OclElement /* 1 */,
				Fragments._Form__NamedElement /* 2 */,
				Fragments._Form__Content /* 3 */,
				Fragments._Form__StaticContent /* 4 */,
				Fragments._Form__Form /* 5 */
			};
		private static final int /*@NonNull*/ [] __Form = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Index =
			{
				Fragments._Index__OclAny /* 0 */,
				Fragments._Index__OclElement /* 1 */,
				Fragments._Index__NamedElement /* 2 */,
				Fragments._Index__Content /* 3 */,
				Fragments._Index__DynamicContent /* 4 */,
				Fragments._Index__Index /* 5 */
			};
		private static final int /*@NonNull*/ [] __Index = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Individual =
			{
				Fragments._Individual__OclAny /* 0 */,
				Fragments._Individual__OclElement /* 1 */,
				Fragments._Individual__NamedElement /* 2 */,
				Fragments._Individual__Content /* 3 */,
				Fragments._Individual__DynamicContent /* 4 */,
				Fragments._Individual__Individual /* 5 */
			};
		private static final int /*@NonNull*/ [] __Individual = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Instant =
			{
				Fragments._Instant__OclAny /* 0 */,
				Fragments._Instant__OclComparable /* 1 */,
				Fragments._Instant__Instant /* 2 */
			};
		private static final int /*@NonNull*/ [] __Instant = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Media =
			{
				Fragments._Media__OclAny /* 0 */,
				Fragments._Media__OclElement /* 1 */,
				Fragments._Media__NamedElement /* 2 */,
				Fragments._Media__Content /* 3 */,
				Fragments._Media__StaticContent /* 4 */,
				Fragments._Media__Media /* 5 */
			};
		private static final int /*@NonNull*/ [] __Media = { 1,1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _MediaType =
			{
				Fragments._MediaType__OclAny /* 0 */,
				Fragments._MediaType__OclElement /* 1 */,
				Fragments._MediaType__OclType /* 2 */,
				Fragments._MediaType__OclEnumeration /* 3 */,
				Fragments._MediaType__MediaType /* 4 */
			};
		private static final int /*@NonNull*/ [] __MediaType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _MethodType =
			{
				Fragments._MethodType__OclAny /* 0 */,
				Fragments._MethodType__OclElement /* 1 */,
				Fragments._MethodType__OclType /* 2 */,
				Fragments._MethodType__OclEnumeration /* 3 */,
				Fragments._MethodType__MethodType /* 4 */
			};
		private static final int /*@NonNull*/ [] __MethodType = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _NamedElement =
			{
				Fragments._NamedElement__OclAny /* 0 */,
				Fragments._NamedElement__OclElement /* 1 */,
				Fragments._NamedElement__NamedElement /* 2 */
			};
		private static final int /*@NonNull*/ [] __NamedElement = { 1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Page =
			{
				Fragments._Page__OclAny /* 0 */,
				Fragments._Page__OclElement /* 1 */,
				Fragments._Page__NamedElement /* 2 */,
				Fragments._Page__Page /* 3 */
			};
		private static final int /*@NonNull*/ [] __Page = { 1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _PartOfPage =
			{
				Fragments._PartOfPage__OclAny /* 0 */,
				Fragments._PartOfPage__OclElement /* 1 */,
				Fragments._PartOfPage__OclType /* 2 */,
				Fragments._PartOfPage__OclEnumeration /* 3 */,
				Fragments._PartOfPage__PartOfPage /* 4 */
			};
		private static final int /*@NonNull*/ [] __PartOfPage = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _Reference =
			{
				Fragments._Reference__OclAny /* 0 */,
				Fragments._Reference__OclElement /* 1 */,
				Fragments._Reference__NamedElement /* 2 */,
				Fragments._Reference__Feature /* 3 */,
				Fragments._Reference__Reference /* 4 */
			};
		private static final int /*@NonNull*/ [] __Reference = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _StaticContent =
			{
				Fragments._StaticContent__OclAny /* 0 */,
				Fragments._StaticContent__OclElement /* 1 */,
				Fragments._StaticContent__NamedElement /* 2 */,
				Fragments._StaticContent__Content /* 3 */,
				Fragments._StaticContent__StaticContent /* 4 */
			};
		private static final int /*@NonNull*/ [] __StaticContent = { 1,1,1,1,1 };

		private static final ExecutorFragment /*@NonNull*/ [] _WebApplication =
			{
				Fragments._WebApplication__OclAny /* 0 */,
				Fragments._WebApplication__OclElement /* 1 */,
				Fragments._WebApplication__NamedElement /* 2 */,
				Fragments._WebApplication__WebApplication /* 3 */
			};
		private static final int /*@NonNull*/ [] __WebApplication = { 1,1,1,1 };

		/**
		 *	Install the fragment descriptors in the class descriptors.
		 */
		static {
			Types._Attribute.initFragments(_Attribute, __Attribute);
			Types._Content.initFragments(_Content, __Content);
			Types._DataType.initFragments(_DataType, __DataType);
			Types._DynamicContent.initFragments(_DynamicContent, __DynamicContent);
			Types._Element.initFragments(_Element, __Element);
			Types._ElementType.initFragments(_ElementType, __ElementType);
			Types._Entity.initFragments(_Entity, __Entity);
			Types._Feature.initFragments(_Feature, __Feature);
			Types._Form.initFragments(_Form, __Form);
			Types._Index.initFragments(_Index, __Index);
			Types._Individual.initFragments(_Individual, __Individual);
			Types._Instant.initFragments(_Instant, __Instant);
			Types._Media.initFragments(_Media, __Media);
			Types._MediaType.initFragments(_MediaType, __MediaType);
			Types._MethodType.initFragments(_MethodType, __MethodType);
			Types._NamedElement.initFragments(_NamedElement, __NamedElement);
			Types._Page.initFragments(_Page, __Page);
			Types._PartOfPage.initFragments(_PartOfPage, __PartOfPage);
			Types._Reference.initFragments(_Reference, __Reference);
			Types._StaticContent.initFragments(_StaticContent, __StaticContent);
			Types._WebApplication.initFragments(_WebApplication, __WebApplication);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::TypeFragments and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local operations or local operation overrides for each fragment of each type.
	 */
	public static class FragmentOperations {
		static {
			Init.initStart();
			TypeFragments.init();
		}

		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__Attribute = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__Feature = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Attribute__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Content__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Content__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Content__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Content__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _DataType__DataType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DataType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _DynamicContent__DynamicContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DynamicContent__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DynamicContent__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _DynamicContent__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _DynamicContent__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Element__Element = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Element__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Element__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Element__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__ElementType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _ElementType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Entity__Entity = {
			WebTables.Operations._Entity__primaryKeyName /* primaryKeyName() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Entity__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Entity__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Entity__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Feature__Feature = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Feature__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Feature__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Feature__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Form__Form = {
			WebTables.Operations._Form__getElementQty /* getElementQty() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Form__StaticContent = {};

		private static final ExecutorOperation /*@NonNull*/ [] _Index__Index = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Index__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Index__DynamicContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Index__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Index__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Index__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Individual__Individual = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Individual__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Individual__DynamicContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Individual__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Individual__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Individual__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Instant__Instant = {
			WebTables.Operations._Instant__compareTo /* compareTo(OclSelf[1]) */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Instant__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Instant__OclComparable = {
			OCLstdlibTables.Operations._OclComparable___lt_ /* _'<'(OclSelf[1]) */,
			OCLstdlibTables.Operations._OclComparable___lt__eq_ /* _'<='(OclSelf[1]) */,
			OCLstdlibTables.Operations._OclComparable___gt_ /* _'>'(OclSelf[1]) */,
			OCLstdlibTables.Operations._OclComparable___gt__eq_ /* _'>='(OclSelf[1]) */,
			WebTables.Operations._Instant__compareTo /* compareTo(OclSelf[1]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Media__Media = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Media__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Media__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Media__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Media__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Media__StaticContent = {};

		private static final ExecutorOperation /*@NonNull*/ [] _MediaType__MediaType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _MediaType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MediaType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MediaType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MediaType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__MethodType = {};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _MethodType__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _NamedElement__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _NamedElement__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _NamedElement__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Page__Page = {
			WebTables.Operations._Page__getDynamicContentQty /* getDynamicContentQty() */,
			WebTables.Operations._Page__getStaticContentQty /* getStaticContentQty() */,
			WebTables.Operations._Page__isNotEmpty /* isNotEmpty() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Page__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Page__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Page__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _PartOfPage__PartOfPage = {};
		private static final ExecutorOperation /*@NonNull*/ [] _PartOfPage__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _PartOfPage__OclElement = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _PartOfPage__OclEnumeration = {
			OCLstdlibTables.Operations._OclEnumeration__allInstances /* allInstances() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _PartOfPage__OclType = {
			OCLstdlibTables.Operations._OclType__conformsTo /* conformsTo(OclType[?]) */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _Reference__Reference = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__Feature = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _Reference__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _StaticContent__StaticContent = {};
		private static final ExecutorOperation /*@NonNull*/ [] _StaticContent__Content = {};
		private static final ExecutorOperation /*@NonNull*/ [] _StaticContent__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _StaticContent__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _StaticContent__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		private static final ExecutorOperation /*@NonNull*/ [] _WebApplication__WebApplication = {};
		private static final ExecutorOperation /*@NonNull*/ [] _WebApplication__NamedElement = {};
		private static final ExecutorOperation /*@NonNull*/ [] _WebApplication__OclAny = {
			OCLstdlibTables.Operations._OclAny___lt__gt_ /* _'<>'(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny___eq_ /* _'='(OclSelf[?]) */,
			OCLstdlibTables.Operations._OclAny__oclAsSet /* oclAsSet() */,
			OCLstdlibTables.Operations._OclAny__oclAsType /* oclAsType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInState /* oclIsInState(OclState[?]) */,
			OCLstdlibTables.Operations._OclAny__oclIsInvalid /* oclIsInvalid() */,
			OCLstdlibTables.Operations._OclAny__oclIsKindOf /* oclIsKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsNew /* oclIsNew() */,
			OCLstdlibTables.Operations._OclAny__oclIsTypeOf /* oclIsTypeOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclAny__oclIsUndefined /* oclIsUndefined() */,
			OCLstdlibTables.Operations._OclAny__0_oclLog /* oclLog() */,
			OCLstdlibTables.Operations._OclAny__1_oclLog /* oclLog(String[1]) */,
			OCLstdlibTables.Operations._OclAny__oclType /* oclType() */,
			OCLstdlibTables.Operations._OclAny__oclTypes /* oclTypes() */,
			OCLstdlibTables.Operations._OclAny__toString /* toString() */
		};
		private static final ExecutorOperation /*@NonNull*/ [] _WebApplication__OclElement = {
			OCLstdlibTables.Operations._OclElement__allInstances /* allInstances() */,
			OCLstdlibTables.Operations._OclElement__oclAsModelType /* oclAsModelType(TT)(TT[1]) */,
			OCLstdlibTables.Operations._OclElement__oclContainer /* oclContainer() */,
			OCLstdlibTables.Operations._OclElement__oclContents /* oclContents() */,
			OCLstdlibTables.Operations._OclElement__oclIsModelKindOf /* oclIsModelKindOf(OclType[1]) */,
			OCLstdlibTables.Operations._OclElement__oclModelType /* oclModelType() */,
			OCLstdlibTables.Operations._OclElement__oclModelTypes /* oclModelTypes() */
		};

		/*
		 *	Install the operation descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Attribute__Attribute.initOperations(_Attribute__Attribute);
			Fragments._Attribute__Feature.initOperations(_Attribute__Feature);
			Fragments._Attribute__NamedElement.initOperations(_Attribute__NamedElement);
			Fragments._Attribute__OclAny.initOperations(_Attribute__OclAny);
			Fragments._Attribute__OclElement.initOperations(_Attribute__OclElement);

			Fragments._Content__Content.initOperations(_Content__Content);
			Fragments._Content__NamedElement.initOperations(_Content__NamedElement);
			Fragments._Content__OclAny.initOperations(_Content__OclAny);
			Fragments._Content__OclElement.initOperations(_Content__OclElement);

			Fragments._DataType__DataType.initOperations(_DataType__DataType);
			Fragments._DataType__OclAny.initOperations(_DataType__OclAny);
			Fragments._DataType__OclElement.initOperations(_DataType__OclElement);
			Fragments._DataType__OclEnumeration.initOperations(_DataType__OclEnumeration);
			Fragments._DataType__OclType.initOperations(_DataType__OclType);

			Fragments._DynamicContent__Content.initOperations(_DynamicContent__Content);
			Fragments._DynamicContent__DynamicContent.initOperations(_DynamicContent__DynamicContent);
			Fragments._DynamicContent__NamedElement.initOperations(_DynamicContent__NamedElement);
			Fragments._DynamicContent__OclAny.initOperations(_DynamicContent__OclAny);
			Fragments._DynamicContent__OclElement.initOperations(_DynamicContent__OclElement);

			Fragments._Element__Element.initOperations(_Element__Element);
			Fragments._Element__NamedElement.initOperations(_Element__NamedElement);
			Fragments._Element__OclAny.initOperations(_Element__OclAny);
			Fragments._Element__OclElement.initOperations(_Element__OclElement);

			Fragments._ElementType__ElementType.initOperations(_ElementType__ElementType);
			Fragments._ElementType__OclAny.initOperations(_ElementType__OclAny);
			Fragments._ElementType__OclElement.initOperations(_ElementType__OclElement);
			Fragments._ElementType__OclEnumeration.initOperations(_ElementType__OclEnumeration);
			Fragments._ElementType__OclType.initOperations(_ElementType__OclType);

			Fragments._Entity__Entity.initOperations(_Entity__Entity);
			Fragments._Entity__NamedElement.initOperations(_Entity__NamedElement);
			Fragments._Entity__OclAny.initOperations(_Entity__OclAny);
			Fragments._Entity__OclElement.initOperations(_Entity__OclElement);

			Fragments._Feature__Feature.initOperations(_Feature__Feature);
			Fragments._Feature__NamedElement.initOperations(_Feature__NamedElement);
			Fragments._Feature__OclAny.initOperations(_Feature__OclAny);
			Fragments._Feature__OclElement.initOperations(_Feature__OclElement);

			Fragments._Form__Content.initOperations(_Form__Content);
			Fragments._Form__Form.initOperations(_Form__Form);
			Fragments._Form__NamedElement.initOperations(_Form__NamedElement);
			Fragments._Form__OclAny.initOperations(_Form__OclAny);
			Fragments._Form__OclElement.initOperations(_Form__OclElement);
			Fragments._Form__StaticContent.initOperations(_Form__StaticContent);

			Fragments._Index__Content.initOperations(_Index__Content);
			Fragments._Index__DynamicContent.initOperations(_Index__DynamicContent);
			Fragments._Index__Index.initOperations(_Index__Index);
			Fragments._Index__NamedElement.initOperations(_Index__NamedElement);
			Fragments._Index__OclAny.initOperations(_Index__OclAny);
			Fragments._Index__OclElement.initOperations(_Index__OclElement);

			Fragments._Individual__Content.initOperations(_Individual__Content);
			Fragments._Individual__DynamicContent.initOperations(_Individual__DynamicContent);
			Fragments._Individual__Individual.initOperations(_Individual__Individual);
			Fragments._Individual__NamedElement.initOperations(_Individual__NamedElement);
			Fragments._Individual__OclAny.initOperations(_Individual__OclAny);
			Fragments._Individual__OclElement.initOperations(_Individual__OclElement);

			Fragments._Instant__Instant.initOperations(_Instant__Instant);
			Fragments._Instant__OclAny.initOperations(_Instant__OclAny);
			Fragments._Instant__OclComparable.initOperations(_Instant__OclComparable);

			Fragments._Media__Content.initOperations(_Media__Content);
			Fragments._Media__Media.initOperations(_Media__Media);
			Fragments._Media__NamedElement.initOperations(_Media__NamedElement);
			Fragments._Media__OclAny.initOperations(_Media__OclAny);
			Fragments._Media__OclElement.initOperations(_Media__OclElement);
			Fragments._Media__StaticContent.initOperations(_Media__StaticContent);

			Fragments._MediaType__MediaType.initOperations(_MediaType__MediaType);
			Fragments._MediaType__OclAny.initOperations(_MediaType__OclAny);
			Fragments._MediaType__OclElement.initOperations(_MediaType__OclElement);
			Fragments._MediaType__OclEnumeration.initOperations(_MediaType__OclEnumeration);
			Fragments._MediaType__OclType.initOperations(_MediaType__OclType);

			Fragments._MethodType__MethodType.initOperations(_MethodType__MethodType);
			Fragments._MethodType__OclAny.initOperations(_MethodType__OclAny);
			Fragments._MethodType__OclElement.initOperations(_MethodType__OclElement);
			Fragments._MethodType__OclEnumeration.initOperations(_MethodType__OclEnumeration);
			Fragments._MethodType__OclType.initOperations(_MethodType__OclType);

			Fragments._NamedElement__NamedElement.initOperations(_NamedElement__NamedElement);
			Fragments._NamedElement__OclAny.initOperations(_NamedElement__OclAny);
			Fragments._NamedElement__OclElement.initOperations(_NamedElement__OclElement);

			Fragments._Page__NamedElement.initOperations(_Page__NamedElement);
			Fragments._Page__OclAny.initOperations(_Page__OclAny);
			Fragments._Page__OclElement.initOperations(_Page__OclElement);
			Fragments._Page__Page.initOperations(_Page__Page);

			Fragments._PartOfPage__OclAny.initOperations(_PartOfPage__OclAny);
			Fragments._PartOfPage__OclElement.initOperations(_PartOfPage__OclElement);
			Fragments._PartOfPage__OclEnumeration.initOperations(_PartOfPage__OclEnumeration);
			Fragments._PartOfPage__OclType.initOperations(_PartOfPage__OclType);
			Fragments._PartOfPage__PartOfPage.initOperations(_PartOfPage__PartOfPage);

			Fragments._Reference__Feature.initOperations(_Reference__Feature);
			Fragments._Reference__NamedElement.initOperations(_Reference__NamedElement);
			Fragments._Reference__OclAny.initOperations(_Reference__OclAny);
			Fragments._Reference__OclElement.initOperations(_Reference__OclElement);
			Fragments._Reference__Reference.initOperations(_Reference__Reference);

			Fragments._StaticContent__Content.initOperations(_StaticContent__Content);
			Fragments._StaticContent__NamedElement.initOperations(_StaticContent__NamedElement);
			Fragments._StaticContent__OclAny.initOperations(_StaticContent__OclAny);
			Fragments._StaticContent__OclElement.initOperations(_StaticContent__OclElement);
			Fragments._StaticContent__StaticContent.initOperations(_StaticContent__StaticContent);

			Fragments._WebApplication__NamedElement.initOperations(_WebApplication__NamedElement);
			Fragments._WebApplication__OclAny.initOperations(_WebApplication__OclAny);
			Fragments._WebApplication__OclElement.initOperations(_WebApplication__OclElement);
			Fragments._WebApplication__WebApplication.initOperations(_WebApplication__WebApplication);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::FragmentOperations and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of local properties for the local fragment of each type.
	 */
	public static class FragmentProperties {
		static {
			Init.initStart();
			FragmentOperations.init();
		}

		private static final ExecutorProperty /*@NonNull*/ [] _Attribute = {
			WebTables.Properties._Attribute__isPK,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Attribute__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Content = {
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage
		};

		private static final ExecutorProperty /*@NonNull*/ [] _DataType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _DynamicContent = {
			WebTables.Properties._DynamicContent__attributes,
			WebTables.Properties._DynamicContent__entities,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Element = {
			WebTables.Properties._Element__attribute,
			WebTables.Properties._Element__form,
			WebTables.Properties._Element__label,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Element__tooltip,
			WebTables.Properties._Element__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _ElementType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Entity = {
			WebTables.Properties._Entity__features,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Feature = {
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Form = {
			WebTables.Properties._Form__elements,
			WebTables.Properties._Form__entity,
			WebTables.Properties._Form__method,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Index = {
			WebTables.Properties._DynamicContent__attributes,
			WebTables.Properties._DynamicContent__entities,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Individual = {
			WebTables.Properties._DynamicContent__attributes,
			WebTables.Properties._DynamicContent__entities,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Instant = {};

		private static final ExecutorProperty /*@NonNull*/ [] _Media = {
			WebTables.Properties._Media__altText,
			WebTables.Properties._Media__mediaClassification,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage,
			WebTables.Properties._Media__size,
			WebTables.Properties._Media__source,
			WebTables.Properties._Media__type
		};

		private static final ExecutorProperty /*@NonNull*/ [] _MediaType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _MethodType = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _NamedElement = {
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Page = {
			WebTables.Properties._Page__contents,
			WebTables.Properties._Page__createdAt,
			WebTables.Properties._Page__link,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Page__totalMediaSize,
			WebTables.Properties._Page__webApplication
		};

		private static final ExecutorProperty /*@NonNull*/ [] _PartOfPage = {
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _Reference = {
			WebTables.Properties._Reference__foreignKey,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents
		};

		private static final ExecutorProperty /*@NonNull*/ [] _StaticContent = {
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._Content__partOfPage
		};

		private static final ExecutorProperty /*@NonNull*/ [] _WebApplication = {
			WebTables.Properties._WebApplication__entities,
			WebTables.Properties._NamedElement__name,
			OCLstdlibTables.Properties._OclElement__oclContainer,
			OCLstdlibTables.Properties._OclElement__oclContents,
			WebTables.Properties._WebApplication__pages,
			WebTables.Properties._WebApplication__totalPages
		};

		/**
		 *	Install the property descriptors in the fragment descriptors.
		 */
		static {
			Fragments._Attribute__Attribute.initProperties(_Attribute);
			Fragments._Content__Content.initProperties(_Content);
			Fragments._DataType__DataType.initProperties(_DataType);
			Fragments._DynamicContent__DynamicContent.initProperties(_DynamicContent);
			Fragments._Element__Element.initProperties(_Element);
			Fragments._ElementType__ElementType.initProperties(_ElementType);
			Fragments._Entity__Entity.initProperties(_Entity);
			Fragments._Feature__Feature.initProperties(_Feature);
			Fragments._Form__Form.initProperties(_Form);
			Fragments._Index__Index.initProperties(_Index);
			Fragments._Individual__Individual.initProperties(_Individual);
			Fragments._Instant__Instant.initProperties(_Instant);
			Fragments._Media__Media.initProperties(_Media);
			Fragments._MediaType__MediaType.initProperties(_MediaType);
			Fragments._MethodType__MethodType.initProperties(_MethodType);
			Fragments._NamedElement__NamedElement.initProperties(_NamedElement);
			Fragments._Page__Page.initProperties(_Page);
			Fragments._PartOfPage__PartOfPage.initProperties(_PartOfPage);
			Fragments._Reference__Reference.initProperties(_Reference);
			Fragments._StaticContent__StaticContent.initProperties(_StaticContent);
			Fragments._WebApplication__WebApplication.initProperties(_WebApplication);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::FragmentProperties and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 *	The lists of enumeration literals for each enumeration.
	 */
	public static class EnumerationLiterals {
		static {
			Init.initStart();
			FragmentProperties.init();
		}

		public static final EcoreExecutorEnumerationLiteral _DataType__string = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("string"), Types._DataType, 0);
		public static final EcoreExecutorEnumerationLiteral _DataType__int = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("int"), Types._DataType, 1);
		public static final EcoreExecutorEnumerationLiteral _DataType__text = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("text"), Types._DataType, 2);
		public static final EcoreExecutorEnumerationLiteral _DataType__bool = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("bool"), Types._DataType, 3);
		public static final EcoreExecutorEnumerationLiteral _DataType__date = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("date"), Types._DataType, 4);
		public static final EcoreExecutorEnumerationLiteral _DataType__file = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("file"), Types._DataType, 5);
		public static final EcoreExecutorEnumerationLiteral _DataType__currency = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("currency"), Types._DataType, 6);
		public static final EcoreExecutorEnumerationLiteral _DataType__percent = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("percent"), Types._DataType, 7);
		public static final EcoreExecutorEnumerationLiteral _DataType__image = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("image"), Types._DataType, 8);
		public static final EcoreExecutorEnumerationLiteral _DataType__images = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("images"), Types._DataType, 9);
		public static final EcoreExecutorEnumerationLiteral _DataType__email = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("email"), Types._DataType, 10);
		public static final EcoreExecutorEnumerationLiteral _DataType__password = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.DATA_TYPE.getEEnumLiteral("password"), Types._DataType, 11);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _DataType = {
			_DataType__string,
			_DataType__int,
			_DataType__text,
			_DataType__bool,
			_DataType__date,
			_DataType__file,
			_DataType__currency,
			_DataType__percent,
			_DataType__image,
			_DataType__images,
			_DataType__email,
			_DataType__password
		};

		public static final EcoreExecutorEnumerationLiteral _ElementType__textBox = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("textBox"), Types._ElementType, 0);
		public static final EcoreExecutorEnumerationLiteral _ElementType__button = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("button"), Types._ElementType, 1);
		public static final EcoreExecutorEnumerationLiteral _ElementType__checkBox = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("checkBox"), Types._ElementType, 2);
		public static final EcoreExecutorEnumerationLiteral _ElementType__radioButton = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("radioButton"), Types._ElementType, 3);
		public static final EcoreExecutorEnumerationLiteral _ElementType__dropDown = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("dropDown"), Types._ElementType, 4);
		public static final EcoreExecutorEnumerationLiteral _ElementType__textArea = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("textArea"), Types._ElementType, 5);
		public static final EcoreExecutorEnumerationLiteral _ElementType__date = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.ELEMENT_TYPE.getEEnumLiteral("date"), Types._ElementType, 6);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _ElementType = {
			_ElementType__textBox,
			_ElementType__button,
			_ElementType__checkBox,
			_ElementType__radioButton,
			_ElementType__dropDown,
			_ElementType__textArea,
			_ElementType__date
		};

		public static final EcoreExecutorEnumerationLiteral _MediaType__image = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.MEDIA_TYPE.getEEnumLiteral("image"), Types._MediaType, 0);
		public static final EcoreExecutorEnumerationLiteral _MediaType__video = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.MEDIA_TYPE.getEEnumLiteral("video"), Types._MediaType, 1);
		public static final EcoreExecutorEnumerationLiteral _MediaType__gif = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.MEDIA_TYPE.getEEnumLiteral("gif"), Types._MediaType, 2);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _MediaType = {
			_MediaType__image,
			_MediaType__video,
			_MediaType__gif
		};

		public static final EcoreExecutorEnumerationLiteral _MethodType__POST = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.METHOD_TYPE.getEEnumLiteral("POST"), Types._MethodType, 0);
		public static final EcoreExecutorEnumerationLiteral _MethodType__PUT = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.METHOD_TYPE.getEEnumLiteral("PUT"), Types._MethodType, 1);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _MethodType = {
			_MethodType__POST,
			_MethodType__PUT
		};

		public static final EcoreExecutorEnumerationLiteral _PartOfPage__top = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.PART_OF_PAGE.getEEnumLiteral("top"), Types._PartOfPage, 0);
		public static final EcoreExecutorEnumerationLiteral _PartOfPage__bottom = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.PART_OF_PAGE.getEEnumLiteral("bottom"), Types._PartOfPage, 1);
		public static final EcoreExecutorEnumerationLiteral _PartOfPage__left = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.PART_OF_PAGE.getEEnumLiteral("left"), Types._PartOfPage, 2);
		public static final EcoreExecutorEnumerationLiteral _PartOfPage__right = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.PART_OF_PAGE.getEEnumLiteral("right"), Types._PartOfPage, 3);
		public static final EcoreExecutorEnumerationLiteral _PartOfPage__center = new EcoreExecutorEnumerationLiteral(WebPackage.Literals.PART_OF_PAGE.getEEnumLiteral("center"), Types._PartOfPage, 4);
		private static final EcoreExecutorEnumerationLiteral /*@NonNull*/ [] _PartOfPage = {
			_PartOfPage__top,
			_PartOfPage__bottom,
			_PartOfPage__left,
			_PartOfPage__right,
			_PartOfPage__center
		};

		/**
		 *	Install the enumeration literals in the enumerations.
		 */
		static {
			Types._DataType.initLiterals(_DataType);
			Types._ElementType.initLiterals(_ElementType);
			Types._MediaType.initLiterals(_MediaType);
			Types._MethodType.initLiterals(_MethodType);
			Types._PartOfPage.initLiterals(_PartOfPage);

			Init.initEnd();
		}

		/**
		 * Force initialization of the fields of WebTables::EnumerationLiterals and all preceding sub-packages.
		 */
		public static void init() {}
	}

	/**
	 * The multiple packages above avoid problems with the Java 65536 byte limit but introduce a difficulty in ensuring that
	 * static construction occurs in the disciplined order of the packages when construction may start in any of the packages.
	 * The problem is resolved by ensuring that the static construction of each package first initializes its immediate predecessor.
	 * On completion of predecessor initialization, the residual packages are initialized by starting an initialization in the last package.
	 * This class maintains a count so that the various predecessors can distinguish whether they are the starting point and so
	 * ensure that residual construction occurs just once after all predecessors.
	 */
	private static class Init {
		/**
		 * Counter of nested static constructions. On return to zero residual construction starts. -ve once residual construction started.
		 */
		private static int initCount = 0;

		/**
		 * Invoked at the start of a static construction to defer residual construction until primary constructions complete.
		 */
		private static void initStart() {
			if (initCount >= 0) {
				initCount++;
			}
		}

		/**
		 * Invoked at the end of a static construction to activate residual construction once primary constructions complete.
		 */
		private static void initEnd() {
			if (initCount > 0) {
				if (--initCount == 0) {
					initCount = -1;
					EnumerationLiterals.init();
				}
			}
		}
	}

	static {
		Init.initEnd();
	}

	/*
	 * Force initialization of outer fields. Inner fields are lazily initialized.
	 */
	public static void init() {
		new WebTables();
	}

	private WebTables() {
		super(WebPackage.eNS_URI);
	}
}
