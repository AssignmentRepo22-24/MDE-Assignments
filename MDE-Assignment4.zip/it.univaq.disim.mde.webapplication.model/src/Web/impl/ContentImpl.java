/**
 */
package Web.impl;

import Web.Content;
import Web.PartOfPage;
import Web.WebPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Content</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Web.impl.ContentImpl#getPartOfPage <em>Part Of Page</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ContentImpl extends NamedElementImpl implements Content {
	/**
	 * The default value of the '{@link #getPartOfPage() <em>Part Of Page</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPartOfPage()
	 * @generated
	 * @ordered
	 */
	protected static final PartOfPage PART_OF_PAGE_EDEFAULT = PartOfPage.TOP;

	/**
	 * The cached value of the '{@link #getPartOfPage() <em>Part Of Page</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPartOfPage()
	 * @generated
	 * @ordered
	 */
	protected PartOfPage partOfPage = PART_OF_PAGE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ContentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebPackage.Literals.CONTENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PartOfPage getPartOfPage() {
		return partOfPage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPartOfPage(PartOfPage newPartOfPage) {
		PartOfPage oldPartOfPage = partOfPage;
		partOfPage = newPartOfPage == null ? PART_OF_PAGE_EDEFAULT : newPartOfPage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebPackage.CONTENT__PART_OF_PAGE, oldPartOfPage, partOfPage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebPackage.CONTENT__PART_OF_PAGE:
				return getPartOfPage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebPackage.CONTENT__PART_OF_PAGE:
				setPartOfPage((PartOfPage)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebPackage.CONTENT__PART_OF_PAGE:
				setPartOfPage(PART_OF_PAGE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebPackage.CONTENT__PART_OF_PAGE:
				return partOfPage != PART_OF_PAGE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (partOfPage: ");
		result.append(partOfPage);
		result.append(')');
		return result.toString();
	}

} //ContentImpl
