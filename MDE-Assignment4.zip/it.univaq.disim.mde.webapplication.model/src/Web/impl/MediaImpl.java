/**
 */
package Web.impl;

import Web.Media;
import Web.MediaType;
import Web.WebPackage;

import Web.WebTables;
import java.math.BigDecimal;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.ocl.pivot.evaluation.Executor;
import org.eclipse.ocl.pivot.library.oclany.OclComparableLessThanOperation;
import org.eclipse.ocl.pivot.utilities.PivotUtil;
import org.eclipse.ocl.pivot.utilities.ValueUtil;
import org.eclipse.ocl.pivot.values.RealValue;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Media</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link Web.impl.MediaImpl#getType <em>Type</em>}</li>
 *   <li>{@link Web.impl.MediaImpl#getSource <em>Source</em>}</li>
 *   <li>{@link Web.impl.MediaImpl#getAltText <em>Alt Text</em>}</li>
 *   <li>{@link Web.impl.MediaImpl#getSize <em>Size</em>}</li>
 *   <li>{@link Web.impl.MediaImpl#getMediaClassification <em>Media Classification</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MediaImpl extends StaticContentImpl implements Media {
	/**
	 * The default value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected static final MediaType TYPE_EDEFAULT = MediaType.IMAGE;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected MediaType type = TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSource() <em>Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected static final String SOURCE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSource() <em>Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSource()
	 * @generated
	 * @ordered
	 */
	protected String source = SOURCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAltText() <em>Alt Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAltText()
	 * @generated
	 * @ordered
	 */
	protected static final String ALT_TEXT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAltText() <em>Alt Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAltText()
	 * @generated
	 * @ordered
	 */
	protected String altText = ALT_TEXT_EDEFAULT;

	/**
	 * The default value of the '{@link #getSize() <em>Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected static final BigDecimal SIZE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSize() <em>Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected BigDecimal size = SIZE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMediaClassification() <em>Media Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMediaClassification()
	 * @generated
	 * @ordered
	 */
	protected static final String MEDIA_CLASSIFICATION_EDEFAULT = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MediaImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebPackage.Literals.MEDIA;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MediaType getType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(MediaType newType) {
		MediaType oldType = type;
		type = newType == null ? TYPE_EDEFAULT : newType;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebPackage.MEDIA__TYPE, oldType, type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSource() {
		return source;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSource(String newSource) {
		String oldSource = source;
		source = newSource;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebPackage.MEDIA__SOURCE, oldSource, source));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAltText() {
		return altText;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAltText(String newAltText) {
		String oldAltText = altText;
		altText = newAltText;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebPackage.MEDIA__ALT_TEXT, oldAltText, altText));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BigDecimal getSize() {
		return size;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSize(BigDecimal newSize) {
		BigDecimal oldSize = size;
		size = newSize;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, WebPackage.MEDIA__SIZE, oldSize, size));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getMediaClassification() {
		/**
		 * if size < 20 then 'Small size media' else 'Large size media' endif
		 */
		final /*@NonInvalid*/ Executor executor = PivotUtil.getExecutor(this);
		final /*@NonInvalid*/ BigDecimal size = this.getSize();
		final /*@NonInvalid*/ RealValue BOXED_size = ValueUtil.realValueOf(size);
		final /*@NonInvalid*/ boolean lt = OclComparableLessThanOperation.INSTANCE.evaluate(executor, BOXED_size, WebTables.INT_20).booleanValue();
		/*@NonInvalid*/ String local_0;
		if (lt) {
			local_0 = WebTables.STR_Small_32_size_32_media;
		}
		else {
			local_0 = WebTables.STR_Large_32_size_32_media;
		}
		return local_0;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMediaClassification(String newMediaClassification) {
		// TODO: implement this method to set the 'Media Classification' attribute
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case WebPackage.MEDIA__TYPE:
				return getType();
			case WebPackage.MEDIA__SOURCE:
				return getSource();
			case WebPackage.MEDIA__ALT_TEXT:
				return getAltText();
			case WebPackage.MEDIA__SIZE:
				return getSize();
			case WebPackage.MEDIA__MEDIA_CLASSIFICATION:
				return getMediaClassification();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case WebPackage.MEDIA__TYPE:
				setType((MediaType)newValue);
				return;
			case WebPackage.MEDIA__SOURCE:
				setSource((String)newValue);
				return;
			case WebPackage.MEDIA__ALT_TEXT:
				setAltText((String)newValue);
				return;
			case WebPackage.MEDIA__SIZE:
				setSize((BigDecimal)newValue);
				return;
			case WebPackage.MEDIA__MEDIA_CLASSIFICATION:
				setMediaClassification((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case WebPackage.MEDIA__TYPE:
				setType(TYPE_EDEFAULT);
				return;
			case WebPackage.MEDIA__SOURCE:
				setSource(SOURCE_EDEFAULT);
				return;
			case WebPackage.MEDIA__ALT_TEXT:
				setAltText(ALT_TEXT_EDEFAULT);
				return;
			case WebPackage.MEDIA__SIZE:
				setSize(SIZE_EDEFAULT);
				return;
			case WebPackage.MEDIA__MEDIA_CLASSIFICATION:
				setMediaClassification(MEDIA_CLASSIFICATION_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case WebPackage.MEDIA__TYPE:
				return type != TYPE_EDEFAULT;
			case WebPackage.MEDIA__SOURCE:
				return SOURCE_EDEFAULT == null ? source != null : !SOURCE_EDEFAULT.equals(source);
			case WebPackage.MEDIA__ALT_TEXT:
				return ALT_TEXT_EDEFAULT == null ? altText != null : !ALT_TEXT_EDEFAULT.equals(altText);
			case WebPackage.MEDIA__SIZE:
				return SIZE_EDEFAULT == null ? size != null : !SIZE_EDEFAULT.equals(size);
			case WebPackage.MEDIA__MEDIA_CLASSIFICATION:
				return MEDIA_CLASSIFICATION_EDEFAULT == null ? getMediaClassification() != null : !MEDIA_CLASSIFICATION_EDEFAULT.equals(getMediaClassification());
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (type: ");
		result.append(type);
		result.append(", source: ");
		result.append(source);
		result.append(", altText: ");
		result.append(altText);
		result.append(", size: ");
		result.append(size);
		result.append(')');
		return result.toString();
	}

} //MediaImpl
