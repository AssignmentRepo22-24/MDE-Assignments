/**
 */
package Web.impl;

import Web.StaticContent;
import Web.WebPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Static Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class StaticContentImpl extends ContentImpl implements StaticContent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StaticContentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WebPackage.Literals.STATIC_CONTENT;
	}

} //StaticContentImpl
