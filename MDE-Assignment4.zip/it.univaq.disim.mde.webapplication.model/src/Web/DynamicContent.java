/**
 */
package Web;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dynamic Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Web.DynamicContent#getAttributes <em>Attributes</em>}</li>
 *   <li>{@link Web.DynamicContent#getEntities <em>Entities</em>}</li>
 * </ul>
 *
 * @see Web.WebPackage#getDynamicContent()
 * @model abstract="true"
 * @generated
 */
public interface DynamicContent extends Content {
	/**
	 * Returns the value of the '<em><b>Attributes</b></em>' reference list.
	 * The list contents are of type {@link Web.Attribute}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributes</em>' reference list.
	 * @see Web.WebPackage#getDynamicContent_Attributes()
	 * @model required="true"
	 * @generated
	 */
	EList<Attribute> getAttributes();

	/**
	 * Returns the value of the '<em><b>Entities</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entities</em>' reference.
	 * @see #setEntities(Entity)
	 * @see Web.WebPackage#getDynamicContent_Entities()
	 * @model required="true"
	 * @generated
	 */
	Entity getEntities();

	/**
	 * Sets the value of the '{@link Web.DynamicContent#getEntities <em>Entities</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Entities</em>' reference.
	 * @see #getEntities()
	 * @generated
	 */
	void setEntities(Entity value);

} // DynamicContent
