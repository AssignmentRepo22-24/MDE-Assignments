/**
 */
package Web;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Web.Content#getPartOfPage <em>Part Of Page</em>}</li>
 * </ul>
 *
 * @see Web.WebPackage#getContent()
 * @model abstract="true"
 * @generated
 */
public interface Content extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Part Of Page</b></em>' attribute.
	 * The literals are from the enumeration {@link Web.PartOfPage}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part Of Page</em>' attribute.
	 * @see Web.PartOfPage
	 * @see #setPartOfPage(PartOfPage)
	 * @see Web.WebPackage#getContent_PartOfPage()
	 * @model required="true"
	 * @generated
	 */
	PartOfPage getPartOfPage();

	/**
	 * Sets the value of the '{@link Web.Content#getPartOfPage <em>Part Of Page</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Part Of Page</em>' attribute.
	 * @see Web.PartOfPage
	 * @see #getPartOfPage()
	 * @generated
	 */
	void setPartOfPage(PartOfPage value);

} // Content
