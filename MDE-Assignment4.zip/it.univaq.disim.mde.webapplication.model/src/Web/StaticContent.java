/**
 */
package Web;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Static Content</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Web.WebPackage#getStaticContent()
 * @model abstract="true"
 * @generated
 */
public interface StaticContent extends Content {
} // StaticContent
