/**
 */
package Web;

import java.math.BigInteger;

import java.time.Instant;
import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Page</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Web.Page#getTotalMediaSize <em>Total Media Size</em>}</li>
 *   <li>{@link Web.Page#getLink <em>Link</em>}</li>
 *   <li>{@link Web.Page#getContents <em>Contents</em>}</li>
 *   <li>{@link Web.Page#getWebApplication <em>Web Application</em>}</li>
 *   <li>{@link Web.Page#getCreatedAt <em>Created At</em>}</li>
 * </ul>
 *
 * @see Web.WebPackage#getPage()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='OptimisePageLoad'"
 * @generated
 */
public interface Page extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Total Media Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Total Media Size</em>' attribute.
	 * @see #setTotalMediaSize(double)
	 * @see Web.WebPackage#getPage_TotalMediaSize()
	 * @model required="true" volatile="true" derived="true"
	 * @generated
	 */
	double getTotalMediaSize();

	/**
	 * Sets the value of the '{@link Web.Page#getTotalMediaSize <em>Total Media Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Total Media Size</em>' attribute.
	 * @see #getTotalMediaSize()
	 * @generated
	 */
	void setTotalMediaSize(double value);

	/**
	 * Returns the value of the '<em><b>Link</b></em>' reference list.
	 * The list contents are of type {@link Web.Page}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Link</em>' reference list.
	 * @see Web.WebPackage#getPage_Link()
	 * @model
	 * @generated
	 */
	EList<Page> getLink();

	/**
	 * Returns the value of the '<em><b>Contents</b></em>' containment reference list.
	 * The list contents are of type {@link Web.Content}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contents</em>' containment reference list.
	 * @see Web.WebPackage#getPage_Contents()
	 * @model containment="true"
	 * @generated
	 */
	EList<Content> getContents();

	/**
	 * Returns the value of the '<em><b>Web Application</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link Web.WebApplication#getPages <em>Pages</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Web Application</em>' container reference.
	 * @see #setWebApplication(WebApplication)
	 * @see Web.WebPackage#getPage_WebApplication()
	 * @see Web.WebApplication#getPages
	 * @model opposite="pages" required="true" transient="false"
	 * @generated
	 */
	WebApplication getWebApplication();

	/**
	 * Sets the value of the '{@link Web.Page#getWebApplication <em>Web Application</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Web Application</em>' container reference.
	 * @see #getWebApplication()
	 * @generated
	 */
	void setWebApplication(WebApplication value);

	/**
	 * Returns the value of the '<em><b>Created At</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Created At</em>' attribute.
	 * @see #setCreatedAt(Instant)
	 * @see Web.WebPackage#getPage_CreatedAt()
	 * @model dataType="Web.Instant"
	 * @generated
	 */
	Instant getCreatedAt();

	/**
	 * Sets the value of the '{@link Web.Page#getCreatedAt <em>Created At</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Created At</em>' attribute.
	 * @see #getCreatedAt()
	 * @generated
	 */
	void setCreatedAt(Instant value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='contents -&gt; notEmpty()'"
	 * @generated
	 */
	Boolean isNotEmpty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='contents -&gt;select( e | e.oclIsKindOf(StaticContent))-&gt; size()'"
	 * @generated
	 */
	BigInteger getStaticContentQty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='contents -&gt;select( e | e.oclIsKindOf(DynamicContent))-&gt; size()'"
	 * @generated
	 */
	BigInteger getDynamicContentQty();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='totalMediaSize &lt;= 50'"
	 * @generated
	 */
	boolean OptimisePageLoad(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Page
