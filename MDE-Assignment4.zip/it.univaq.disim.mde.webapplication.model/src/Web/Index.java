/**
 */
package Web;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Index</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see Web.WebPackage#getIndex()
 * @model
 * @generated
 */
public interface Index extends DynamicContent {
} // Index
