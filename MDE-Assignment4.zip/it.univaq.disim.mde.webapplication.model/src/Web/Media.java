/**
 */
package Web;

import java.math.BigDecimal;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Media</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link Web.Media#getType <em>Type</em>}</li>
 *   <li>{@link Web.Media#getSource <em>Source</em>}</li>
 *   <li>{@link Web.Media#getAltText <em>Alt Text</em>}</li>
 *   <li>{@link Web.Media#getSize <em>Size</em>}</li>
 *   <li>{@link Web.Media#getMediaClassification <em>Media Classification</em>}</li>
 * </ul>
 *
 * @see Web.WebPackage#getMedia()
 * @model
 * @generated
 */
public interface Media extends StaticContent {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link Web.MediaType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see Web.MediaType
	 * @see #setType(MediaType)
	 * @see Web.WebPackage#getMedia_Type()
	 * @model
	 * @generated
	 */
	MediaType getType();

	/**
	 * Sets the value of the '{@link Web.Media#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see Web.MediaType
	 * @see #getType()
	 * @generated
	 */
	void setType(MediaType value);

	/**
	 * Returns the value of the '<em><b>Source</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Source</em>' attribute.
	 * @see #setSource(String)
	 * @see Web.WebPackage#getMedia_Source()
	 * @model
	 * @generated
	 */
	String getSource();

	/**
	 * Sets the value of the '{@link Web.Media#getSource <em>Source</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Source</em>' attribute.
	 * @see #getSource()
	 * @generated
	 */
	void setSource(String value);

	/**
	 * Returns the value of the '<em><b>Alt Text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Alt Text</em>' attribute.
	 * @see #setAltText(String)
	 * @see Web.WebPackage#getMedia_AltText()
	 * @model
	 * @generated
	 */
	String getAltText();

	/**
	 * Sets the value of the '{@link Web.Media#getAltText <em>Alt Text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Alt Text</em>' attribute.
	 * @see #getAltText()
	 * @generated
	 */
	void setAltText(String value);

	/**
	 * Returns the value of the '<em><b>Size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Size</em>' attribute.
	 * @see #setSize(BigDecimal)
	 * @see Web.WebPackage#getMedia_Size()
	 * @model required="true"
	 * @generated
	 */
	BigDecimal getSize();

	/**
	 * Sets the value of the '{@link Web.Media#getSize <em>Size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Size</em>' attribute.
	 * @see #getSize()
	 * @generated
	 */
	void setSize(BigDecimal value);

	/**
	 * Returns the value of the '<em><b>Media Classification</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Media Classification</em>' attribute.
	 * @see #setMediaClassification(String)
	 * @see Web.WebPackage#getMedia_MediaClassification()
	 * @model volatile="true" derived="true"
	 * @generated
	 */
	String getMediaClassification();

	/**
	 * Sets the value of the '{@link Web.Media#getMediaClassification <em>Media Classification</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Media Classification</em>' attribute.
	 * @see #getMediaClassification()
	 * @generated
	 */
	void setMediaClassification(String value);

} // Media
