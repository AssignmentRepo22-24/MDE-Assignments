/**
 */
package Web.tests;

import Web.Form;
import Web.WebFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Form</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link Web.Form#getElementQty() <em>Get Element Qty</em>}</li>
 *   <li>{@link Web.Form#AtLeastOneElement(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Element</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class FormTest extends StaticContentTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(FormTest.class);
	}

	/**
	 * Constructs a new Form test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FormTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Form test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Form getFixture() {
		return (Form)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebFactory.eINSTANCE.createForm());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link Web.Form#getElementQty() <em>Get Element Qty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Form#getElementQty()
	 * @generated
	 */
	public void testGetElementQty() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.Form#AtLeastOneElement(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Element</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Form#AtLeastOneElement(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testAtLeastOneElement__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //FormTest
