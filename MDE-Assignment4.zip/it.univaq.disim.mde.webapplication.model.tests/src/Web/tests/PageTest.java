/**
 */
package Web.tests;

import Web.Page;
import Web.WebFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Page</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are tested:
 * <ul>
 *   <li>{@link Web.Page#getTotalMediaSize() <em>Total Media Size</em>}</li>
 * </ul>
 * </p>
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link Web.Page#isNotEmpty() <em>Is Not Empty</em>}</li>
 *   <li>{@link Web.Page#getStaticContentQty() <em>Get Static Content Qty</em>}</li>
 *   <li>{@link Web.Page#getDynamicContentQty() <em>Get Dynamic Content Qty</em>}</li>
 *   <li>{@link Web.Page#OptimisePageLoad(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Optimise Page Load</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class PageTest extends NamedElementTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(PageTest.class);
	}

	/**
	 * Constructs a new Page test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PageTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Page test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected Page getFixture() {
		return (Page)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebFactory.eINSTANCE.createPage());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link Web.Page#getTotalMediaSize() <em>Total Media Size</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Page#getTotalMediaSize()
	 * @generated
	 */
	public void testGetTotalMediaSize() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.Page#setTotalMediaSize(double) <em>Total Media Size</em>}' feature setter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Page#setTotalMediaSize(double)
	 * @generated
	 */
	public void testSetTotalMediaSize() {
		// TODO: implement this feature setter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.Page#isNotEmpty() <em>Is Not Empty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Page#isNotEmpty()
	 * @generated
	 */
	public void testIsNotEmpty() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.Page#getStaticContentQty() <em>Get Static Content Qty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Page#getStaticContentQty()
	 * @generated
	 */
	public void testGetStaticContentQty() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.Page#getDynamicContentQty() <em>Get Dynamic Content Qty</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Page#getDynamicContentQty()
	 * @generated
	 */
	public void testGetDynamicContentQty() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.Page#OptimisePageLoad(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Optimise Page Load</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.Page#OptimisePageLoad(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testOptimisePageLoad__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //PageTest
