/**
 */
package Web.tests;

import Web.WebApplication;
import Web.WebFactory;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Application</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are tested:
 * <ul>
 *   <li>{@link Web.WebApplication#getTotalPages() <em>Total Pages</em>}</li>
 * </ul>
 * </p>
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link Web.WebApplication#UniquePageNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Page Names</em>}</li>
 *   <li>{@link Web.WebApplication#AtLeastOnePage(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Page</em>}</li>
 *   <li>{@link Web.WebApplication#AtLeastOneEntity(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Entity</em>}</li>
 *   <li>{@link Web.WebApplication#UniqueEntityNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Entity Names</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class WebApplicationTest extends NamedElementTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(WebApplicationTest.class);
	}

	/**
	 * Constructs a new Application test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public WebApplicationTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Application test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected WebApplication getFixture() {
		return (WebApplication)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(WebFactory.eINSTANCE.createWebApplication());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

	/**
	 * Tests the '{@link Web.WebApplication#getTotalPages() <em>Total Pages</em>}' feature getter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.WebApplication#getTotalPages()
	 * @generated
	 */
	public void testGetTotalPages() {
		// TODO: implement this feature getter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.WebApplication#setTotalPages(int) <em>Total Pages</em>}' feature setter.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.WebApplication#setTotalPages(int)
	 * @generated
	 */
	public void testSetTotalPages() {
		// TODO: implement this feature setter test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.WebApplication#AtLeastOneEntity(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Entity</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.WebApplication#AtLeastOneEntity(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testAtLeastOneEntity__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.WebApplication#UniqueEntityNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Entity Names</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.WebApplication#UniqueEntityNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testUniqueEntityNames__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.WebApplication#UniquePageNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>Unique Page Names</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.WebApplication#UniquePageNames(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testUniquePageNames__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

	/**
	 * Tests the '{@link Web.WebApplication#AtLeastOnePage(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map) <em>At Least One Page</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see Web.WebApplication#AtLeastOnePage(org.eclipse.emf.common.util.DiagnosticChain, java.util.Map)
	 * @generated
	 */
	public void testAtLeastOnePage__DiagnosticChain_Map() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //WebApplicationTest
